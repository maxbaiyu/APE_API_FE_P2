import React, { useEffect, useRef } from 'react'
import { useState } from 'react'
import { Provider as StoreProvider } from 'reto'
import { PersistState } from './plugins/persist'

export interface DictState {
    dicts: any[]
}

export function DictStore() {
    const [state, setState] = useState(
        PersistState('dict', {
            dicts: []
        } as any)
    )

    function updateDict(values) {
        setState({
            dicts: values
        })
    }

    return Object.assign(
        {
            key: 'dict',
            state,
            setState
        },
        { updateDict }
    )
}

export const DictStoreProvider = props => (
    <StoreProvider of={DictStore}>{props.children}</StoreProvider>
)
