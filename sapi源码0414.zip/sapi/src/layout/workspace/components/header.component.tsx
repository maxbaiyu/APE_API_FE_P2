import React, { Component } from 'react'
import styled from 'styled-components'
import { Button, Dropdown, Menu,Badge, message  } from 'antd'
import { Avatar } from 'antd'
import { UserOutlined, DownOutlined } from '@ant-design/icons'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { RouteComponentProps } from 'react-router-dom'
import { dateFormat } from '~/shared/utils/common.util'
import { AuthWrapper } from '~/shared/components/auth-wrapper'
import { taskService } from '~/services/task'
import { RequestParams } from '~/core/http'
const components = {
    Wrapper: styled.section`
        padding: 0 20px;
    `,
    LogoContainer: styled.div`
        padding: 0 10px;
    `,
    UserContainer: styled.div`
        padding: 0 20px;
    `,
    ActionContainer: styled.div`
        padding: 0 20px;
        .action-button {
            background-color: ${props => props.theme.header.button.background};
            color: ${props => props.theme.header.button.color};
            border: none;
        }
    `,
    MenuContainer: styled(Menu)`
        padding: 0;
        .ant-dropdown-menu-item,
        .ant-dropdown-menu-submenu-title {
            padding: 0;
        }
    `,
    MenuItem: styled(AuthWrapper(Menu.Item))`
        padding: 15px 10px !important;
        background-color: #1d262c;
        color: #969696;
        border-left: solid 5px transparent;
        font-size: 14px;

        &:hover {
            background-color: #253038;
            color: #fff;
            border-left-color: #db0011;
        }
    `
}

interface HeaderProps {}

interface HeaderState {
    currentMenu: any
    location: any
    messageNum:any
    linkNum:any
}

export default class Header extends Component<
    RouteComponentProps<HeaderProps>,
    HeaderState
> {
    private taskService = new taskService()
    constructor(props) {
        super(props)
        this.state={
            messageNum:'',
            location:'',
            currentMenu:'',
            linkNum:null
        }
    }
   public componentDidMount(){
    
   }

   public componentDidUpdate(){
        
   }
    public render() {
        return (
            <components.Wrapper className="full-absolute flex-row justify-content-between align-items-center">
                {this.renderLogoContainer()}
                <div
                    className="flex-row flex-nowrap align-items-center"
                    style={{ cursor: 'pointer' }}
                >
                    {this.renderUserContainer()}
                    {this.renderActionContainer()}
                </div>
            </components.Wrapper>
        )
    }

    private renderLogoContainer() {
        return (
            <components.LogoContainer>
                {/* <Avatar shape="square" size="large" icon={<UserOutlined />} />
                 */}
                <a href="#">
                    <img
                        src={require('~/assets/images/Logo.png')}
                        height="30px"
                        onClick={() => {
                            this.props.history.push('/home-page')
                        }}
                    ></img>
                </a>
            </components.LogoContainer>
        )
    }
  private  editLink({ taskout }){
      taskout(0)

    this.props.history.push({
        pathname: '/pages/user-center'
    })
  }
    private renderUserContainer() {
        const {messageNum} = this.state
        const menu = (
            <components.MenuContainer>
                <components.MenuItem
                    onClick={() => this.openUserProfile()}
                    auth={[
                        'ROLE_01',
                        'ROLE_02',
                        'ROLE_03',
                        'ROLE_04',
                        'ROLE_05',
                        'ROLE_06',
                        'ROLE_07',
                        'ROLE_08',
                        'ROLE_09',
                        'ROLE_10',
                        "ROLE_011"
                    ]}
                >
                    User Profile
                </components.MenuItem>
                <components.MenuItem
                    onClick={() => this.openUserCenter()}
                    auth={[
                        'ROLE_01',
                        'ROLE_02',
                        'ROLE_03',
                        'ROLE_04',
                        'ROLE_05',
                        'ROLE_06',
                        'ROLE_07',
                        'ROLE_08',
                        'ROLE_09',
                        'ROLE_10',
                        "ROLE_011"
                    ]}
                >
                    User Center
                </components.MenuItem>
                <components.MenuItem
                    auth={['ROLE_09']}
                    onClick={() => this.openAccountAuthotiry()}
                >
                    Account Authority
                </components.MenuItem>
            </components.MenuContainer>
        )

        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <>
                        <>
                            <div onClick={() => {
                                this.editLink(userStore)
                            } }
                                style={{ marginTop: 20 }}
                            >

                                <Badge count={userStore.state.msgCount}>
                                    <p className="head-example"></p>
                                </Badge>
                            </div>

                            <Dropdown
                                overlay={menu}
                                trigger={['click']}
                                overlayStyle={{ background: 'red' }}
                            >
                                <components.UserContainer className="flex-row align-items-center">
                                    <div className="padding-right">
                                        <div className="text-right">
                                            {userStore.state.userName}
                                        </div>
                                        <div>
                                    Last Login{' '}
                                            {dateFormat(Date.now(), 'dd/MM/yyyy hh:mm')}
                                        </div>
                                    </div>
                                    <div>
                                        <img style={{ borderRadius: '50%', width: '2.5rem', height: '2.5rem', marginRight: 12, }} src={userStore.state.userPhoto} alt="" />
                                    </div>
                                    <DownOutlined style={{ fontSize: '16px' }} />
                                </components.UserContainer>
                            </Dropdown>
                        </></>
                )}
            </Consumer>
        )
    }
    private openUserProfile() {
        this.props.history.push('/pages/user-profile')
    }
    private openAccountAuthotiry() {
        this.props.history.push('/pages/account-authotiry')
    }

    private openUserCenter() {
        this.props.history.push('/pages/user-center')
    }

    private renderActionContainer() {
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <components.ActionContainer>
                        <Button
                            onClick={() => this.onLogout(userStore)}
                            className="action-button"
                        >
                            Log off
                        </Button>
                    </components.ActionContainer>
                )}
            </Consumer>
        )
    }

    private onLogout({ logout }) {
        const { history } = this.props
        logout()
        // sessionStorage.clear()
        // history.push('/dashboard')
    }
    
}
