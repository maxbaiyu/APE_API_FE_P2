import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react'
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom'
import { routes } from './routes'
import { UserStore } from '~/store/user.store'
import { useStore } from 'reto'

function RouterGenerate(route) {
    const DICT_STORE_KEY = 'react-storage'
    if (route.redirect) {
        return (
            <Route path={route.path}>
                <Redirect push to={route.redirect}></Redirect>
            </Route>
        )
    }

    if (route.auth && !route.token) {
        const { search, pathname } = window.location
        if (pathname !== '/login') {
            const storage = localStorage.getItem(DICT_STORE_KEY) || '{}'
            const stroageObject = JSON.parse(storage)
            const staffId = stroageObject?.user?.staffId || ''
            const preUserOperateInfo = {
                pathname: pathname + search,
                staffId,
                state: window.history?.state?.state
            }
            localStorage.setItem(
                'preUserOperateInfo',
                JSON.stringify(preUserOperateInfo)
            )
        }
        return (
            <Route path={route.path}>
                <Redirect push to="/login"></Redirect>
            </Route>
        )
    }

    return (
        <Route
            path={route.path}
            render={props => (
                <route.layout {...props}>
                    <route.component {...props} routes={route.routes} />
                </route.layout>
            )}
        />
    )
}

function RouterContainer() {
    const userStore = useStore(UserStore)
    const token = userStore.state.token
    return (
        <Switch>
            {routes.map((route, index) => (
                <RouterGenerate key={index} {...route} token={token} />
            ))}
        </Switch>
    )
}

export function Router() {
    return (
        <BrowserRouter>
            <RouterContainer></RouterContainer>
        </BrowserRouter>
    )
}
