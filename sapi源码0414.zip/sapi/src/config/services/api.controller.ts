/**
 * API Catalogue Controller
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'api'

export const ApiController = {
    // update apiCatalogue
    cataloguePut: {
        controller,
        action: 'catalogue',
        type: RequestMethod.Put
    },
    // all
    catalogueAll: {
        controller,
        action: 'catalogue/all',
        type: RequestMethod.Get
    },
    // get ApiList By ApiName
    catalogueApiList: {
        controller,
        action: 'catalogue/api-list',
        type: RequestMethod.Get
    },
    // check api submit
    catalogueChecking: {
        controller,
        action: 'catalogue/checking',
        type: RequestMethod.Get
    },
    // update apiCatalogue version
    catalogueVersionPut: {
        controller,
        action: 'catalogue/version',
        type: RequestMethod.Put
    },
    // get apiCatalogue version detail
    catalogueVersionGet: {
        controller,
        action: 'catalogue/version',
        type: RequestMethod.Get
    },
    // get apiCatalogue detail
    catalogueGetById: {
        controller,
        action: 'catalogue',
        type: RequestMethod.Get
    },
    service: {
        controller,
        action: 'catalogue/service',
        type: RequestMethod.Get
    },
    version: {
        controller,
        action: 'catalogue/version',
        type: RequestMethod.Post
    },
}
