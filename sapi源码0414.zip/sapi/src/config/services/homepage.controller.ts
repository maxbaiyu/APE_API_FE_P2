/**
 * Review Service
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'homepage'

export const homepageController = {
    messageGet: {
        controller,
        action: 'message',
        type: RequestMethod.Get
    },
    messagePost: {
        controller,
        action: 'message',
        type: RequestMethod.Post
    },
    messageDelete: {
        controller,
        action: 'message',
        type: RequestMethod.Delete
    },
    details: {
        controller,
        action: 'demand/details',
        type: RequestMethod.Get
    },
    date: {
        controller,
        action: 'demand/date',
        type: RequestMethod.Get
    },
    outstandingApproval: {
        controller,
        action: 'outstanding-approval',
        type: RequestMethod.Get
    },
    top: {
        controller,
        action: 'top',
        type: RequestMethod.Get
    },
    reusability: {
        controller,
        action: 'reusability',
        type: RequestMethod.Get
    },
    averageCost: {
        controller,
        action: 'average-cost',
        type: RequestMethod.Get
    },
    deliveryDuration: {
        controller,
        action: 'delivery-duration',
        type: RequestMethod.Get
    },
    tracking: {
        controller,
        action: 'demand-order-tracking',
        type: RequestMethod.Get
    },
    trackingYear:{
        controller,
        action: 'demand-order-tracking/year',
        type: RequestMethod.Get
    }
}
