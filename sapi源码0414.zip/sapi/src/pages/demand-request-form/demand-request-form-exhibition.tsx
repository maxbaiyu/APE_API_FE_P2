import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    Modal,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button,
    message
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { DemandService } from '~/services/demand.service'
import { ApiService } from '~/services/api.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import moment from 'moment'
import NotificationContainer from '~/shared/components/notification-container'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { isNullOrUndefined } from 'util'
import { rulesdata } from '~/assets/regular/rest'
import debounce from 'lodash/debounce'
import { values } from 'ramda'
import { LeftSquareOutlined } from '@ant-design/icons'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface DemandRequestFormDetailTWOState {
    demandId: string
    data: any
    reviewModalVisible: boolean
    successModalVisible: boolean
    discharge: boolean
    discharge2: boolean
    countryData: any[]
    featureData: any[]
    serviceData: any[]
    hover: boolean
    fieldsValues: any
    pathName: string
    ApproveBoolean: boolean
    searchParams: string

    inputType: string
    versionData: any[]
    searchData: any[]
    hoverDemand: boolean
    demandModalVisible: boolean
}

interface DemandRequestFormDetailTWOProps {}

const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})

export default class DemandRequestFormDetailTWO extends Component<
    RouteComponentProps<DemandRequestFormDetailTWOProps>,
    DemandRequestFormDetailTWOState
> {
    private dataFromRef!: React.RefObject<DataForm>
    private dataFrom1Ref!: React.RefObject<DataForm>
    private dataFrom2Ref!: React.RefObject<DataForm>
    private demandFromRef!: React.RefObject<DataForm>

    private demandService = new DemandService()
    private apiSevice = new ApiService()
    private dictUtil = new DictUtil()
    private actionFormRef!: React.RefObject<DataForm>
    private statusType = ''
    private demandStatus = ''
    private demandIdSure = ''

    private backEndSystem = ''
    private apiCatalogueId = ''
    private apiName = ''
    private reuseAPIVersion = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.dataFrom1Ref = React.createRef()
        this.dataFrom2Ref = React.createRef()
        this.actionFormRef = React.createRef()
        this.demandFromRef = React.createRef()

        this.state = {
            demandId: '',
            data: {},
            discharge: true,
            discharge2: true,
            hover: false,
            reviewModalVisible: false,
            successModalVisible: false,
            demandModalVisible: false,
            countryData: [],
            featureData: [],
            serviceData: [],
            fieldsValues: {},
            pathName: '',
            ApproveBoolean: true,
            searchParams: '',

            inputType: '01',
            searchData: [],
            versionData: [],
            hoverDemand: false
        }
    }
    public componentDidMount() {
        try {
            const { demandId } = this.props.location
                .state as DemandRequestFormDetailTWOState
            this.demandIdSure = demandId
        } catch (error) {
            const searchArr = this.props.location.search.split('=')
            if (searchArr && searchArr.length >= 1) {
                this.demandIdSure = searchArr[1]
            }
        }
        this.demandService
            .get(new RequestParams({}, { append: [this.demandIdSure] }))
            .subscribe(data => {
                this.setState({
                    data: data
                })
                this.dataForm.formInstance.setFieldsValue({
                    ...data,
                    targetLiveDate:
                        isNullOrUndefined(data.targetLiveDate) ||
                        data.targetLiveDate === ''
                            ? ''
                            : moment(data.targetLiveDate),
                    receivedDate:
                        isNullOrUndefined(data.receivedDate) ||
                        data.receivedDate === ''
                            ? ''
                            : moment(data.receivedDate)
                })
                this.dataForm1.formInstance.setFieldsValue({
                    ...data,
                    designReviewDate:
                        isNullOrUndefined(data.designReviewDate) ||
                        data.designReviewDate === ''
                            ? ''
                            : moment(data.designReviewDate)
                })
                this.dataForm2.formInstance.setFieldsValue({
                    ...data,
                    targetDateOfNextMilestone:
                        isNullOrUndefined(data.targetDateOfNextMilestone) ||
                        data.targetDateOfNextMilestone === ''
                            ? ''
                            : moment(data.targetDateOfNextMilestone),
                    targetOverallDelivery:
                        isNullOrUndefined(data.targetOverallDelivery) ||
                        data.targetOverallDelivery === ''
                            ? ''
                            : moment(data.targetOverallDelivery)
                })
            })
    }
    private openedit(reopenJumpParams?: any) {
        const { data } = this.state
        const { demandStatus } = data
        // const ids  = this.props.location.state as DemandRequestFormDetailTWOState
        this.props.history.push({
            pathname: '/pages/demand-request-form-detail',
            // pathname: '/pages/demand-request-form-exhibition',
            state: {
                demandId: this.demandIdSure,
                demandStatusid: demandStatus,
                reopenJumpParams
            },
            search: `demandId=${this.demandIdSure}&demandStatusid=${demandStatus}`
        })
    }

    private reopenJumpToDetail() {
        const demandFormValue = this.demandForm.formInstance.getFieldsValue()
        const {
            reuseAPIVersion,
            apiType,
            backEndSystem,
            demandClassification
        } = demandFormValue
        delete demandFormValue.reuseAPIVersion
        this.openedit({
            demandClassification,
            backEndSystem,
            apiName: this.apiName,
            apiType,
            reuseApiVersionId: reuseAPIVersion?.value,
            reuseApiVersion: reuseAPIVersion?.label,
            apiCatalogueId: this.apiCatalogueId,
            reopenStatus: '1'
        })
        this.closeDemanRequestForm()
    }

    private vertityFileds() {
        this.demandForm?.formInstance?.validateFields().then(() => {
            const { inputType, data } = this.state
            const { apiName, backEndSystem } = data
            if ((apiName !== this.apiName || backEndSystem !== this.backEndSystem) && (inputType === '01' || inputType === '02')) {
                this.apiSevice
                    .checking(
                        new RequestParams(
                            { backEndSystem: this.backEndSystem },
                            { append: [this.apiName] }
                        )
                    )
                    .subscribe(data => {
                        if (data.status === 1) {
                            this.reopenJumpToDetail()
                        } else {
                            message.error('Api Name error')
                        }
                    })
            } else {
                this.reopenJumpToDetail()
            }
        })
    }

    private onSearch(value) {
        if (value !== '') {
            this.apiSevice
                .getApiListByName(
                    new RequestParams(
                        { backEndSystem: this.backEndSystem },
                        { append: [value] }
                    )
                )
                .subscribe(data => {
                    this.setState({
                        searchData: data
                    })
                })
        }
    }

    private reopenDemanRequestForm(currentDemandClassification?: string) {
        const { data } = this.state
        if (data && typeof data == 'object') {
            const {
                demandClassification = '',
                backEndSystem = '',
                apiName = null,
                apiType = '',
                reuseAPIVersion = '',
                reuseAPIVersionId = '',
                apiCatalogueId = ''
            } = data
            this.apiName = apiName
            this.apiCatalogueId = apiCatalogueId
            this.backEndSystem = backEndSystem
            const currentDemand =
                currentDemandClassification || demandClassification
            const newDemandValueArr = ['01', '02']
            const replaceDemandValueArr = ['03', '04', '05']
            let apiNameValue
            let searchData: any[] = []
            let apiTypeValue: any = apiType
            if (
                newDemandValueArr.includes(demandClassification) &&
                newDemandValueArr.includes(currentDemand)
            ) {
                apiNameValue = apiName
            } else if (
                replaceDemandValueArr.includes(demandClassification) &&
                replaceDemandValueArr.includes(currentDemand)
            ) {
                apiNameValue = {
                    key: apiCatalogueId,
                    value: apiCatalogueId,
                    label: apiName
                }
                searchData = [
                    {
                        apiCatalogueId,
                        apiName,
                        apiType,
                        versionList: []
                    }
                ]
            } else {
                apiNameValue = ''
                apiTypeValue = ''
                searchData = []
            }
            this.setState(
                {
                    demandModalVisible: true,
                    inputType: currentDemand,
                    searchData
                },
                () => {
                    this.demandForm?.formInstance?.setFieldsValue({
                        demandClassification: currentDemand,
                        backEndSystem,
                        apiName: apiNameValue,
                        apiType: apiTypeValue,
                        reuseAPIVersion: {
                            value: reuseAPIVersionId,
                            key: reuseAPIVersionId,
                            label: reuseAPIVersion
                        }
                    })
                }
            )
        } else {
            this.dataForm1.formInstance.resetFields([
                'apiName',
                'reuseAPIVersion',
                'backEndSystem',
                'apiType'
            ])
        }
    }

    private closeDemanRequestForm() {
        this.setState({
            demandModalVisible: false
        })
    }

    private renderDemandModal() {
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderModalTitle('Demand Request Form')}
                        visible={this.state.demandModalVisible}
                        okText="Next"
                        onOk={() => this.vertityFileds()}
                        onCancel={() => this.closeDemanRequestForm()}
                        width="800px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {this.renderStep1Container()}
                    </Modal>
                )}
            </Consumer>
        )
    }

    private renderStep1Container() {
        const { inputType, versionData, searchData, hoverDemand } = this.state
        let linkStyle
        let imgsrc = ''
        if (hoverDemand) {
            imgsrc = require('~/assets/images/qm.png')
            linkStyle = {
                display: 'block',
                position: 'absolute',
                right: -229,
                top: -20,
                width: 220,
                backgroundColor: '#fff',
                border: '1px solid #333333',
                padding: 10,
                fontSize: 12,
                color: '#333333',
                cursor: 'pointer'
            }
        } else {
            imgsrc = require('~/assets/images/Help.png')
            linkStyle = {
                display: 'none'
            }
        }
        return (
            <DataForm
                name="demo-form"
                column={1}
                labelCol={{ span: 7 }}
                labelAlign="left"
                formWidth={600}
                ref={this.demandFromRef}
            >
                <>
                    <Form.Item
                        name="demandClassification"
                        label="Demand Classification"
                        rules={[{ required: true }]}
                    >
                        <Select
                            style={{ width: 400 }}
                            onChange={(value: string) => {
                                this.setState({
                                    inputType: value,
                                    searchData: []
                                })
                                this.reopenDemanRequestForm(value)
                            }}
                        >
                            {this.dictUtil.dicts('api_classification', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            top: 4,
                            cursor: 'pointer',
                            zIndex: 999
                        }}
                        onClick={this.toggleHoverDemand}
                    >
                        <img
                            width="20"
                            // src={imgsrc}
                            src={imgsrc}
                        ></img>
                    </div>
                    <div
                        style={linkStyle}
                        onClick={() => {
                            window.open(
                                'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Terminology'
                            )
                        }}
                    >
                        <div
                            style={{
                                position: 'absolute',
                                width: 0,
                                height: 0,
                                top: '25px',
                                left: '-20px',
                                border: '10px solid transparent',
                                borderRightColor: '#333333'
                            }}
                        ></div>
                        <div
                            style={{
                                position: 'absolute',
                                width: 0,
                                height: 0,
                                top: '25px',
                                left: '-18px',
                                border: '10px solid transparent',
                                borderRightColor: '#fff',
                                zIndex: 99
                            }}
                        ></div>
                        Refer to Core Banking TRUE SAPI Terminology
                    </div>
                </>
                <Form.Item
                    name="backEndSystem"
                    label="Backend System"
                    rules={[{ required: true }]}
                >
                    <Select
                        style={{ width: 400 }}
                        onChange={(value: any) => {
                            this.backEndSystem = value
                            this.demandForm.formInstance.resetFields([
                                'apiName',
                                'reuseAPIVersion'
                            ])
                            this.setState({
                                searchData:[]
                            })
                        }}
                    >
                        {this.dictUtil.dicts('backend_system', dict => (
                            <Select.Option
                                key={dict.dirCode}
                                value={dict.dirCode}
                            >
                                {dict.dirName}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    name="apiName"
                    label="API Name"
                    rules={[
                        inputType === '01' || inputType === '02'
                            ? {
                                  required: true,
                                  message:
                                      'API Name can contain letters, numbers, spaces, and special character: -.',
                                  pattern: rulesdata.patternOne
                              }
                            : { required: true },
                            {
                                validator: (_, value) =>{
                                    if(inputType !== '01' && inputType !== '02'){
                                        const { data } = this.state
                                        if (
                                            (data.demandClassification ==
                                                '01' ||
                                                data.demandClassification ==
                                                    '02') &&
                                            data?.apiName == value.label
                                        ) {
                                            return Promise.reject(
                                                new Error('API Name repeat')
                                            )
                                        }
                                    }
                                    return Promise.resolve(true)
                                }
                            }
                    ]}
                >
                    {inputType === '01' || inputType === '02' ? (
                        <Input
                            onChange={e => {
                                this.apiName = e.target.value
                            }}
                            style={{ width: 400 }}
                        />
                    ) : (
                        <Select
                            style={{ width: 400 }}
                            showSearch
                            defaultActiveFirstOption={false}
                            showArrow={false}
                            filterOption={false}
                            onSearch={debounce(
                                value => this.onSearch(value),
                                200
                            )}
                            onChange={(value: any) => {
                                this.apiName = value.label
                                this.apiCatalogueId = value.value
                                this.demandForm.formInstance.resetFields([
                                    'reuseAPIVersion'
                                ])
                                const selectedRow = searchData.filter(
                                    x => x.apiCatalogueId === value.value
                                )
                                searchData.filter(x => {
                                    if (this.apiName == x.apiName) {
                                        this.demandForm.formInstance.setFieldsValue(
                                            { apiType: x.apiType }
                                        )
                                    }
                                })
                                this.setState({
                                    versionData: selectedRow[0].versionList
                                })
                            }}
                            notFoundContent={null}
                            labelInValue
                        >
                            {searchData.map(x => (
                                <Select.Option
                                    key={x.apiCatalogueId}
                                    value={x.apiCatalogueId}
                                >
                                    {x.apiName}
                                </Select.Option>
                            ))}
                        </Select>
                    )}
                </Form.Item>
                <a
                    href="https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Naming+Convention"
                    target="_blank"
                    style={{
                        position: 'absolute',
                        left: '600px',
                        top: '-45px',
                        cursor: 'pointer',
                        width: '200px',
                        textDecoration: 'underline'
                    }}
                >
                    API Naming Standard
                </a>
                <Form.Item
                    name="apiType"
                    label="API Type"
                    rules={[{ required: true }]}
                >
                    <Select style={{ width: 400 }}>
                        {this.dictUtil.dicts('api_type', dict => (
                            <Select.Option
                                key={dict.dirCode}
                                value={dict.dirCode}
                            >
                                {dict.dirName}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    name="reuseAPIVersion"
                    label="Reused API Version"
                    // rules={[{ required: true }]}
                    style={styles().input(
                        inputType !== '01' && inputType !== '02'
                    )}
                >
                    <Select
                        style={{ width: 400 }}
                        labelInValue
                        onChange={(value: any) => {
                            versionData.forEach(x => {
                                if (
                                    x.designReviewStatus !== '4' &&
                                    x.versionId == value?.value
                                ) {
                                    message.warning(
                                        "There's a reused version is under review, please contact " +
                                            x?.cbSysContact +
                                            ' or ' +
                                            x?.createByAccName +
                                            ' to get align on the API version.'
                                    )
                                }
                            })
                        }}
                    >
                        {versionData.map(x => (
                            <Select.Option
                                key={x.versionId}
                                value={x.versionId}
                            >
                                {x.version}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
            </DataForm>
        )
    }

    private toggleHoverDemand = () => {
        this.setState({
            hoverDemand: !this.state.hoverDemand
        })
    }

    private openReviewModal() {
        this.setState({
            reviewModalVisible: true
        })
    }
    private toggleHover = () => {
        this.setState({
            hover: !this.state.hover
        })
    }

    public render() {
        const {
            discharge,
            discharge2,
            data,
            countryData,
            featureData,
            serviceData
        } = this.state
        let demandStatusButton
        var linkStyle
        var imgsrc = ''
        if (this.state.hover) {
            imgsrc = require('~/assets/images/qm.png')
            linkStyle = {
                display: 'block',
                position: 'absolute',
                left: '24em',
                top: '-1em',
                width: '42.3em',
                height: '5.83em',
                backgroundColor: '#fff',
                border: '1px solid #333333',
                padding: 15,
                fontSize: '0.85714em',
                color: '#333333',
                cursor: 'pointer',
                zIndex: 999
            }
        } else {
            imgsrc = require('~/assets/images/Help.png')
            linkStyle = {
                display: 'none'
            }
        }

        return (
            <components.PageContainer
                title="Demand Request Detail"
                noHeader={true}
                isNotNeedFlex={true}
                isNeedCenter={true}
            >
                <div
                    // className="flex-row justify-content-end"
                    className="flex-row justify-content-between align-items-center"
                >
                    <div style={{ fontSize: 28, marginLeft: 20 }}>
                        {data.apiName}
                    </div>
                    <div>
                        <components.AuthDisableButton
                            auth={['ROLE_01', 'ROLE_02']}
                            type="primary"
                            //size="large"
                            style={{
                                marginRight: 20
                            }}
                            onClick={() => {
                                this.reopenDemanRequestForm()
                            }}
                        >
                            Reopen
                        </components.AuthDisableButton>
                        <components.AuthDisableButton
                            auth={['ROLE_01']}
                            type="primary"
                            //size="large"
                            style={{
                                marginRight: 20
                            }}
                            onClick={() => {
                                this.openedit()
                            }}
                        >
                            Edit
                        </components.AuthDisableButton>
                        <Button
                            //size="large"
                            onClick={() => {
                                // this.props.history.goBack()
                                try {
                                    const {
                                        fieldsValues = {},
                                        pathName = '',
                                        demandId,
                                        searchParams
                                    } = this.props.location
                                        .state as DemandRequestFormDetailTWOState
                                    if (pathName) {
                                        this.props.history.push({
                                            pathname: pathName,
                                            state: {
                                                fieldsValues
                                            },
                                            search: searchParams
                                        })
                                    } else {
                                        this.props.history.goBack()
                                    }
                                } catch (error) {
                                    this.props.history.goBack()
                                }
                            }}
                        >
                            Back
                        </Button>
                    </div>
                </div>
                {this.renderDemandModal()}
                {/* <Divider /> */}
                <CardContainer title="Demand Governance">
                    <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="API Name">
                            <Button
                                type="link"
                                className="text-left"
                                style={{
                                    ...styles().input(
                                        data.apiCatalogueId != null
                                    ),
                                    padding: 0,
                                    height: 'initial'
                                }}
                                onClick={() =>
                                    this.openForm(data.apiCatalogueId)
                                }
                            >
                                {data.apiName}
                            </Button>
                            <div
                                style={{
                                    ...styles().input(
                                        data.apiCatalogueId === null
                                    ),
                                    padding: 0
                                }}
                            >
                                {data.apiName}
                            </div>
                        </LabelItem>
                        <LabelItem label="Entry Created Date">
                            {data.createDate}
                        </LabelItem>
                        <LabelItem label="Project Name">
                            {data.projectName}
                        </LabelItem>
                        <LabelItem label="Demand Creator">
                            {data.createByAccName}
                        </LabelItem>
                        <LabelItem label="Order Received Date">
                            {data.receivedDate}
                        </LabelItem>
                        <LabelItem label="Region">
                            {/* {data.region} */}
                            {this.dictUtil.filter('region', data.region)}
                            {/* {dict.dirName} */}
                        </LabelItem>
                        <LabelItem label="Requester">
                            {data.requester}
                        </LabelItem>
                        <LabelItem label="Site">
                            {/* {data.country} */}
                            {this.dictUtil.filter(data.region, data.country)}
                        </LabelItem>
                        <LabelItem label="Core Banking API Contact">
                            {/* {data.cbApiContact} */}
                            {this.dictUtil.filter(
                                'cb_api_contact',
                                data.cbApiContact
                            )}
                        </LabelItem>
                        <LabelItem label="Backend System">
                            {/* {data.backEndSystem} */}
                            {this.dictUtil.filter(
                                'backend_system',
                                data.backEndSystem
                            )}
                        </LabelItem>
                        <LabelItem label="Core Banking System Contact">
                            {/* {data.cbSysContact} */}
                            {this.dictUtil.filter(
                                'cb_system_contact',
                                data.cbSysContact
                            )}
                        </LabelItem>
                        <LabelItem label="Channel">
                            {/* {data.channel} */}
                            {this.dictUtil.filter('channel', data.channel)}
                        </LabelItem>
                        <LabelItem label="Total API L0 Estimates">
                            {'$ ' + data.totalApiL0Estimates + 'K (USD)'}
                            {/* {this.dictUtil.filter(
                                'channel',
                                data.totalApiL0Estimates
                            )} */}
                        </LabelItem>
                        <LabelItem label="GB/GF">
                            {/* {data.gbOrGF} */}
                            {this.dictUtil.filter('gb_gf', data.gbOrGF)}
                        </LabelItem>
                        <LabelItem label="Mule API L0 Estimates">
                            {'$ ' + data.ossApiL0Estimates + 'K (USD)'}
                        </LabelItem>
                        <LabelItem label="Demand Classification">
                            {/* {data.demandClassification} */}
                            {this.dictUtil.filter(
                                'api_classification',
                                data.demandClassification
                            )}
                        </LabelItem>
                        <LabelItem label="CB System L0 Estimates">
                            {'$ ' + data.cbSystemL0Estimates + 'K (USD)'}
                        </LabelItem>
                        <LabelItem label="API Lifecycle Stage">
                            {/* {data.apiLifecycleStage} */}
                            {this.dictUtil.filter(
                                'api_lifecycle_stage',
                                data.apiLifecycleStage
                            )}
                        </LabelItem>
                        <LabelItem label="BPID">
                            {/* {data.gdpmInterLockBpid} */}
                            <Button
                                type="link"
                                className="text-left"
                                onClick={() => this.openBPidLink(data)}
                                style={{ padding: 0, height: 'initial' }}
                                // appConfig.server +'/demand/export','API-Demand-Request-List.xls',
                            >
                                {data.gdpmInterLockBpid}
                            </Button>
                        </LabelItem>
                        <LabelItem label="Target Live Date">
                            {data.targetLiveDate}
                        </LabelItem>
                        <LabelItem label="Consumer">{data.consumer}</LabelItem>
                        <LabelItem label="Clarity ID">
                            {data.clarityId}
                        </LabelItem>
                        <LabelItem label="Remarks">
                            <div
                                style={{
                                    wordWrap: 'break-word',
                                    wordBreak: 'break-word',
                                    width: '25em'
                                }}
                            >
                                {data.demandRemarks}
                            </div>
                        </LabelItem>
                    </LabelContainer>
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                    ></DataForm>
                    {this.renderDemandApprovalViewBox()}
                </CardContainer>
                <CardContainer title=" Design Governance">
                    <div
                        style={{
                            position: 'absolute',
                            left: '18.3em',
                            top: '0.6em',
                            cursor: 'pointer',
                            zIndex: 1000
                        }}
                        onClick={this.toggleHover}
                    >
                        <img width="20" src={imgsrc}></img>
                    </div>
                    <div
                        style={linkStyle}
                        onClick={() => {
                            // window.open(
                            //     'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Terminology'
                            // )
                        }}
                    >
                        <div
                            style={{
                                position: 'absolute',
                                width: 0,
                                height: 0,
                                top: '2.1em',
                                left: '-1.67em',
                                border: '10px solid transparent',
                                borderRightColor: '#333333'
                            }}
                        ></div>
                        <div
                            style={{
                                position: 'absolute',
                                width: 0,
                                height: 0,
                                top: '2.1em',
                                left: '-1.5em',
                                border: '10px solid transparent',
                                borderRightColor: '#fff',
                                zIndex: 99
                            }}
                        ></div>
                        Refer to Review Request Form. All information in Design
                        Governance is required to be entered form Design Review
                        Request Form.
                    </div>
                    <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="Capability">
                            {/* {data.capability} */}
                            {this.dictUtil.filter(
                                'capability',
                                data.capability
                            )}
                        </LabelItem>
                        <LabelItem label="API ID">{data.trueSapiId}</LabelItem>
                        <LabelItem label="Feature">
                            {/* {data.feature} */}
                            {this.dictUtil.filter(
                                data.capability,
                                data.feature
                            )}
                        </LabelItem>
                        <LabelItem label="Original API ID">
                            {data.originalSapiId}
                        </LabelItem>
                        <LabelItem label="Service">
                            {/* {data.service} */}
                            {this.dictUtil.filter(data.feature, data.service)}
                        </LabelItem>
                        {/* <LabelItem label="Multiple Country">
                            {data.multiCountry}
                        </LabelItem> */}
                        <LabelItem label="Platform">
                            {/* {data.platform}*/}
                            {this.dictUtil.filter('platform', data.platform)}
                        </LabelItem>
                        <LabelItem label="Reusability Score">
                            {/* {data.reusabilityScore} */}
                            {this.dictUtil.filter(
                                'reusability_score',
                                data.reusabilityScore
                            )}
                        </LabelItem>
                        <LabelItem label="Channel Agnostic">
                            {/* {data.channelAgnostic} */}
                            {this.dictUtil.filter(
                                'channel_agnostic',
                                data.channelAgnostic
                            )}
                        </LabelItem>
                        <LabelItem label="Design Review Approval Status">
                            {/* {data.designReviewStatus} */}
                            <Button
                                type="link"
                                disabled={!data.reviewId}
                                className="text-left"
                                style={{ padding: 0, height: 'initial' }}
                                onClick={() =>
                                    this.openReviewForm(data.reviewId)
                                }
                            >
                                {this.dictUtil.filter(
                                    'demand_status',
                                    data.designReviewStatus
                                )}
                            </Button>
                        </LabelItem>
                        <LabelItem label="API Type">
                            {/* {data.apiType} */}
                            {this.dictUtil.filter('api_type', data.apiType)}
                        </LabelItem>
                        <LabelItem label="Design Review Approval Date">
                            {data.designReviewDate}
                        </LabelItem>
                        <LabelItem label="Applicable Channels">
                            {this.dictUtil.filter(
                                'applicable_channels',
                                data?.applicableChannels
                            )}
                            {data?.applicableChannels2 != null &&
                                data?.applicableChannels2 != '' &&
                                ' - ' + data?.applicableChannels2}
                        </LabelItem>
                        <LabelItem label="Applicable GB/GF">
                            {this.dictUtil.filter(
                                'applicable_gb',
                                data?.applicableGbGf
                            )}
                            {data?.applicableGbGf2 != null &&
                                data?.applicableGbGf2 != '' &&
                                ' - ' + data?.applicableGbGf2}
                        </LabelItem>
                        <LabelItem label="Applicable Countries">
                            {this.dictUtil.filter(
                                'applicable_countries',
                                data?.applicableCountries
                            )}
                            {data?.applicableCountries2 != null &&
                                data?.applicableCountries2 != '' &&
                                ' - ' + data?.applicableCountries2}
                        </LabelItem>
                        <LabelItem label="Remarks">
                            <div
                                style={{
                                    wordWrap: 'break-word',
                                    wordBreak: 'break-word',
                                    width: '25em'
                                }}
                            >
                                {data.designRemarks}
                            </div>
                        </LabelItem>
                    </LabelContainer>
                    <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom1Ref}
                    ></DataForm>

                    {this.renderDesignApprovalViewBox()}
                    {this.renderModal()}
                    {this.renderReviewModal()}
                </CardContainer>
                {/* <Divider /> */}
                <CardContainer title="Other Information">
                    <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="Target Date of Next Milestone">
                            {data.targetDateOfNextMilestone}
                        </LabelItem>
                        <LabelItem label="Target Overall Delivery">
                            {data.targetOverallDelivery}
                        </LabelItem>
                        <LabelItem label="Next Miletone RAG Status">
                            {data.nextMiletoneRagStatus}
                        </LabelItem>
                        <LabelItem label="Overall Delivery RAG Status">
                            {data.overallDeliveryRagStatus}
                        </LabelItem>
                    </LabelContainer>
                    <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom2Ref}
                    ></DataForm>
                </CardContainer>
            </components.PageContainer>
        )
    }
    private openBPidLink(data) {
        if (data.gdpmInterLockBpidYear !== null) {
            let linkYear = data.gdpmInterLockBpidYear.substring(
                data.gdpmInterLockBpidYear.length - 2
            )
            window.location.href =
                'https://planningdatamodel.it.global.hsbc/gpdm' +
                linkYear +
                '/billableProduct.asp?bpID=' +
                data.gdpmInterLockBpid
        }
    }
    private renderDemandApprovalViewBox() {
        const { data } = this.state
        const { demandStatus } = data

        let theme: any
        switch (demandStatus) {
            case '4':
                theme = 'approved'
                break
            case '5':
                theme = 'rejected'
                break
            case '1':
                theme = 'inProgress'
                break
            default:
                theme = 'verify'
                break
        }
        return (
            <NotificationContainer
                className="padding-y"
                title="Demand Approval"
                theme={theme}
                status={demandStatus}
            >
                <div
                    style={{
                        ...styles().input(
                            demandStatus == 4 || demandStatus == 5
                        )
                    }}
                >
                    <LabelContainer column={1} labelSpan={3}>
                        <LabelItem label="Reviewer:">
                            {data.demandCommentApprover}
                        </LabelItem>
                        <LabelItem label="Operation Date:">
                            {data.demandDate}
                        </LabelItem>
                        <LabelItem label="Comments:">
                            {data.demandCommentDesc}
                        </LabelItem>
                    </LabelContainer>
                </div>
                <div className="flex-row justify-content-end">
                    <div
                        style={{
                            padding: '0 1em 1em'
                        }}
                    >
                        <components.AuthDisableButton
                            type="primary"
                            htmlType="submit"
                            className="submit-button"
                            danger
                            //size="large"
                            onClick={() => {
                                this.statusType = 'DEMAND'
                                this.demandStatus = '4'
                                this.openReviewModal()
                                this.setState({
                                    ApproveBoolean: false
                                })
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(data.demandStatus == '3')
                            }}
                        >
                            Approve
                        </components.AuthDisableButton>
                    </div>
                    <div
                        style={{
                            padding: '0 1em 1em'
                        }}
                    >
                        <components.AuthDisableButton
                            className="submit-button"
                            //size="large"
                            onClick={() => {
                                this.statusType = 'DEMAND'
                                this.demandStatus = '5'
                                this.openReviewModal()
                                this.setState({
                                    ApproveBoolean: true
                                })
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(demandStatus == '3'),
                                width: 100
                            }}
                        >
                            Reject
                        </components.AuthDisableButton>
                    </div>
                </div>
            </NotificationContainer>
        )
    }

    private renderDesignApprovalViewBox() {
        const { data } = this.state
        const { demandStatus, designStatus } = data
        let theme: any
        switch (designStatus) {
            case '4':
                theme = 'approved'
                break
            case '5':
                theme = 'rejected'
                break
            case '1':
                theme = 'inProgress'
                break
            default:
                theme = 'verify'
                break
        }

        return (
            <NotificationContainer
                className="padding-y"
                title="Design Approval"
                theme={theme}
                status={designStatus}
            >
                <div
                    style={{
                        ...styles().input(
                            designStatus == 4 || designStatus == 5
                        )
                    }}
                >
                    <LabelContainer column={1} labelSpan={3}>
                        <LabelItem label="Reviewer:">
                            {data.designCommentApprover}
                        </LabelItem>
                        <LabelItem label="Operation Date:">
                            {data.designDate}
                        </LabelItem>
                        <LabelItem label="Comments:">
                            {data.designCommentDesc}
                        </LabelItem>
                    </LabelContainer>
                </div>
                <div className="flex-row justify-content-end">
                    <div
                        style={{
                            padding: '0 1em 1em'
                        }}
                    >
                        <components.AuthDisableButton
                            type="primary"
                            htmlType="submit"
                            className="submit-button"
                            danger
                            //size="large"
                            onClick={() => {
                                this.statusType = 'DESIGN'
                                this.demandStatus = '4'
                                this.openReviewModal()
                                this.setState({
                                    ApproveBoolean: false
                                })
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(
                                    demandStatus == 4 && designStatus == 3
                                )
                            }}
                        >
                            Approve
                        </components.AuthDisableButton>
                    </div>
                    <div
                        style={{
                            padding: '0 1em 1em'
                        }}
                    >
                        <components.AuthDisableButton
                            className="submit-button"
                            //size="large"
                            onClick={() => {
                                this.statusType = 'DESIGN'
                                this.demandStatus = '5'
                                this.openReviewModal()
                                this.setState({
                                    ApproveBoolean: true
                                })
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(
                                    demandStatus == 4 && designStatus == 3
                                ),
                                width: 100
                            }}
                        >
                            Reject
                        </components.AuthDisableButton>
                    </div>
                </div>
            </NotificationContainer>
        )
    }
    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    private get dataForm1(): DataForm {
        return this.dataFrom1Ref.current as DataForm
    }
    private get dataForm2(): DataForm {
        return this.dataFrom2Ref.current as DataForm
    }
    private get demandForm(): DataForm {
        return this.demandFromRef.current as DataForm
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand Detail -->"
                cancelText="Close"
                content="Check Status in Demand Detail Page."
                onOk={() => {
                    this.closeSuccessModal()
                    this.componentDidMount()
                    // this.props.history.push('/pages/api-demand-request-list')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private renderModalTitle(title) {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275
                    }}
                >
                    {title}
                </div>
            </div>
        )
    }
    private renderReviewModal() {
        const { ApproveBoolean } = this.state
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderModalTitle('Verification')}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {/* {(this.staffId = userStore.state.staffId)} */}
                        <div
                            style={{
                                color: '#333333',
                                fontSize: '1em',
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFormRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        Governance Group
                                    </LabelItem>
                                </LabelContainer>

                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[
                                        {
                                            type: 'string',
                                            max: 200,
                                            message:
                                                'the length of approve comment should less then 200'
                                        }
                                    ]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private submitAction(staffId) {
        const { data } = this.state
        this.actionForm.formInstance.validateFields().then((...data1) => {
            this.demandService
                .status(
                    new RequestParams({
                        apiDemandIdList: [data.demandId],
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        status: this.demandStatus,
                        statusType: this.statusType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }
    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }

    private get actionForm(): DataForm {
        return this.actionFormRef.current as DataForm
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                apiCatalogueId
            },
            search: `apiCatalogueId=${apiCatalogueId}`
        })
    }
    private openReviewForm(reviewId = '') {
        this.props.history.push({
            pathname: '/pages/review-request-form',
            state: {
                reviewId
            },
            search: `reviewId=${reviewId}`
        })
    }
    private discharge() {
        const { data } = this.state
        if (
            data.demandStatus == '3' ||
            data.demandStatus == '2' ||
            data.demandStatus == '1'
        ) {
            this.setState({
                discharge: false
            })
            if (data.demandClassification == '01') {
                this.setState({
                    discharge2: false
                })
            }
        }
    }
}
