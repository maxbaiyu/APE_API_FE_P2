export interface TodolistDatas {
    title: String
    apiName: String
    projectName: String
    messagePrefix?: String
    message?: String
    functionType: String
    demandId?: Number
    reviewId?: Number
    operator?: String
    operatingTime?: String
    taskStatus?: String
    avatarSrc?: any
}


export interface NotificationDatas {
    title: String
    apiName: String
    projectName?: String
    message?: String
    operator?: String
    operatingTime?: String
    messagePrefix?: String
}