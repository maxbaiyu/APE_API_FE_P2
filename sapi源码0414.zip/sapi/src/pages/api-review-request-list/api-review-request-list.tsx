import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import DataTable from '~/shared/components/data-table'
import Column from 'antd/lib/table/Column'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { Form, Input, Select, DatePicker, Button, Modal, message } from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import CustomizeModal from '~/shared/components/customize-modal'
import { ReviewService } from '~/services/review.service'
import { PageService } from '~/bootstrap/services/page.service'
import { RequestParams } from '~/core/http'
import { UserStore } from '~/store/user.store'
import { download } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'
import { Consumer } from 'reto'
import { DictUtil } from '~/shared/utils/dict.util'
import { dataConvert } from '~/shared/utils/form.data.convert'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { SortService } from '~/bootstrap/services/sort.service'
import ColumnGroup from 'antd/lib/table/ColumnGroup'
import { layOutSize } from '~/shared/utils/common.util'
const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface APIReviewRequestListState {
    dataSource: any[]
    inputType: string
    selectedRowKeys: any[]
    successModalVisible: boolean
    reviewModalVisible: boolean
    fieldsValues: any
    Loading: boolean
    ApproveBoolean: boolean
    countryData: any[]
}

interface APIReviewRequestListProps {}

export default class APIReviewRequestList extends Component<
    RouteComponentProps<APIReviewRequestListProps>,
    APIReviewRequestListState
> {
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private searchFormRef!: React.RefObject<DataForm>
    private reivewStatus = ''
    private statusType = ''
    private reviewService = new ReviewService()
    private pageService = new PageService()
    private sortService = new SortService({
        createDate: 'DESC'
    })
    private homePageJumpSearch = ''

    public componentDidMount() {
        const state = this.props.location.state as APIReviewRequestListState
        if (state && state.fieldsValues) {
            const fieldsValues = dataConvert(true, state.fieldsValues)
            this.searchForm.formInstance.setFieldsValue(fieldsValues)
        }
        if (this.props?.location?.search) {
            this.homePageJumpSearch = this.props.location.search.replace(
                '?',
                ''
            )
        }
        this.getreviewList()
    }

    constructor(props) {
        super(props)
        this.actionFromRef = React.createRef()
        this.searchFormRef = React.createRef()
        this.state = {
            inputType: '01',
            dataSource: [],
            selectedRowKeys: [],
            successModalVisible: false,
            reviewModalVisible: false,
            Loading: true,
            fieldsValues: {},
            ApproveBoolean: true,
            countryData: []
        }
    }

    public render() {
        const { dataSource, selectedRowKeys, Loading } = this.state
        const { Option } = Select
        const { RangePicker } = DatePicker
        return (
            <components.PageContainer title="API Design Review List" noHeader={true}>
                <CardContainer title="Search">
                    <DataForm
                        name="filter-data-form"
                        column={3}
                        labelCol={{ span: 10 }}
                        labelAlign="left"
                        actions={this.renderFormAction()}
                        ref={this.searchFormRef}
                    >
                        <DataForm.Item name="projectName" label="Project Name">
                            <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item name="apiName" label="API Name">
                            <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item name="apiId" label="API ID">
                            <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="targetLiveDate"
                            label="Target Live Date"
                            className="range-picker"
                        >
                            <RangePicker />
                        </DataForm.Item>

                        <DataForm.Item
                            name="demandClassification"
                            label="Demand Classification"
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'api_classification',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="createDate"
                            label="Entry Created Date"
                            className="range-picker"
                        >
                            <RangePicker />
                        </DataForm.Item>
                        <DataForm.Item name="region" label="Region">
                            <Select
                                allowClear
                                onChange={value => {
                                    const countries = this.dictUtil.dicts(value)
                                    this.setState({
                                        countryData: countries
                                    })
                                    this.searchForm.formInstance.resetFields([
                                        'country'
                                    ])
                                }}
                            >
                                {this.dictUtil.dicts('region', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>

                        <DataForm.Item
                            name="backEndSystem"
                            label="Backend System"
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts('backend_system', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="demandApprovalStatus"
                            label="Demand Approval Status"
                            initialValue=""
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts('demand_status', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>

                        {/* <DataForm.Item name="country" label="Site" collapse>
                            <Select allowClear>
                                {this.dictUtil.dicts('country', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item> */}
                        <DataForm.Item name="country" label="Site" collapse>
                            <Select allowClear>
                                {this.state.countryData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="requester"
                            label="Requester"
                            collapse
                        >
                            <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="designApprovalStatus"
                            label="Design Approval Status"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts('demand_status', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="rdrReviewStatus"
                            label="Regional Review Status"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'design_review_status',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="gbdrReviewStatus"
                            label="Global Business Status"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'design_review_status',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="gtdrReviewStatus"
                            label="Global Technical Status"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'design_review_status',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="rdrReviewDate"
                            label="Regional Review Date"
                            className="range-picker"
                            collapse
                        >
                            <RangePicker />
                        </DataForm.Item>
                        <DataForm.Item
                            name="gbdrReviewDate"
                            label="Global Business Date"
                            className="range-picker"
                            collapse
                        >
                            <RangePicker />
                        </DataForm.Item>

                        <DataForm.Item
                            name="gtdrReviewDate"
                            label="Global Technical Date"
                            className="range-picker"
                            collapse
                        >
                            <RangePicker />
                        </DataForm.Item>
                        <DataForm.Item
                            name="rdrReviewer"
                            label="Regional Reviewer"
                            initialValue=""
                            collapse
                        >
                           <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="gbdrCbReviewer"
                            label="Global Business CB Reviewer"
                            initialValue=""
                            collapse
                        >
                           <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="gtdrCbReviewer"
                            label="Global Technical CB Reviewer"
                            initialValue=""
                            collapse
                        >
                           <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="apiLifecycleStage"
                            label="API Lifecycle Stage"
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'api_lifecycle_stage',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="gbdrApiReviewer"
                            label="Global Business API Reviewer"
                            collapse
                        >
                           <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="gtdrApiReviewer"
                            label="Global Technical API Reviewer"
                            collapse
                        >
                            <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                    </DataForm>
                </CardContainer>
                <CardContainer title="API Design Review List">
                    <components.AuthDisableButton
                        auth={[
                            'ROLE_02',
                            'ROLE_03',
                            'ROLE_04',
                            'ROLE_05',
                            'ROLE_06',
                            'ROLE_07',
                            'ROLE_08',
                            'ROLE_09'
                        ]}
                        //size="large"
                        style={{
                            marginTop: -55,
                            float: 'right'
                        }}
                        onClick={() => {
                            const formatDateRes = this.formatDate();

                            download(
                                appConfig.server + '/review/export',
                                'API-Review-Request-List.xls',
                                Object.assign(
                                    this.searchForm.formInstance.getFieldsValue(),
                                    formatDateRes
                                )
                            )
                        }}
                    >
                        Export
                    </components.AuthDisableButton>
                    <DataTable
                        rowKey="reviewId"
                        dataSource={dataSource}
                        page={this.pageService}
                        loading={Loading}
                        onPageChange={() => this.getreviewList()}
                        rowSelection={{
                            selectedRowKeys,
                            onChange: selectedRowKeys =>
                                this.setState({ selectedRowKeys })
                        }}
                        actions={this.renderTableAction()}
                        onChange={(pagination, filters, sorter) => {
                            if (sorter.order) {
                                this.sortService.update(
                                    sorter.columnKey,
                                    sorter.order
                                )
                            } else {
                                this.sortService.reset()
                            }
                            this.getreviewList()
                        }}
                    >
                        <ColumnGroup title="Basic Information" className="grey">
                            <Column
                                ellipsis={true}
                                title="API ID"
                                dataIndex="trueSapiId"
                                key="trueSapiId"
                                render={(text, row, index) => (
                                    // <Button
                                    //     type="link"
                                    //     onClick={() => this.openForm(row)}
                                    // >
                                    //     {text}
                                    // </Button>
                                    <a
                                        onClick={() => this.openForm(row)}
                                        style={{ width: '80px' }}
                                    >
                                        {text}
                                    </a>
                                )}
                                sorter
                            />

                            <Column
                                //width={280}
                                ellipsis={true}
                                title="API Name"
                                dataIndex="apiName"
                                key="apiName"
                                sorter
                                render={(text, row, index) => (
                                    // <Button
                                    //     type="link"
                                    //     onClick={() => this.openForm(row)}
                                    // >
                                    //     {text}
                                    // </Button>
                                    <a
                                        onClick={() => this.openForm(row)}
                                        style={{ width: '290px' }}
                                    >
                                        {text}
                                    </a>
                                )}
                            />
                            <Column
                                ellipsis={true}
                                title="Backend System"
                                dataIndex="backEndSystem"
                                key="backEndSystem"
                                render={value =>
                                    this.dictUtil.filter(
                                        'backend_system',
                                        value
                                    )
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Requester"
                                dataIndex="requester"
                                key="requester"
                            />
                            <Column
                                ellipsis={true}
                                title="Project Name"
                                dataIndex="projectName"
                                key="projectName"
                            />

                            <Column
                                title="Region"
                                dataIndex="region"
                                key="region"
                                ellipsis={true}
                                render={value =>
                                    this.dictUtil.filter('region', value)
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Site"
                                dataIndex="country"
                                key="country"
                                render={value =>
                                    this.dictUtil.filter('country', value)
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Demand Classification"
                                dataIndex="demandClassification"
                                key="demandClassification"
                                render={value =>
                                    this.dictUtil.filter(
                                        'api_classification',
                                        value
                                    )
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Entry Created Date"
                                dataIndex="createDate"
                                key="createDate"
                                sorter
                            />
                            <Column
                                title="Target Live Date"
                                dataIndex="targetLiveDate"
                                key="targetLiveDate"
                                ellipsis={true}
                                sorter
                            />
                            <Column
                                title="API Lifecycle Stage"
                                dataIndex="apiLifecycleStage"
                                key="apiLifecycleStage"
                                ellipsis={true}
                                render={value =>
                                    this.dictUtil.filter(
                                        'api_lifecycle_stage',
                                        value
                                    )
                                }
                            />
                        </ColumnGroup>
                        <ColumnGroup title="Regional Review" className="blue">
                            <Column
                                ellipsis={true}
                                title="Regional Review Status"
                                dataIndex="rdrReviewStatus"
                                key="rdrReviewStatus"
                                render={value =>
                                    this.dictUtil.filter(
                                        'design_review_status',
                                        value
                                    )
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Regional Review Date"
                                dataIndex="rdrReviewDate"
                                key="rdrReviewDate"
                                sorter
                            />
                            <Column
                                ellipsis={true}
                                title="Regional Reviewer"
                                dataIndex="rdrReviewer"
                                key="rdrReviewer"
                            />
                        </ColumnGroup>
                        <ColumnGroup
                            title="Global Business Review"
                            className="green"
                        >
                            <Column
                                ellipsis={true}
                                title="Global Business Status"
                                dataIndex="gbdrReviewStatus"
                                key="gbdrReviewStatus"
                                render={value =>
                                    this.dictUtil.filter(
                                        'design_review_status',
                                        value
                                    )
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Global Business Date"
                                dataIndex="gbdrReviewDate"
                                key="gbdrReviewDate"
                                sorter
                            />
                            <Column
                                ellipsis={true}
                                title="Global Business CB Reviewer"
                                dataIndex="gbdrCbReviewer"
                                key="gbdrCbReviewer"
                                render={(value, record: any) =>
                                    record.gbdrReviewerType == 'CB' ||
                                    record.gbdrReviewerType == ''
                                        ? record.gbdrCbReviewer
                                        : ''
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Global Business API Reviewer"
                                dataIndex="gbdrApiReviewer"
                                key="gbdrApiReviewer"
                                render={(value, record: any) =>
                                    record.gbdrReviewerType == 'API' ||
                                    record.gbdrReviewerType == ''
                                        ? record.gbdrApiReviewer
                                        : ''
                                }
                            />
                        </ColumnGroup>
                        <ColumnGroup
                            title="Global Technical Review"
                            className="purple"
                        >
                            <Column
                                ellipsis={true}
                                title="Global Technical Status"
                                dataIndex="gtdrReviewStatus"
                                key="gtdrReviewStatus"
                                render={value =>
                                    this.dictUtil.filter(
                                        'design_review_status',
                                        value
                                    )
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Global Technical Date"
                                dataIndex="gtdrReviewDate"
                                key="gtdrReviewDate"
                                sorter
                            />
                            <Column
                                ellipsis={true}
                                title="Global Technical CB Reviewer"
                                dataIndex="gtdrCbReviewer"
                                key="gtdrCbReviewer"
                                render={(value, record: any) =>
                                    record.gtdrReviewerType == 'CB' ||
                                    record.gtdrReviewerType == ''
                                        ? record.gtdrCbReviewer
                                        : ''
                                }
                            />
                            <Column
                                ellipsis={true}
                                title="Global Technical API Reviewer"
                                dataIndex="gtdrApiReviewer"
                                key="gtdrApiReviewer"
                                render={(value, record: any) =>
                                    record.gtdrReviewerType == 'API' ||
                                    record.gtdrReviewerType == ''
                                        ? record.gtdrApiReviewer
                                        : ''
                                }
                            />
                        </ColumnGroup>
                    </DataTable>
                </CardContainer>
                {this.renderModal()}
                {this.renderReviewModal()}
            </components.PageContainer>
        )
    }

    private renderFormAction() {
        return (
            <Button type="primary" danger onClick={() => this.replacement()}>
                Search
            </Button>
        )
    }
    private renderTableAction() {
        return (
            <LabelContainer column={2} colon>
                <LabelContainer.Item label="RDR Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'RDR'
                            this.reivewStatus = '4'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean: false
                            })
                        }}
                        auth={['ROLE_03']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'RDR'
                            this.reivewStatus = '5'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean: true
                            })
                        }}
                        auth={['ROLE_03']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
                <LabelContainer></LabelContainer>
                <LabelContainer.Item label="GBDR Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'GBDR'
                            this.reivewStatus = '4'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean: false
                            })
                        }}
                        auth={['ROLE_04', 'ROLE_05']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'GBDR'
                            this.reivewStatus = '5'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean: true
                            })
                        }}
                        auth={['ROLE_04', 'ROLE_05']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
                <LabelContainer.Item label="GTDR Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'GTDR'
                            this.reivewStatus = '4'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean: false
                            })
                        }}
                        auth={['ROLE_06', 'ROLE_07']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'GTDR'
                            this.reivewStatus = '5'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean: true
                            })
                        }}
                        auth={['ROLE_06', 'ROLE_07']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
            </LabelContainer>
        )
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Review List -->"
                cancelText="Close"
                content="Check Status in Review List."
                onOk={() => {
                    this.closeSuccessModal()
                    this.getreviewList()
                    this.setState({
                        selectedRowKeys: []
                    })
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private renderReviewModal() {
        const { dataSource, ApproveBoolean } = this.state
        let strroletype = ''
        if (this.statusType === 'RDR') {
            strroletype = 'Regional Review Group'
        }
        if (this.statusType === 'GBDR') {
            strroletype = 'Global Business Design Group'
        }
        if (this.statusType === 'GTDR') {
            strroletype = 'Global Technical Design Group'
        }
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        {strroletype}
                                    </LabelItem>
                                </LabelContainer>

                                <DataForm.Item name="comment" label="Comment">
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }
    private replacement = () => {
        this.setState({
            Loading: true
        })
        this.pageService.reset()
        this.sortService.reset()
        this.getreviewList()
    }

    formatDate = () => {
        // let createDate = ''
        // if (this.searchForm.formInstance.getFieldsValue().createDate) {
        //     createDate =
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .createDate[0].format('MM/DD/YYYY') +
        //         ' - ' +
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .createDate[1].format('MM/DD/YYYY')
        // }

        // let rdrReviewDate = ''
        // if (this.searchForm.formInstance.getFieldsValue().rdrReviewDate) {
        //     rdrReviewDate =
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .rdrReviewDate[0].format('MM/DD/YYYY') +
        //         ' - ' +
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .rdrReviewDate[1].format('MM/DD/YYYY')
        // }

        // let gbdrReviewDate = ''
        // if (this.searchForm.formInstance.getFieldsValue().gbdrReviewDate) {
        //     gbdrReviewDate =
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .gbdrReviewDate[0].format('MM/DD/YYYY') +
        //         ' - ' +
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .gbdrReviewDate[1].format('MM/DD/YYYY')
        // }

        // let gtdrReviewDate = ''
        // if (this.searchForm.formInstance.getFieldsValue().gtdrReviewDate) {
        //     gtdrReviewDate =
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .gtdrReviewDate[0].format('MM/DD/YYYY') +
        //         ' - ' +
        //         this.searchForm.formInstance
        //             .getFieldsValue()
        //             .gtdrReviewDate[1].format('MM/DD/YYYY')
        // }

        // let targetLiveDate = ''
        //                 if (
        //                     this.searchForm.formInstance.getFieldsValue()
        //                         .targetLiveDate
        //                 ) {
        //                     targetLiveDate =
        //                         this.searchForm.formInstance
        //                             .getFieldsValue()
        //                             .targetLiveDate[0].format('MM/DD/YYYY') +
        //                         ' - ' +
        //                         this.searchForm.formInstance
        //                             .getFieldsValue()
        //                             .targetLiveDate[1].format('MM/DD/YYYY')
        //                 }

        const {
            createDate,
            rdrReviewDate,
            gbdrReviewDate,
            gtdrReviewDate,
            targetLiveDate
        } = this.searchForm.formInstance.getFieldsValue()
        const formatDate = {}
        if (createDate && Array.isArray(createDate) && createDate.length >= 2) {
            const [startDate, endDate] = createDate
            formatDate['createDate'] =
                startDate.format('MM/DD/YYYY') +
                ' - ' +
                endDate.format('MM/DD/YYYY')
        }

        if (
            rdrReviewDate &&
            Array.isArray(rdrReviewDate) &&
            rdrReviewDate.length >= 2
        ) {
            const [startDate, endDate] = rdrReviewDate
            formatDate['rdrReviewDate'] =
                startDate.format('MM/DD/YYYY') +
                ' - ' +
                endDate.format('MM/DD/YYYY')
        }

        if (
            gbdrReviewDate &&
            Array.isArray(gbdrReviewDate) &&
            gbdrReviewDate.length >= 2
        ) {
            const [startDate, endDate] = gbdrReviewDate
            formatDate['gbdrReviewDate'] =
                startDate.format('MM/DD/YYYY') +
                ' - ' +
                endDate.format('MM/DD/YYYY')
        }
        if (
            gtdrReviewDate &&
            Array.isArray(gtdrReviewDate) &&
            gtdrReviewDate.length >= 2
        ) {
            const [startDate, endDate] = gtdrReviewDate
            formatDate['gtdrReviewDate'] =
                startDate.format('MM/DD/YYYY') +
                ' - ' +
                endDate.format('MM/DD/YYYY')
        }
        if (
            targetLiveDate &&
            Array.isArray(targetLiveDate) &&
            targetLiveDate.length >= 2
        ) {
            const [startDate, endDate] = targetLiveDate
            formatDate['targetLiveDate'] =
                startDate.format('MM/DD/YYYY') +
                ' - ' +
                endDate.format('MM/DD/YYYY')
        }
        return formatDate;
    }

    getreviewList = () => {
        const formatDateRes = this.formatDate();
        this.reviewService
            .all(
                new RequestParams(
                    Object.assign(
                        this.searchForm.formInstance.getFieldsValue(),
                        {
                            ...formatDateRes,
                            outStandingApprovalName: this.homePageJumpSearch
                        }
                    ),
                    {
                        page: this.pageService,
                        sort: this.sortService
                    }
                )
            )
            .subscribe(data => {
                setTimeout(this.send, 500)
                this.setState({
                    dataSource: data
                })
            })
    }
    private send = () => {
        this.setState({
            Loading: false
        })
    }
    private openForm(row) {
        const fieldsValues = dataConvert(
            false,
            this.searchForm.formInstance.getFieldsValue()
        )
        this.props.history.push({
            pathname: '/pages/review-request-form',
            state: {
                reviewId: row.reviewId,
                fieldsValues,
                pathName: '/pages/api-review-request-list',
                searchParams: this.homePageJumpSearch
            },
            search: `reviewId=${row.reviewId}`
        })
    }

    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openReviewModal() {
        const { selectedRowKeys, dataSource } = this.state
        let selectedRow = dataSource.filter(e => {
            return (
                selectedRowKeys.indexOf(e.reviewId) === 0 ||
                selectedRowKeys.indexOf(e.reviewId) > 0
            )
        })
        if (this.statusType === 'RDR') {
            if (selectedRow.some(data => data.rdrReviewStatus !== '3')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        }
        if (this.statusType === 'GBDR') {
            if (selectedRow.some(data => data.gbdrReviewStatus !== '3')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        }
        if (this.statusType === 'GTDR') {
            if (selectedRow.some(data => data.gtdrReviewStatus !== '3')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        }

        if (selectedRowKeys.length == 0) {
            message.error('Please select at least one data')
            return
        }
        this.setState({
            reviewModalVisible: true
        })
    }
    private submitAction(staffId) {
        const { selectedRowKeys } = this.state
        this.actionForm.formInstance.validateFields().then((...data) => {
            this.reviewService
                .status(
                    new RequestParams({
                        reviewId: selectedRowKeys,
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        reviewStatus: this.reivewStatus,
                        reviewType: this.statusType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }
    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }

    private get searchForm(): DataForm {
        return this.searchFormRef.current as DataForm
    }
}
