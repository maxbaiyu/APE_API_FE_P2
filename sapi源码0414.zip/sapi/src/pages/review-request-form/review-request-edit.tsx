import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { DownOutlined } from '@ant-design/icons';
import {
    Form,
    Input,
    Select,
    Table,
    Divider,
    Button,
    Avatar,
    Modal,
    List,
    message,
    Row,
    Col,
    InputNumber
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { InboxOutlined, UserOutlined } from '@ant-design/icons'
import NotificationContainer from '~/shared/components/notification-container'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import { DictUtil } from '~/shared/utils/dict.util'
import Dragger from 'antd/lib/upload/Dragger'
import appConfig from '~/config/app.config'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import ReplyCommont from '~/components/reply-commont'
import { download } from '~/shared/utils/common.util'
import { isNullOrUndefined } from 'util'
import { FormInstance } from 'antd/lib/form'
import{rulesdata} from '~/assets/regular/rest'
import 'braft-editor/dist/index.css'
import BraftEditor from 'braft-editor'

const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

const { TextArea } = Input

interface ReviewRequestEditState {
    id: string
    data: any
    dataSource: any[]
    reviewModalVisible: boolean
    disabledEdit:boolean
    disabledInputEdit:boolean
    successModalVisible: boolean
    applicableChannelsSpecficDisplay: boolean
    applicableCountriesSpecficDisplay: boolean
    applicableGbSpecficDisplay: boolean
    contractInformationStatus: boolean
    commontsTree: any
    show:boolean
    featureData: any[]
    serviceData: any[]
}

interface ReviewRequestEditProps {}

export default class ReviewRequestEdit extends Component<
    RouteComponentProps<ReviewRequestEditProps>,
    ReviewRequestEditState
> {
    private dataFromRef!: React.RefObject<DataForm>
    private rpsSessionFromRef!: React.RefObject<DataForm>

    private reviewService = new ReviewService()
    private dictUtil = new DictUtil()
    private rulesdata = rulesdata
    private actionFromRef!: React.RefObject<DataForm>
    private contractInformationFromRef!: React.RefObject<DataForm>
    private reviewType = ''
    private reviewStatus = ''
    private file: File
    private formRef = React.createRef<FormInstance>()
    private idTrue = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.actionFromRef = React.createRef()
        this.rpsSessionFromRef = React.createRef()
        this.contractInformationFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            dataSource: [],
            reviewModalVisible: false,
            successModalVisible: false,
            applicableChannelsSpecficDisplay: false,
            applicableCountriesSpecficDisplay: false,
            applicableGbSpecficDisplay: false,
            contractInformationStatus: false,
            commontsTree: [],
            featureData: [],
            serviceData: [],
            show:false,
            disabledEdit:true,
            disabledInputEdit:true
        }
    }

    public componentDidMount() {
        try {
            const { id } = this.props.location.state as ReviewRequestEditState
            this.idTrue = id
        } catch (error) {
            const searchArr = this.props.location.search.split('=')
            if (searchArr && searchArr.length >= 1) {
                this.idTrue = searchArr[1]
            }
        }
        this.getReview()
        this.getComments()
    }

    private getReview() {
        this.reviewService
            .get(new RequestParams({}, { append: [this.idTrue] }))
            .subscribe(data => {
                this.setState({
                    data: data,
                    dataSource: data.contracts,
                    contractInformationStatus:
                        data.gbdrReviewStatus > 3 ||
                        data.gtdrReviewStatus > 3 ||
                        data.rdrReviewStatus > 3,
                    applicableChannelsSpecficDisplay:
                        data.applicableChannels === '04',
                    applicableCountriesSpecficDisplay:
                    data.applicableCountries === '02' ||
                    data.applicableCountries === '03' ||
                    data.applicableCountries === '04',
                    applicableGbSpecficDisplay:
                    data.applicableGbGf === '04',
                })
                
                const features=this.dictUtil.dicts(data.capability)
                this.setState({featureData:features})
                const services=this.dictUtil.dicts(data.feature)
                this.setState({serviceData:services})
                this.dataForm.formInstance.setFieldsValue(data)
                this.rpsSessionForm?.formInstance?.setFieldsValue({data})
                if(data.demandClassification=='01'||data.demandClassification=='02'){
                    this.setState({
                        disabledInputEdit:false
                    })
                }else{
                    this.setState({
                        disabledInputEdit:true
                    })
                } 
                if (data.rdrReviewStatus > 3 ||
                    data.gbdrReviewStatus > 3 ||
                    data.gtdrReviewStatus > 3) {
                    this.setState({
                        disabledEdit: true,
                        disabledInputEdit:true
                    })
                }else{
                    this.setState({
                        disabledEdit: false
                    })
                }
            })
    }

    private getComments() {
        this.reviewService
            .comments(new RequestParams({}, { append: [this.idTrue] }))
            .subscribe(data => {
                const action = node => {
                    const children = data.filter(
                        x => x.parentId === node.commentId
                    )
                    
                    node.children = children
                    children.length && children.forEach(action)
                    return node
                }

                const tree = data.filter(x => !x.parentId).map(action)
                this.setState({
                    commontsTree: tree
                })
            })
    }
    public render() {
        const { data, disabledEdit,featureData, serviceData,disabledInputEdit} = this.state
        return (
            <components.PageContainer
                title="Review Request Edit"
                noHeader={true}
                isNotNeedFlex={true}
                isNeedCenter={true}
            >
                <div
                    className="flex-row justify-content-between align-items-center"
                >
                    <div style={{ fontSize: 28, marginLeft: 20 }}>
                        {data.apiName}
                    </div>
                    <div>
                        <Button
                            //size="large"
                            onClick={() => {
                                this.props.history.goBack()
                            }}
                        >
                            Back
                        </Button>
                    </div>
                </div>
                {/* <Divider /> */}
                <CardContainer title="Basic Information">
                    <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="Project Name">
                            {data?.projectName}
                        </LabelItem>

                        <LabelItem label="Demand Classification">
                            {this.dictUtil.filter(
                                'api_classification',
                                data?.demandClassification
                            )}
                        </LabelItem>
                        <LabelItem label="Requester">
                            {data?.requester}
                        </LabelItem>
                        <LabelItem label="Reused API Version">
                            {data?.reuseApiVersion}
                        </LabelItem>
                        <LabelItem label="Entry Created Date">
                            {data?.createDate}
                        </LabelItem>
                        {/* <LabelItem label="Original API ID">
                            {data?.originalSapiId}
                        </LabelItem> */}
                        <LabelItem label="Region">{data?.region}</LabelItem>
                        <LabelItem label="Backend System">
                            {this.dictUtil.filter(
                                'backend_system',
                                data?.backEndSystem
                            )}
                        </LabelItem>
                        <LabelItem label="Site">{data?.country}</LabelItem>
                    </LabelContainer>
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                    >
                        <Form.Item
                            name="apiName"
                            label="API Name"
                            rules={[
                                {
                                    message:
                                        'API Name can contain letters, numbers, spaces, and special character: -.',
                                    pattern: rulesdata.patternOne
                                }
                            ]}
                        >
                            <Input disabled={disabledInputEdit} />
                        </Form.Item>
                        <Form.Item
                            name="trueSapiId"
                            label="API ID"
                            rules={[
                                {
                                    message:
                                        'API ID only contains letters, numbers and special character: -.',
                                    pattern: rulesdata.patternThree
                                }
                            ]}
                        >
                            <Input  disabled={disabledEdit}/>
                        </Form.Item>
                        <Form.Item
                            label="Original API ID"
                            name="originalSapiId"
                        >
                            <Input disabled={disabledEdit}/>
                        </Form.Item>
                        {/* <Form.Item name="multiCountry" label="Multiple Country">
                            <Select allowClear disabled={disabledEdit}>
                                <Select.Option value="Y">Y</Select.Option>
                                <Select.Option value="N">N</Select.Option>
                            </Select>
                        </Form.Item> */}
                        <Form.Item
                            name="coreBankingApiId"
                            label="Core Banking API ID"
                            rules={[
                                {
                                    message:
                                        'Core Banking API ID can contain letters, numbers, spaces, and special character: -.',
                                    pattern: /^\w+[\w\s-]*$/
                                }
                            ]}
                        >
                            <Input disabled={disabledEdit} />
                        </Form.Item>
                        <Form.Item name="apiType" label="API Type">
                            <Select allowClear disabled={disabledEdit}>
                                {this.dictUtil.dicts('api_type', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="tps"
                            label="TPS"
                            rules={[
                                {
                                    // type: 'string'
                                },
                                () => ({
                                    validator(_, value) {
                                        if (value == undefined) {
                                            return Promise.resolve(true)
                                        }
                                        const str = String(value)
                                        if (
                                            !str.includes('.') &&
                                            str.length > 4
                                        ) {
                                            return Promise.reject(
                                                new Error(
                                                    'Maximum 4-dight number'
                                                )
                                            )
                                        } else if (str.includes('.')) {
                                            if (str.length > 5) {
                                                return Promise.reject(
                                                    new Error(
                                                        'Maximum 4-dight number'
                                                    )
                                                )
                                            } else {
                                                const end = str.split('.')[1]
                                                if (end.length > 2) {
                                                    return Promise.reject(
                                                        new Error(
                                                            'Maximum 4-dight number'
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                        return Promise.resolve(true)
                                    }
                                })
                            ]}
                        >
                            <Input type="number" disabled={disabledEdit}/>
                        </Form.Item>
                        <Form.Item name="apiMethod" label="API Method">
                            <Select allowClear disabled={disabledEdit}>
                                <Select.Option value="POST">POST</Select.Option>
                                <Select.Option value="GET">GET</Select.Option>
                                <Select.Option value="PUT">PUT</Select.Option>
                                <Select.Option value="DELETE">
                                    DELETE
                                </Select.Option>
                            </Select>
                        </Form.Item>

                        <DataForm.Item
                            name="capability"
                            label="Capability"
                            initialValue=""
                        >
                            <Select
                                allowClear
                                disabled={disabledEdit}
                                onChange={value => {
                                    this.dataForm.formInstance.resetFields([
                                        'feature'
                                    ])
                                    this.dataForm.formInstance.resetFields([
                                        'service'
                                    ])
                                    const features = this.dictUtil.dicts(value)
                                    this.setState({
                                        featureData: features
                                    })
                                }}
                            >
                                {this.dictUtil.dicts('capability', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>

                        <Form.Item name="platform" label="Platform">
                            <Select disabled={disabledEdit}>
                                {this.dictUtil.dicts('platform', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>

                        <DataForm.Item
                            name="feature"
                            label="Feature"
                            initialValue=""
                        >
                            <Select
                                allowClear
                                disabled={disabledEdit}
                                onChange={value => {
                                    this.dataForm.formInstance.resetFields([
                                        'service'
                                    ])
                                    const services = this.dictUtil.dicts(value)
                                    this.setState({
                                        serviceData: services
                                    })
                                }}
                            >
                                {featureData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <Form.Item
                            name="channelAgnostic"
                            label="Channel Agnostic"
                        >
                            <Select disabled={disabledEdit}>
                                {this.dictUtil.dicts(
                                    'channel_agnostic',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <DataForm.Item
                            name="service"
                            label="Service"
                            initialValue=""
                        >
                            <Select allowClear disabled={disabledEdit}>
                                {serviceData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <Form.Item
                            name="zhanwei"
                        >
                        </Form.Item>
                        <Form.Item
                            name="description"
                            rules={[
                                {
                                    type: 'string',
                                    max: 799,
                                    message: 'Maximum 800 characters'
                                }
                            ]}
                            style={{ width: '100%' }}
                            label="Description"
                        >
                            <TextArea
                                rows={4}
                                style={{
                                    width: '100%',
                                    textAlign: 'left'
                                }}
                                maxLength={800}
                            />
                        </Form.Item>
                        <Form.Item
                            name="reviewDesc"
                            rules={[
                                {
                                    type: 'string',
                                    max: 800,
                                    message: 'Maximum 800 characters'
                                }
                            ]}
                            style={{ width: '100%' }}
                            label="API Design Review Description"
                        >
                            <TextArea
                                rows={4}
                                style={{
                                    width: '100%',
                                    textAlign: 'left'
                                }}
                                maxLength={800}
                                disabled={disabledEdit}
                            />
                        </Form.Item>
                        <Form.Item
                            name="reviewRemarks"
                            rules={[
                                {
                                    type: 'string',
                                    max: 500,
                                    message: 'Maximum 500 characters'
                                }
                            ]}
                            style={{ width: '100%' }}
                            label="Remarks"
                        >
                            <TextArea
                                rows={4}
                                style={{
                                    width: '100%',
                                    textAlign: 'left'
                                }}
                                maxLength={500}
                            />
                        </Form.Item>
                        <Form.Item
                            name="customField1"
                            rules={[
                                {
                                    type: 'string',
                                    max: 100,
                                    message: 'Maximum 100 characters'
                                }
                            ]}
                            style={{ width: '100%' }}
                            label="Custom Field 1"
                        >
                            <TextArea
                                rows={4}
                                style={{
                                    width: '100%',
                                    textAlign: 'left'
                                }}
                                maxLength={100}
                            />
                        </Form.Item>
                        <Form.Item
                            name="customField2"
                            rules={[
                                {
                                    type: 'string',
                                    max: 100,
                                    message: 'Maximum 100 characters'
                                }
                            ]}
                            style={{ width: '100%' }}
                            label="Custom Field 2"
                        >
                            <TextArea
                                rows={4}
                                style={{
                                    width: '100%',
                                    textAlign: 'left'
                                }}
                                maxLength={100}
                            />
                        </Form.Item>
                    </DataForm>
                </CardContainer>

                {data?.backEndSystem === '03' && (
                    <CardContainer title="RPS Session">
                        <DataForm
                            ref={this.rpsSessionFromRef}
                            name="demo-form"
                            column={2}
                            labelCol={{ span: 8 }}
                            labelAlign="left"
                        >
                            <Form.Item
                                name="proxyId"
                                label="Proxy ID"
                                // rules={[
                                //     {
                                //         type: 'string',
                                //         max: 4,
                                //         message: 'Maximum 4 characters'
                                //     }
                                // ]}
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="programId"
                                label="Program ID"
                                // rules={[
                                //     {
                                //         type: 'string',
                                //         max: 4,
                                //         message: 'Maximum 4 characters'
                                //     }
                                // ]}
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="txnId"
                                label="Transaction ID"
                                rules={[
                                    {
                                        type: 'string',
                                        max: 4,
                                        message: 'Maximum 4 characters'
                                    }
                                ]}
                            >
                                <Input disabled={disabledEdit} />
                            </Form.Item>
                        </DataForm>
                    </CardContainer>
                )}
                <div
                    style={{ width: '100%',padding:'20px' }}
                    className="flex-row justify-content-end"
                >
                    <components.AuthDisableButton
                        type="primary"
                        //size="large"
                        danger
                        onClick={() => this.submit()}
                        auth={['ROLE_01', 'ROLE_011']}
                    >
                        Submit
                    </components.AuthDisableButton>
                </div>
                {this.renderContractInformation()}
                {this.renderModal()}
            </components.PageContainer>
        )
    }
    
    private submit(){
        //const { id } = this.props.location.state as ReviewRequestEditState
        let d1=this.dataForm.formInstance.getFieldsValue()
        if(d1.apiName==''||d1.apiType==''||d1.feature==''||d1.platform==''||
        d1.service==''||d1.trueSapiId==''
        ){
            message.warning("All required field should be filled, otherwise the status won't change to 'in progress'")
        }
        const { tps } = d1;
        this.dataForm.formInstance.validateFields().then(() => {
                this.reviewService
            .information(
                new RequestParams({
                    ...d1,
                    reviewId:this.idTrue,
                    tps:tps && Number(tps),
                    ...this.rpsSessionForm?.formInstance.getFieldsValue()
                })
            )
            .subscribe(data => {
                this.openSuccessModal()
                // this.props.history.goBack()
            })
        })
    
    }
    private renderContractInformation() {
        const {
            applicableChannelsSpecficDisplay,
            applicableCountriesSpecficDisplay,
            applicableGbSpecficDisplay,
            contractInformationStatus
        } = this.state

        const testData = {
            reviewId: 1,
            applicableChannels: '1'
        }

        const uploadProps = {
            name: 'file',
            multiple: false,
            action: appConfig.server + '/review/upload',
            data: testData,
            beforeUpload: file => {
                this.file = file
                return false
            },
            onChange(info) {
                const { status } = info.file

                if (status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully.`
                    )
                } else if (status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }
        const columns = [
            {
                title: 'Documents',
                dataIndex: 'contractName',
                render: (text, record) => (
                    <Button
                        type="link"
                        className="text-left"
                        onClick={() => {
                            download(
                                appConfig.server +
                                    '/review/download?fileName=' +
                                    text,
                                text,''
                            )
                        }}
                    >
                        {text}
                    </Button>
                )
            },
            {
                title: 'Upload Date',
                dataIndex: 'createDate'
            },
            {
                title: 'Upload Person',
                dataIndex: 'accName'
            },
            {
                title: 'Delete ',
                render: (text, record) => (
                    <components.AuthDisableButton
                        onClick={() => this.deleteContract(record)}
                        auth={['ROLE_01','ROLE_011']}
                    >
                        Delete
                    </components.AuthDisableButton>
                )
            }
        ]

        const { dataSource } = this.state

        return (
            <div></div>
            // <CardContainer>
            // </CardContainer>
        )
    }
    private deleteContract(record) {
        this.reviewService
            .deleteContract(
                new RequestParams({}, { append: [record.contractId] })
            )
            .subscribe(data => {
                message.success('contract delete success')

                this.getReview()
            })
    }
    private renderComment() {
        const { commontsTree } = this.state

        return (
            <List
                className="comment-list"
                header={`${commontsTree.length} replies`}
                itemLayout="horizontal"
                dataSource={commontsTree}
                renderItem={(item: any) => (
                    <li key={item.commentId}>{this.renderCommontItem(item)}</li>
                )}
            />
        )
    }
    private renderCommontItem(item) {
        const data = item.children
        return (
            <ReplyCommont
                item={item}
                onSubmit={() => {
                    this.getComments()
                }}
            >
                {data &&
                    data.map(m => {
                        return (
                            <div key={m.commentId}>
                                {m && this.renderCommontItem(m)}
                            </div>
                        )
                    })}
            </ReplyCommont>
        )
    }

    private renderrdrViewBox() {
        const { data } = this.state
        const { rdrReviewStatus } = data
        switch (rdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="approved"
                        status={rdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.rdrReviewer}
                            </LabelItem>
                            <LabelItem label="Operation Date:">
                                {data.rdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.rdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    //size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    //size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="rejected"
                        status={rdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.rdrReviewer}
                            </LabelItem>
                            <LabelItem label="Operation Date:">
                                {data.rdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.rdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    //size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    //size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="verify"
                        status={rdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    //size="large"
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_03']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    //size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_03']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="inProgress"
                        status={rdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    //size="large"
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    //size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderGbdrViewBox() {
        const { data } = this.state
        const { gbdrReviewStatus } = data
        switch (gbdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="approved"
                        status={gbdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gbdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gbdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Operation Date:">
                                {data.gbdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gbdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    //size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    //size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="rejected"
                        status={gbdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gbdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gbdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Operation Date:">
                                {data.gbdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gbdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    //size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    //size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="verify"
                        status={gbdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    //size="large"
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_04', 'ROLE_05']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    //size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_04', 'ROLE_05']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="inProgress"
                        status={gbdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    //size="large"
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    //size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderGtdrViewBox() {
        const { data } = this.state
        const { gtdrReviewStatus } = data
        switch (gtdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="approved"
                        status={gtdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gtdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gtdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Operation Date:">
                                {data.gtdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gtdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    //size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    //size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="rejected"
                        status={gtdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gtdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gtdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Operation Date:">
                                {data.gtdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gtdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    //size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    //size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="verify"
                        status={gtdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    //size="large"
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_06', 'ROLE_07']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    //size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_06', 'ROLE_07']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="inProgress"
                        status={gtdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    //size="large"
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                   // size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }

    private renderReviewModal() {
        let strroletype = ''
        if (this.reviewType === 'RDR') {
            strroletype = 'Regional Review Group'
        }
        if (this.reviewType === 'GBDR') {
            strroletype = 'Global Business Design Group'
        }
        if (this.reviewType === 'GTDR') {
            strroletype = 'Global Technical Design Group'
        }
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {/* {(this.staffId = userStore.state.staffId)} */}
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        {strroletype}
                                    </LabelItem>
                                </LabelContainer>
                                {/*  <DataForm.Item label="Team">
                                    {userStore.state.roleList.map(
                                        val => val.authority + ' '
                                    )}
                                </DataForm.Item> */}
                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private submitAction(staffId) {
        const { data } = this.state
        this.actionForm.formInstance.validateFields().then((...data1) => {
            this.reviewService
                .status(
                    new RequestParams({
                        reviewId: [data.reviewId],
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        reviewStatus: this.reviewStatus,
                        reviewType: this.reviewType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }

    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Review Request Form -->"
                cancelText="Close"
                content="Check in Review Request Form."
                onOk={() => {
                    this.props.history.goBack()
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private openReviewModal() {
        this.setState({
            reviewModalVisible: true
        })
    }
    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private get contractInformationFrom(): DataForm {
        return this.contractInformationFromRef.current as DataForm
    }

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Customer Address Creation
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    private get rpsSessionForm(): DataForm {
        return this.rpsSessionFromRef.current as DataForm
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                apiCatalogueId
            },
            search:`apiCatalogueId=${apiCatalogueId}`
        })
    }
}
