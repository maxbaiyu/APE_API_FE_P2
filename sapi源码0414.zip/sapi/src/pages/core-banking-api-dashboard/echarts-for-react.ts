import ReactEchartsCore from 'echarts-for-react/lib/core';
import echarts from 'echarts/lib/echarts';
import 'echarts/lib/component/toolbox';
import 'echarts/lib/component/title';
import 'echarts/lib/component/legend';
import 'echarts/lib/component/grid';
import 'echarts/lib/component/markPoint'

const loadingOption = {
    text: 'loading...',
    color: '#1890ff',
    textColor: '#1890ff'
  };
  
  // todo ts.json
  export {
    loadingOption,
    ReactEchartsCore,
    echarts
  };