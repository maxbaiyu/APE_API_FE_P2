import { colorArr } from './type'

const labelOption = {
    show: true,
    position: 'insideBottom',
    distance: 15,
    align: 'left',
    verticalAlign: 'middle',
    rotate: 90,
    formatter: params => {
        const { seriesName, value } = params
        if (value) {
            return `${value} ${seriesName}`
        }
        return ''
    },
    fontSize: 9
}

const MULT_BAR_WIDTH = 18
const SINGLE_BAR_WIDTH = 20

const MULT_BAR_BASIC_PROPS = {
    type: 'bar'
    //barWidth: MULT_BAR_WIDTH,
    //label: labelOption,
    //barGap: 2,
    // emphasis: {
    //     focus: 'series'
    // }
}

const GRID_BASIC_SET = {
    left: '2.9%',
    right: '3%',
    bottom: '2%',
    containLabel: true
}

// Reusability Pie Chart
export const reusePieChartOption: any = {
    title: {
        left: 'center'
    },
    tooltip: {
        trigger: 'item',
        axisPointer: {
            type: 'shadow'
        },
        formatter: params => {
            const { name, percent, value } = params
            return `${name} ${name ? ':' : ''} ${value} (${percent}%)`
        }
    },
    grid: {
        ...GRID_BASIC_SET,
        left: 0,
        right: 0
    },
    series: [
        {
            type: 'pie',
            radius: '60%',
            data: [],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            color: colorArr
        }
    ],
    markLine: {
        silent: true
    }
}

// API Demand Order Delivery Duration
export const deliveryDurationChartOption: any = {
    tooltip: {
        trigger: 'item',
        axisPointer: {
            type: 'shadow'
        }
    },
    grid: {
        ...GRID_BASIC_SET,
        left: '3.6%',
        right: '10.5%'
    },
    xAxis: {
        type: 'category',
        data: ['1', '2', '3', '4', '5', '6', '6+'],
        name: 'Months'
    },
    yAxis: {
        type: 'value',

        name: 'Number of API'
    },
    series: [
        {
            data: [],
            type: 'bar',
            barWidth: SINGLE_BAR_WIDTH,
            color: ['#14A5AB']
        }
    ]
}

// API Demand Order Tracking
export const trackingChartOption: any = {
    grid: {
        ...GRID_BASIC_SET,
        right: '2%',
        left: '4%'
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    legend: {
        data: [
            'Order Received',
            'Delivered for Testing',
            'Delivered for Production'
        ]
    },
    color: ['#14A5AB', '#6D8EA6', '#4FA62F'],
    xAxis: [
        {
            type: 'category',
            data: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec'
            ]
        }
    ],
    yAxis: [
        {
            type: 'value',
            name: 'Number of API'
        }
    ],
    series: [
        {
            name: 'Order Received',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'Delivered for Testing',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'Delivered for Production',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        }
    ]
}

// TOP 10 of API Reused
export const topApiReusedOption: any = {
    color: ['#E67310'],
    tooltip: {
        trigger: 'item',
        axisPointer: {
            type: 'shadow'
        }
    },
    grid: {
        ...GRID_BASIC_SET,
        right: '12.5%',
        left: '1.5%'
    },
    xAxis: {
        type: 'value',
        boundaryGap: [0, 0.01],
        name: 'Reuse Times'
    },
    yAxis: {
        type: 'category',
        name: 'API Name',
        axisLabel: {
            show: true,
            formatter: value => {
                var texts = value
                if (texts.length > 35) {
                    texts = texts.substr(0, 35) + '...'
                }
                return texts
            }
        },
        data: []
    },
    series: [
        {
            type: 'bar',
            barWidth: SINGLE_BAR_WIDTH,
            data: []
        }
    ]
}

// API Demand Order status
export const statusChartOption: any = {
    color: ['#008580', '#34880F', '#BF610F', '#A8166D', '#6637D5', '#1564B5'],
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    grid: GRID_BASIC_SET,
    legend: {
        data: [
            'Discovery',
            'Development',
            'SIT',
            'UAT',
            'Deployment Readiness',
            'Production'
        ]
    },
    xAxis: [
        {
            type: 'category',
            data: []
        }
    ],
    yAxis: [
        {
            type: 'value',
            name: 'Number of API'
        }
    ],
    series: [
        {
            name: 'Discovery',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'Development',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'SIT',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'UAT',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'Deployment Readiness',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        },
        {
            name: 'Production',
            ...MULT_BAR_BASIC_PROPS,
            data: []
        }
    ]
}
