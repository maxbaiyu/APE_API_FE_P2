import React, { useState, useEffect } from 'react'
import 'echarts/lib/chart/bar'
import { RequestParams } from '~/core/http'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import styled from 'styled-components'
import { Button } from 'antd'
import { download } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import DashboardCardComponent from './dashboard-card-component'
import { deliveryDurationChartOption } from './dashboardInitData'
import { ECHARTS_DECREASE_TOP_CLASS } from './type'

const components = {
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface ExtentdProps {
    dashboardService: any
}

const DeliveryDurationChartCard: React.FC<ExtentdProps> = props => {
    const { dashboardService } = props

    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [pieOption, setPieOption] = useState<any>(deliveryDurationChartOption)

    useEffect(() => {
        dashboardService.deliveryDuration(new RequestParams()).subscribe(
            data => {
                setShowLoading(false)
                setPieOption({
                    ...pieOption,
                    series: [
                        {
                            ...pieOption.series[0],
                            data
                        }
                    ]
                })
            },
            error => {
                setShowLoading(false)
                // delete
                // const duration = require('./duration.json')
                // setPieOption({
                //     ...pieOption,
                //     series: [
                //         {
                //             ...pieOption.series[0],
                //             data: duration
                //         }
                //     ]
                // })
            }
        )
    }, [])

    return (
        <DashboardCardComponent
            title={'API Demand Order Delivery Duration'}
            className={'delivery-duration-chart-card'}
            extra={
                <components.AuthDisableButton
                    auth={[
                        'ROLE_01',
                        'ROLE_02',
                        'ROLE_03',
                        'ROLE_04',
                        'ROLE_05',
                        'ROLE_06',
                        'ROLE_07',
                        'ROLE_08',
                        'ROLE_09',
                        'ROLE_10',
                        'ROLE_011'
                    ]}
                    //size="large"
                    onClick={() => {
                        download(
                            appConfig.server + '/homepage/delivery-duration/export',
                            'API-Demand-Order-Delivery-Duration.xls',
                            ''
                        )
                    }}
                >
                    Export
                </components.AuthDisableButton>
            }
        >
            <ReactEchartsCore
                className={ECHARTS_DECREASE_TOP_CLASS}
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                style={{ height: 300 }}
            />
        </DashboardCardComponent>
    )
}

export default DeliveryDurationChartCard
