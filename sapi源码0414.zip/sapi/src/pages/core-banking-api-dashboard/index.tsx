import React, { useState, useRef, useEffect } from 'react'
import { useStore } from 'reto'
import { UserStore } from '~/store/user.store'
import { DictUtil } from '~/shared/utils/dict.util'
import { ReviewService } from '~/services/review.service'
import PageContainer from '~/shared/components/page-container'
import StatisticsCard from './statistics-card'
import ReusabilityPieChartCard from './reusability-pie-chart'
import DeliveryDurationChartCard from './delivery-duration'
import TrackingChartCard from './tracking'
import TopApiReusedChartCard from './top-api-reused'
import StatusChartCard from './status'

import styled from 'styled-components'

const components = {
    PageContainer: styled(PageContainer)``,
    Content: styled.div`
        padding: 1rem;
        display: flex;
        box-sizing: border-box;
        .dashboard-left-area {
            width: 45%;
            padding-right: 0.625em;
            box-sizing: border-box;
        }
        .dashboard-right-area {
            flex: 1 1;
        }
    `
}

const dashboardService = new ReviewService()

const CoreBankingAPIDashboard: React.FC = () => {
    const userStore = useStore(UserStore)
    const dictUtil = new DictUtil()
    useEffect(() => {}, [])
    return (
        <components.PageContainer
            width={'100%'}
            title="Core Banking API Dashboard"
            noHeader={true}
            isNotNeedFlex={true}
            isNeedCenter={true}
            className={'core-banking-api-dashboard'}
        >
            <components.Content>
                <div className={'dashboard-left-area'}>
                    <StatisticsCard userStore={userStore} />
                    <ReusabilityPieChartCard dictUtil={dictUtil} dashboardService={dashboardService}/>
                    <DeliveryDurationChartCard dashboardService={dashboardService}/>
                </div>
                <div className={'dashboard-right-area'}>
                    <TrackingChartCard dictUtil={dictUtil} dashboardService={dashboardService}/>
                    <TopApiReusedChartCard
                        dictUtil={dictUtil}
                        dashboardService={dashboardService}
                    />
                    <StatusChartCard />
                </div>
            </components.Content>
        </components.PageContainer>
    )
}

export default CoreBankingAPIDashboard
