import React, { ReactNode, useState, useEffect, useRef } from 'react'
import { Form, Select, Button } from 'antd'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import 'echarts/lib/chart/bar'
import DataForm from '~/shared/components/data-form'
import DashboardCardComponent from './dashboard-card-component'
import { trackingChartOption } from './dashboardInitData'
import { RequestParams } from '~/core/http'

const { Option } = Select

interface ExtentdProps {
    dictUtil: any
    dashboardService: any
}

const TrackingChartCard: React.FC<ExtentdProps> = props => {
    const { dictUtil, dashboardService } = props

    const dataFormRef: any = useRef<HTMLDivElement>(null)

    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [pieOption, setPieOption] = useState<any>(trackingChartOption)
    const [yearList, setYearList] = useState<any>([])
    const [filterOptions, setFilterOption] = useState<any>()

    const getYear = () => {
        dashboardService.trackingYear(new RequestParams()).subscribe(
            data => {
                setYearList(data)
            }
        )
    }

    const getInitFormOption = () => {
        setFilterOption({
            product: dictUtil.dicts('backend_system') || [],
            region: dictUtil.dicts('gb_gf') || [],
            country: dictUtil.dicts('region') || [],
            gbOrGF: dictUtil.dicts('country') || []
        })
    }

    const regionChange = value => {
        const country = dictUtil.dicts(value)
        setFilterOption({
            ...filterOptions,
            country
        })
        dataFormRef.current.formInstance.setFieldsValue({
            country: country[0]?.dirCode || ''
        })
    }

    const resetFilter = () => {
        dataFormRef.current.formInstance.resetFields()
    }

    const onFormValueChange = () => {
        getOption()
    }

    const getOption = () => {
        const {
            backendSystem,
            region,
            country,
            gbOrGF,
            demandApprovalDate
        } = dataFormRef.current.formInstance.getFieldsValue()
        dashboardService
            .tracking(
                new RequestParams({
                    product: backendSystem,
                    region: region,
                    site: country,
                    gbge: gbOrGF,
                    year: demandApprovalDate
                })
            )
            .subscribe(
                data => {
                    setShowLoading(false)
                    setPieOption({
                        ...pieOption,
                        series: pieOption.series.map((item, index) => ({
                            ...item,
                            ...data[index]
                        }))
                    })
                },
                error => {
                    setShowLoading(false)
                    // todo delete
                    // const data = require('./trackingMock.json')
                    // setPieOption({
                    //     ...pieOption,
                    //     series: pieOption.series.map((item, index) => ({
                    //         ...item,
                    //         ...data[index]
                    //     }))
                    // })
                }
            )
    }

    useEffect(() => {
        getYear()
        getInitFormOption()
        getOption()
    }, [])

    return (
        <DashboardCardComponent
            title={'API Demand Order Tracking'}
            className={'tracking-chart-card'}
        >
            <DataForm
                name="search-form-tracking"
                column={3}
                labelCol={{ span: 8 }}
                labelAlign="left"
                ref={dataFormRef}
                onValuesChange={onFormValueChange}
            >
                <DataForm.Item
                    name="backendSystem"
                    label="Product"
                    initialValue="all"
                >
                    <Select>
                        <Option value="all">{'All'}</Option>
                        {filterOptions?.product.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item name="region" label="Region" initialValue="all">
                    <Select onChange={regionChange}>
                        <Option value="all">{'All'}</Option>
                        {filterOptions?.region.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item name="country" label="Site" initialValue="all">
                    <Select>
                        <Option value="all">{'All'}</Option>
                        {filterOptions?.country.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item name="gbOrGF" label="GB/GF" initialValue="all">
                    <Select>
                        <Option value="all">{'All'}</Option>
                        {filterOptions?.gbOrGF.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item
                    name="demandApprovalDate"
                    label="Year"
                    initialValue="all"
                >
                    <Select allowClear>
                        <Option value="all">Overall</Option>
                        {yearList.map(item => 
                            <Option key={item.year} value={item.year}>
                                {item.year}
                            </Option>
                        )}
                    </Select>
                </DataForm.Item>
                <Button
                    style={{ width: '100%' }}
                    onClick={() => {
                        resetFilter()
                        getOption()
                    }}
                >
                    Re-set
                </Button>
            </DataForm>

            <ReactEchartsCore
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                notMerge={true}
                style={{ height: 300 }}
            />
        </DashboardCardComponent>
    )
}

export default TrackingChartCard
