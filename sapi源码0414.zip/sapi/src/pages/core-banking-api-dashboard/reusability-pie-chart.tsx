import React, { useState, useEffect, useRef } from 'react'
import 'echarts/lib/chart/pie' //饼状图
import { RequestParams } from '~/core/http'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import { Select } from 'antd'
import DataForm from '~/shared/components/data-form'
import DashboardCardComponent from './dashboard-card-component'
import { reusePieChartOption } from './dashboardInitData'
import {
    colorArr,
    ECHARTS_DECREASE_TOP_CLASS,
    PIE_CHART_DEMAND_CORRESPONDENCE,
    GROUP_BY_LIST
} from './type'

const { Option } = Select

interface ExtentdProps {
    dictUtil: any
    dashboardService: any
}

const ReusabilityPieChartCard: React.FC<ExtentdProps> = props => {
    const { dictUtil, dashboardService } = props

    const dataFormRef: any = useRef<HTMLDivElement>(null)

    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [pieOption, setPieOption] = useState<any>(reusePieChartOption)

    const selectChange = (demandClassification = 'all', groupBy = 'all') => {
        let color = colorArr
        if (groupBy == 'all' && demandClassification !== 'all') {
            color = colorArr.slice(
                Number(demandClassification.substring(1, 2)) - 1,
                Number(demandClassification.substring(1, 2))
            )
        }
        dashboardService
            .reusability(
                new RequestParams({
                    classification:
                        PIE_CHART_DEMAND_CORRESPONDENCE[demandClassification],
                    groupType: groupBy
                })
            )
            .subscribe(
                res => {
                    setShowLoading(false)
                    setPieOption({
                        ...pieOption,
                        series: [
                            {
                                ...pieOption.series[0],
                                data: res.map((item, index) => ({
                                    labelLine: {
                                        show: !!item.name
                                    },
                                    label: {
                                        normal: {
                                            position: item.name ? 'outside' : 'inner',
                                            show: !!item.name
                                        }
                                    },
                                    ...res[index]
                                })),
                                color
                            }
                        ]
                    })
                },
                error => {
                    setShowLoading(false)
                    // todo delete
                    // const data = require('./pieChart.json')
                    // const res = data[`${demandClassification}${groupBy}`]
                    // setPieOption({
                    //     ...pieOption,
                    //     series: [
                    //         {
                    //             ...pieOption.series[0],
                    //             data: res.map((item, index) => ({
                    //                 labelLine: {
                    //                     show: !!item.name
                    //                 },
                    //                 label: {
                    //                     normal: {
                    //                         position: item.name ? 'outside' : 'inner',
                    //                         show: !!item.name
                    //                     }
                    //                 },
                    //                 ...res[index]
                    //             })),
                    //             color
                    //         }
                    //     ]
                    // })
                }
            )
    }

    const onFormValueChange = (changeValue, values) => {
        const { demandClassification = 'all', groupBy = 'all' } = values
        selectChange(demandClassification, groupBy)
    }

    useEffect(() => {
        selectChange()
        return () => {
            console.log('pie 销毁')
        }
    }, [])

    return (
        <DashboardCardComponent
            title={'TRUE SAPI Reusability Pie Chart'}
            className={'reusability-pie-chart-card'}
        >
            <DataForm
                name="search-form-pie-chart"
                column={2}
                labelCol={{ span: 9 }}
                labelAlign="left"
                ref={dataFormRef}
                onValuesChange={onFormValueChange}
            >
                <DataForm.Item
                    name="groupBy"
                    label="Group by"
                    initialValue="all"
                >
                    <Select style={{ width: '11.43em' }}>
                        {GROUP_BY_LIST.map(item => (
                            <Option value={item.value} key={item.value}>
                                {item.name}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item
                    name="demandClassification"
                    label="Demand Classification"
                    initialValue="all"
                >
                    <Select style={{ width: '11.43em' }}>
                        <Option value="all">All</Option>
                        {dictUtil.dicts('api_classification', dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
            </DataForm>

            <ReactEchartsCore
                className={ECHARTS_DECREASE_TOP_CLASS}
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                notMerge={true}
                style={{ height: 300 }}
            />
        </DashboardCardComponent>
    )
}

export default ReusabilityPieChartCard
