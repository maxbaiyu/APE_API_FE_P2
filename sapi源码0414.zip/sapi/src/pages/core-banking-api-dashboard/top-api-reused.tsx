import React, { useState, useEffect, useRef } from 'react'
import 'echarts/lib/chart/bar'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import { RequestParams } from '~/core/http'
import { Select } from 'antd'
import DataForm from '~/shared/components/data-form'
import DashboardCardComponent from './dashboard-card-component'
import { topApiReusedOption } from './dashboardInitData'
import { ECHARTS_DECREASE_TOP_CLASS } from './type'

const { Option } = Select

interface ExtentdProps {
    dictUtil: any
    dashboardService: any
}

interface ChartDataProps {
    yAxisData: string[]
    data: number[]
}

const TopApiReusedChartCard: React.FC<ExtentdProps> = props => {
    const { dictUtil, dashboardService } = props

    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [groupBy, setGroupBy] = useState<string | any>('apiName')
    const [pieOption, setPieOption] = useState<any>(topApiReusedOption)

    const dataFormRef: any = useRef<HTMLDivElement>(null)
    const dataMap = useRef<Map<any, any>>(new Map())

    const initStatic = () => {
        dashboardService.top(new RequestParams()).subscribe(
            data => {
                if (Array.isArray(data) && data.length) {
                    const apiNameAll: ChartDataProps = {
                        yAxisData: [],
                        data: []
                    }
                    const apiName03: ChartDataProps = {
                        yAxisData: [],
                        data: []
                    }
                    const apiName04: ChartDataProps = {
                        yAxisData: [],
                        data: []
                    }
                    const apiName05: ChartDataProps = {
                        yAxisData: [],
                        data: []
                    }
                    const featureAllData: ChartDataProps = {
                        yAxisData: [],
                        data: []
                    }
                    data.forEach(item => {
                        if (item.groupBy == 'apiName') {
                            if (item.demandClassification == '03') {
                                apiName03.yAxisData.push(item.name)
                                apiName03.data.push(item.count)
                            } else if (item.demandClassification == '04') {
                                apiName04.yAxisData.push(item.name)
                                apiName04.data.push(item.count)
                            } else if (item.demandClassification == '05') {
                                apiName05.yAxisData.push(item.name)
                                apiName05.data.push(item.count)
                            } else if (item.demandClassification == 'all') {
                                apiNameAll.yAxisData.push(item.name)
                                apiNameAll.data.push(item.count)
                            }
                        } else {
                            featureAllData.yAxisData.push(item.name)
                            featureAllData.data.push(item.count)
                        }
                    })
                    dataMap.current.set('apiName03', apiName03)
                    dataMap.current.set('apiName04', apiName04)
                    dataMap.current.set('apiName05', apiName05)
                    dataMap.current.set('apiNameall', apiNameAll)
                    dataMap.current.set('featureall', featureAllData)

                    selectChange('apiName', 'all')
                }
            },
            error => {
                setShowLoading(false)
                
            }
        )
    }

    const selectChange = (groupBy, reusedCatagory) => {
        if (dataMap.current.size) {
            setShowLoading(false)
            const { yAxisData = [], data = [] } = dataMap.current.get(
                `${groupBy}${reusedCatagory}`
            )
            setPieOption({
                ...pieOption,
                yAxis: {
                    ...pieOption.yAxis,
                    name: groupBy === 'apiName' ? 'API Name' : 'Feature',
                    data: yAxisData.slice().reverse()
                },
                series: [
                    {
                        ...pieOption.series[0],
                        data: data.slice().reverse()
                    }
                ]
            })
        }
    }

    useEffect(() => {
        setShowLoading(false)
        initStatic()
    }, [])

    return (
        <DashboardCardComponent
            title={'TOP 10 Reused TRUE SAPI'}
            className={'top-chart-card'}
        >
            <DataForm
                name="search-form-top10"
                column={2}
                labelCol={{ span: 10 }}
                labelAlign="left"
                ref={dataFormRef}
            >
                <DataForm.Item
                    name="groupBy"
                    label="Group by"
                    initialValue="apiName"
                >
                    <Select
                        //style={{ width: 200 }}
                        onChange={value => {
                            setGroupBy(value)
                            dataFormRef.current?.formInstance?.resetFields([
                                'demandClassification'
                            ])
                            selectChange(value, 'all')
                        }}
                    >
                        <Option value="apiName">API name</Option>
                        <Option value="feature">Feature</Option>
                    </Select>
                </DataForm.Item>

                {groupBy === 'apiName' ? (
                    <DataForm.Item
                        name="demandClassification"
                        label="Demand Classification"
                        initialValue="all"
                    >
                        <Select
                            //style={{ width: 200 }}
                            onChange={value => {
                                selectChange('apiName', value)
                            }}
                        >
                            <Option value="all">All</Option>
                            {dictUtil.dicts('api_classification', dict => {
                                if (
                                    dict.dirCode !== '01' &&
                                    dict.dirCode !== '02'
                                ) {
                                    return (
                                        <Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Option>
                                    )
                                }
                            })}
                        </Select>
                    </DataForm.Item>
                ) : (
                    <DataForm.Item
                        name="demandClassification"
                        label=""
                        initialValue="all"
                    ></DataForm.Item>
                )}
            </DataForm>

            <ReactEchartsCore
                className={ECHARTS_DECREASE_TOP_CLASS}
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                notMerge={true}
                style={{ height: 350 }}
            />
        </DashboardCardComponent>
    )
}

export default TopApiReusedChartCard
