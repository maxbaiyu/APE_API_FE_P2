import React, { useState, useEffect, useRef } from 'react'
import { useHistory } from 'react-router-dom'
import { Descriptions, Row, Col, Divider } from 'antd'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import DashboardCardComponent from './dashboard-card-component'
import { averageCostItems, ROLE28 } from './type'

interface ExtendProps {
    userStore: any
}

const reviewService = new ReviewService()

const StatisticsCard: React.FC<ExtendProps> = props => {
    const { userStore } = props

    const [outstandApprovalData, setOutstandApproval] = useState<any>({})
    const [averageCostList, setAverageCostList] = useState<any>(
        averageCostItems
    )
    const [isRole28, setIsRole28] = useState<boolean>(true)
    const {
        demandApprovalDuesoon,
        demandApprovalOverdue,
        demandApprovalTotal,
        designApprovalDuesoon,
        designApprovalOverdue,
        designApprovalTotal,
        designReviewDuesoon,
        designReviewOverdue,
        designReviewTotal
    } = outstandApprovalData

    const history = useHistory()

    const outstandApproval = () => {
        reviewService
            .outstandingApproval(new RequestParams({}))
            .subscribe(data => {
                setOutstandApproval(data)
            })
    }

    const averageCost = () => {
        reviewService.averageCost(new RequestParams({})).subscribe(
            data => {
                if (Array.isArray(data) && data.length) {
                    const res = data.map((item, index) => ({
                        ...item,
                        color: averageCostItems[index].color
                    }))
                    setAverageCostList(res)
                }
            },
            error => {
                // delete
                // const { data } = require('./mock')
                // if (Array.isArray(data) && data.length) {
                //     const res = data.map((item, index) => ({
                //         ...item,
                //         color: averageCostItems[index].color
                //     }))
                //     setAverageCostList(res)
                // }
            }
        )
    }

    const jumpForm = (jumpPath, params) => {
        const pathname =
            jumpPath === 'demand'
                ? '/pages/api-demand-request-list'
                : '/pages/api-review-request-list'
        const search = params
        history.push({
            pathname,
            search
        })
    }

    useEffect(() => {
        const isRole28 = ROLE28.some(role =>
            userStore?.state?.roleList.map(x => x.authority).includes(role)
        )
        isRole28 && outstandApproval()
        averageCost()
        setIsRole28(isRole28)
    }, [])

    return (
        <>
            {isRole28 && (
                <DashboardCardComponent
                    title={'Outstanding Approval'}
                    className={'statistics-card'}
                >
                    <Descriptions
                        //title="Outstanding Approval"
                        layout="vertical"
                        className={'outstanding-approval'}
                        // column={5}
                    ></Descriptions>
                    <div className={'home-page-approval'}>
                        <Row align="middle">
                            <Col span={3}></Col>
                            <Col span={7}>Demand Approval</Col>
                            <Col span={7}>Design Review</Col>
                            <Col span={7}>Design Approval</Col>
                        </Row>
                        <Row align="middle">
                            <Col span={3}>Total Pending Approval</Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('demand', 'demandApprovalTotal')
                                }
                            >
                                {demandApprovalTotal}
                            </Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('review', 'designReviewTotal')
                                }
                            >
                                {designReviewTotal}
                            </Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('demand', 'designApprovalTotal')
                                }
                            >
                                {designApprovalTotal}
                            </Col>
                        </Row>
                        <Row align="middle">
                            <Col span={3}>Due Soon</Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('demand', 'demandApprovalDuesoon')
                                }
                            >
                                {demandApprovalDuesoon}
                            </Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('review', 'designReviewDuesoon')
                                }
                            >
                                {designReviewDuesoon}
                            </Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('demand', 'designApprovalDuesoon')
                                }
                            >
                                {designApprovalDuesoon}
                            </Col>
                        </Row>
                        <Row align="middle">
                            <Col span={3}>Overdue</Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('demand', 'demandApprovalOverdue')
                                }
                            >
                                {demandApprovalOverdue}
                            </Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('review', 'designReviewOverdue')
                                }
                            >
                                {designReviewOverdue}
                            </Col>
                            <Col
                                span={7}
                                onClick={() =>
                                    jumpForm('demand', 'designApprovalOverdue')
                                }
                            >
                                {designApprovalOverdue}
                            </Col>
                        </Row>
                    </div>
                </DashboardCardComponent>
            )}

            <DashboardCardComponent
                title={'Average Cost by Reuse Category'}
                className={'statistics-card'}
            >
                <Descriptions
                    //title="Average Cost by Reuse Category"
                    layout="vertical"
                    className={'average-cost-by-reuse-category'}
                    column={5}
                >
                    {averageCostList.map((item, index) => (
                        <Descriptions.Item
                            key={`average-cost${index}`}
                            label={item.name}
                            contentStyle={{ color: item.color }}
                            span={item.span ? item.span : 1}
                        >
                            {item.value ? `${item.value}k` : '0k'}
                        </Descriptions.Item>
                    ))}
                </Descriptions>
            </DashboardCardComponent>
        </>
    )
}

export default StatisticsCard
