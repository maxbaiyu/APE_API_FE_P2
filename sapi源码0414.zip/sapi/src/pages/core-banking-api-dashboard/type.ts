interface averageCostProps {
    name?: string
    label?: string
    color?: string
    value?: string | number
    span?: number
}

export const colorArr = [
    '#14A5AB',
    '#4FA62F',
    '#E67310',
    '#D71E8D',
    '#834EFF',
    '#2580DC',
    '#6D8EA6'
]

export const ECHARTS_DECREASE_TOP_CLASS = 'echarts-need-decrease-top'

export const averageCostItems: averageCostProps[] = [
    {
        name: 'New',
        color: '#D71E8D'
    },
    {
        name: 'New to Replace',
        color: '#E67310'
    },

    {
        name: 'Reuse with version Change',
        color: '#834EFF'
    },
    {
        name: 'Reuse with minor Change',
        color: '#4FA62F'
    },
    {
        name: 'Reuse Direct',
        color: '#2580DC'
    }
]

export const ROLE28 = [
    'ROLE_02',
    'ROLE_03',
    'ROLE_04',
    'ROLE_05',
    'ROLE_06',
    'ROLE_07',
    'ROLE_08'
]

export const GROUP_BY_LIST = [
    { name: 'All', value: 'all' },
    { name: 'Product', value: 'product' },
    { name: 'Region', value: 'region' },
    { name: 'Capability', value: 'capability' },
    { name: 'GB/GF', value: 'gbge' }
]

export const PIE_CHART_DEMAND_CORRESPONDENCE = {
    all: 'all',
    '01': 'new',
    '02': 'newToReplace',
    '03': 'reuseVersion',
    '04': 'reuseMinor',
    '05': 'reuseDirect'
}
