import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import DataTable from '~/shared/components/data-table'
import Column from 'antd/lib/table/Column'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { Form, Input, Select, DatePicker, Button } from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import { ApiService } from '~/services/api.service'
import { PageService } from '~/bootstrap/services/page.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import { dataConvert } from '~/shared/utils/form.data.convert';
import { SortService } from '~/bootstrap/services/sort.service'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { download } from '~/shared/utils/common.util'
import { layOutSize } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'
const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface APICatalogueListState {
    dataSource: any[]
    selectedRowKeys: any[]
    featureData: any[]
    serviceData: any[]
    fieldsValues: any
    Loading:boolean
}

interface APICatalogueListProps {}

export default class APICatalogueList extends Component<
    RouteComponentProps<APICatalogueListProps>,
    APICatalogueListState
> {
    private dictUtil = new DictUtil()

    private apiService = new ApiService()
    private pageService = new PageService()
    private sortService = new SortService({
        modifyTime: 'DESC'
    })
    private searchFormRef!: React.RefObject<DataForm>

    constructor(props) {
        super(props)
        this.searchFormRef = React.createRef()
        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            featureData: [],
            serviceData: [],
            fieldsValues: {},
            Loading:true
        }
    }
    public componentDidMount() {
        const state = this.props.location.state as APICatalogueListState;
        if (state && state.fieldsValues) {
            const fieldsValues = dataConvert(true, state.fieldsValues);
            this.searchForm.formInstance.setFieldsValue(fieldsValues);
        }
        this.getApiList()
    }

    public render() {
        const {
            dataSource,
            selectedRowKeys,
            featureData,
            serviceData,
            Loading
        } = this.state
        const { Option } = Select

        return (
            <components.PageContainer title="API Catalogue" noHeader={true}>
                <CardContainer title="Search">
                    <DataForm
                        name="filter-data-form"
                        column={2}
                        labelCol={{ span: 10 }}
                        labelAlign="left"
                        actions={this.renderFormAction()}
                        ref={this.searchFormRef}
                    >
                        <DataForm.Item
                            name="apiName"
                            label="API Name"
                            initialValue=""
                        >
                            <Input onPressEnter={this.replacement} />
                        </DataForm.Item>
                        <DataForm.Item
                            name="apiType"
                            label="API Type"
                            initialValue=""
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts('api_type', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="backEndSystem"
                            label="Backend system"
                            initialValue=""
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts('backend_system', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="status"
                            label="Status"
                            initialValue=""
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'catalogue_status_type',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="apiMethod"
                            label="API Method"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                <Select.Option value="GET">GET</Select.Option>
                                <Select.Option value="POST">POST</Select.Option>
                                <Select.Option value="PUT">PUT</Select.Option>
                                <Select.Option value="DELETE">
                                    DELETE
                                </Select.Option>
                            </Select>
                        </DataForm.Item>

                        <DataForm.Item
                            name="applicableGbGf"
                            label="Applicable GB/GF"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts('applicable_gb', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="capability"
                            label="Capability"
                            initialValue=""
                            collapse
                        >
                            <Select
                                allowClear
                                onChange={value => {
                                    this.searchForm.formInstance.resetFields([
                                        'feature'
                                    ])
                                    this.searchForm.formInstance.resetFields([
                                        'service'
                                    ])
                                    const features = this.dictUtil.dicts(value)
                                    this.setState({
                                        featureData: features
                                    })
                                }}
                            >
                                {this.dictUtil.dicts('capability', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="applicableChannels"
                            label="Applicable Channels"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'applicable_channels',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="feature"
                            label="Feature"
                            initialValue=""
                            collapse
                        >
                            <Select
                                allowClear
                                onChange={value => {
                                    this.searchForm.formInstance.resetFields([
                                        'service'
                                    ])
                                    const services = this.dictUtil.dicts(value)
                                    this.setState({
                                        serviceData: services
                                    })
                                }}
                            >
                                {featureData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>

                        <DataForm.Item
                            name="applicableCountries"
                            label="Applicable Countries"
                            initialValue=""
                            collapse
                        >
                            {/* <Select allowClear>
                                <Option value="Global">Global</Option>
                                <Option value="Regional">Regional</Option>
                                <Option value="Local">Local</Option>
                            </Select> */}
                            <Select allowClear>
                                {this.dictUtil.dicts(
                                    'applicable_countries',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item
                            name="service"
                            label="Service"
                            initialValue=""
                            collapse
                        >
                            <Select allowClear>
                                {serviceData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                    </DataForm>
                </CardContainer>
                <CardContainer title="API Catalogue">
                    <components.AuthDisableButton
                        auth={[
                            'ROLE_01',
                            'ROLE_02',
                            'ROLE_03',
                            'ROLE_04',
                            'ROLE_05',
                            'ROLE_06',
                            'ROLE_07',
                            'ROLE_08',
                            'ROLE_09',
                            'ROLE_10',
                            'ROLE_011'
                        ]}
                        //size="large"
                        style={{
                            marginTop: -55,
                            float: 'right'
                        }}
                        onClick={() => {
                            download(
                                appConfig.server + '/api/catalogue/export',
                                'API-Catalogue-Request-List.xls',
                                this.searchForm.formInstance.getFieldsValue()
                            )
                        }}
                    >
                        Export
                    </components.AuthDisableButton>
                    <DataTable
                        rowKey="apiCatalogueId"
                        dataSource={dataSource}
                        page={this.pageService}
                        loading={Loading}
                        onPageChange={() => this.getApiList()}
                        onChange={(pagination, filters, sorter) => {
                            if (sorter.order) {
                                this.sortService.update(
                                    sorter.columnKey,
                                    sorter.order
                                )
                            } else {
                                this.sortService.reset()
                            }
                            this.getApiList()
                        }}
                        // rowSelection={{
                        //     selectedRowKeys,
                        //     onChange: selectedRowKeys =>
                        //         this.setState({ selectedRowKeys })
                        // }}
                    >
                        <Column
                            title="API Name"
                            dataIndex="apiName"
                            key="apiName"
                            ellipsis={true}
                            sorter={true}
                            render={(text, row, index) => (
                                // <Button
                                //     type="link"
                                //     onClick={() => this.openForm(row)}
                                // >
                                //     {text}
                                // </Button>
                                <a
                                    onClick={() => this.openForm(row)}
                                    style={{ width: '290px' }}
                                >
                                    {text}
                                </a>
                            )}
                        />
                        <Column
                            title="Description"
                            dataIndex="description"
                            key="description"
                            // ellipsis={true}
                            render={val => (
                                <div
                                    style={{
                                        wordWrap: 'break-word',
                                        wordBreak: 'break-word',
                                        width: '380px'
                                    }}
                                >
                                    {val || ''}
                                </div>
                            )}
                        />
                        <Column
                            title="Backend System"
                            dataIndex="backEndSystem"
                            key="backEndSystem"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('backend_system', value)
                            }
                        />
                        <Column
                            title="API Method"
                            dataIndex="apiMethod"
                            key="apiMethod"
                            ellipsis={true}
                        />
                        <Column
                            title="API Type"
                            dataIndex="apiType"
                            key="apiType"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('api_type', value)
                            }
                        />
                        <Column
                            title="Status"
                            dataIndex="status"
                            key="status"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'catalogue_status_type',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Capability"
                            dataIndex="capability"
                            key="capability"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('capability', value)
                            }
                        />
                        <Column
                            title="Feature"
                            dataIndex="feature"
                            key="feature"
                            ellipsis={true}
                            render={(text, row: any, index) =>
                                this.dictUtil.filter(
                                    row.capability,
                                    row.feature
                                )
                            }
                        />
                        <Column
                            title="Service"
                            dataIndex="service"
                            key="service"
                            ellipsis={true}
                            render={(text, row: any, index) =>
                                this.dictUtil.filter(row.feature, row.service)
                            }
                        />
                        <Column
                            title="Applicable Countries"
                            dataIndex="applicableCountries"
                            key="applicableCountries"
                            ellipsis={true}
                            render={(text, row: any, index) => {
                                let context = ''
                                if (
                                    row.applicableCountries2 != null &&
                                    row.applicableCountries2 != ''
                                ) {
                                    context =
                                        this.dictUtil.filter(
                                            'applicable_countries',
                                            row.applicableCountries
                                        ) +
                                        ' - ' +
                                        row.applicableCountries2
                                } else {
                                    context = this.dictUtil.filter(
                                        'applicable_countries',
                                        row.applicableCountries
                                    )
                                }
                                return context
                            }}
                        />
                        <Column
                            title="Applicable Channels"
                            dataIndex="applicableChannels"
                            key="applicableChannels"
                            ellipsis={true}
                            render={(text, row: any, index) => {
                                let context = ''
                                if (
                                    row.applicableChannels2 != null &&
                                    row.applicableChannels2 != ''
                                ) {
                                    context =
                                        this.dictUtil.filter(
                                            'applicable_channels',
                                            row.applicableChannels
                                        ) +
                                        ' - ' +
                                        row.applicableChannels2
                                } else {
                                    context = this.dictUtil.filter(
                                        'applicable_channels',
                                        row.applicableChannels
                                    )
                                }
                                return context
                            }}
                        />
                        <Column
                            title="Applicable GB/GF"
                            dataIndex="applicableGbGf"
                            key="applicableGbGf"
                            ellipsis={true}
                            render={(text, row: any, index) => {
                                let context = ''
                                if (
                                    row.applicableGbGf2 != null &&
                                    row.applicableGbGf2 != ''
                                ) {
                                    context =
                                        this.dictUtil.filter(
                                            'applicable_gb',
                                            row.applicableGbGf
                                        ) +
                                        ' - ' +
                                        row.applicableGbGf2
                                } else {
                                    context = this.dictUtil.filter(
                                        'applicable_channels',
                                        row.applicableGbGf
                                    )
                                }
                                return context
                            }}
                        />

                        <Column
                            title="Latest Version"
                            dataIndex="latestVersion"
                            key="latestVersion"
                            ellipsis={true}
                        />
                    </DataTable>
                </CardContainer>
            </components.PageContainer>
        )
    }
    private openForm(row) {
        const fieldsValues = dataConvert(false, this.searchForm.formInstance.getFieldsValue());
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                apiCatalogueId: row.apiCatalogueId,
                fieldsValues,
                pathName:'/pages/api-catalogue'
            },
            search:`apiCatalogueId=${row.apiCatalogueId}`
        })
    }
    private renderFormAction() {
        return (
            <Button type="primary" danger onClick={() => this.replacement()} size={layOutSize()}>
                Search
            </Button>
        )
    }
    private replacement= () =>{
        this.setState({
            Loading:true
        })
        this.pageService.reset()
          this.sortService.reset()
          this.getApiList()
       }
    getApiList= () => {
        this.apiService
            .catalogueAll(
                new RequestParams(
                    Object.assign(
                        this.searchForm.formInstance.getFieldsValue(),
                        {}
                    ),
                    {
                        page: this.pageService,
                        sort: this.sortService
                    }
                )
            )
            .subscribe(data => {
                setTimeout(this.send,500)
                this.setState({
                    dataSource: data,
                })
            })
    }
    private send  = () =>{
        this.setState({
            Loading:false
        })
    }
    private get searchForm(): DataForm {
        return this.searchFormRef.current as DataForm
    }
}
