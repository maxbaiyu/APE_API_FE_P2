import React, { ReactNode, useState, useEffect } from 'react'
import { Input, Select, DatePicker, Form, InputNumber, message ,Button} from 'antd'
import { ApiService } from '~/services/api.service'
import { RequestParams } from '~/core/http'
import moment from 'moment'
import { isNullOrUndefined } from 'util'
import { DictUtil } from '~/shared/utils/dict.util'
import debounce from 'lodash/debounce'
import { proInfoItemProps } from './data'
import imgsrcHelp from '~/assets/images/Help.png'
import imgsrcQm from '~/assets/images/qm.png'
import { rulesdata } from '~/assets/regular/rest'

const dictUtil = new DictUtil()
const apiSevice = new ApiService()

export interface formItemProps {
    dataFormRef: any
    formItemDatas: proInfoItemProps[]
    fieldName?: any
    fieldKey?: any
    currentStep?: Number
}

const FormItemComponent: React.FC<formItemProps> = props => {
    const [formItemDatas, setFormItemDatas] = useState<proInfoItemProps[]>(
        props.formItemDatas
    )
    const [inputType, setInputType] = useState<String>('01')
    const [hover, setHover] = useState<Boolean>(false)

    const renderTips = () => {
        return (
            <>
                <div
                    className={'tips-img'}
                    onClick={() => {
                        setHover(!hover)
                    }}
                >
                    <img width="20" src={hover ? imgsrcQm : imgsrcHelp}></img>
                </div>
                <div
                    className={hover ? 'link-style-block' : 'link-style-none'}
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Terminology'
                        )
                    }}
                >
                    <div className={'link-style-block-text'}></div>
                    <div style={{}} className={'link-style-block-kuang'}></div>
                    Refer to Core Banking TRUE SAPI Terminology
                </div>
            </>
        )
    }

    const renderLink = () => {
        return (
            <Button
                type="link"
                className={'tips-img tips-apiName-link'}
                onClick={() => {
                    window.open(
                        `https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Naming+Convention`
                    )
                }}
            >
                API Naming Standard
            </Button>
        )
    }

    const renderItem = (itemFormData, index) => {
        const {
            type = 'div',
            disabled,
            optionUtilsKey,
            options,
            name,
            isExist,
            onSearchPro,
            selectKey,
            selectValue,
            selectName,
            labelInValue
        } = itemFormData
        let item: ReactNode = <></>
        let style = {}
        if (typeof isExist === 'function' && !isExist(inputType)) {
            style['display'] = 'none'
        }
        switch (type) {
            case 'input':
                if (
                    inputType !== '01' &&
                    inputType !== '02' &&
                    name === 'apiName'
                ) {
                    return
                }
                item = (
                    <Input
                        style={{ width: 560 }}
                        disabled={disabled}
                        onBlur={event => {
                            inputBlur(event)
                        }}
                    />
                )
                break
            case 'inputNumber':
                const { inputProps } = itemFormData
                item = (
                    <Input
                        type="number"
                        prefix="$"
                        suffix="K (USD)"
                        // style={{ width: 240 }}
                        {...inputProps}
                    />
                )
                break
            case 'select':
                // optionUtilsKey 有值，采用字典处理数据，如果无值，则采用options数据设置
                item = (
                    <Select
                        style={{ width: 560 }}
                        disabled={disabled}
                        labelInValue={labelInValue}
                        onChange={value => {
                            selectOnChange(value, name, index, itemFormData)
                        }}
                    >
                        {optionUtilsKey
                            ? dictUtil.dicts(optionUtilsKey, dict => (
                                  <Select.Option
                                      key={dict[selectKey]}
                                      value={dict[selectValue]}
                                  >
                                      {dict[selectName]}
                                  </Select.Option>
                              ))
                            : options.map(option => {
                                  return (
                                      <Select.Option
                                          key={option[selectKey]}
                                          value={option[selectValue]}
                                      >
                                          {option[selectName]}
                                      </Select.Option>
                                  )
                              })}
                    </Select>
                )
                break
            case 'debounceSelect':
                const { dropdownClassName } = itemFormData
                if (
                    (inputType == '01' || inputType == '02') &&
                    name === 'apiName'
                ) {
                    return
                }
                let projectNameOptions
                item = (
                    <Select
                        style={{ width: 560 }}
                        showSearch
                        defaultActiveFirstOption={false}
                        showArrow={false}
                        filterOption={false}
                        notFoundContent={null}
                        labelInValue={labelInValue}
                        dropdownClassName={dropdownClassName}
                        onSearch={debounce(value => {
                            const initFormItemDatas = [...formItemDatas]
                            if (name === 'apiName') {
                                const fieldsValue = props?.dataFormRef.current.formInstance.getFieldsValue()
                                let back = ''
                                if (props.fieldName == undefined) {
                                    // 非嵌套form
                                    back = fieldsValue?.backEndSystem
                                } else {
                                    // 嵌套form
                                    back =
                                        fieldsValue?.ossApiDemand[
                                            props.fieldName
                                        ].backEndSystem
                                }
                                onSearchPro(value, back).then(res => {
                                    initFormItemDatas[index] = {
                                        ...itemFormData,

                                        options: res
                                    }
                                    setFormItemDatas(initFormItemDatas)
                                })
                            } else if (name === 'projectName') {
                                onSearchPro(value).then(res => {
                                    projectNameOptions = res

                                    if (name === 'projectName') {
                                        // 但返回数据为空 reset projectName value
                                        props?.dataFormRef.current.formInstance.setFieldsValue(
                                            {
                                                projectName: value
                                            }
                                        )
                                        if (!res.length) {
                                            projectNameOptions = [
                                                { projectName: value }
                                            ]
                                        }
                                    }
                                    initFormItemDatas[index] = {
                                        ...itemFormData,
                                        dropdownClassName: res.length
                                            ? ''
                                            : 'demand-debounce-select-no-data',
                                        options: projectNameOptions
                                    }
                                    setFormItemDatas(initFormItemDatas)
                                })
                            }
                        }, 200)}
                        onChange={value => {
                            selectOnChange(value, name, index, itemFormData)
                        }}
                        onBlur={() => {
                            if (name === 'projectName') {
                                const initFormItemDatas = [...formItemDatas]
                                initFormItemDatas[index] = {
                                    ...itemFormData,
                                    dropdownClassName:
                                        projectNameOptions &&
                                        projectNameOptions.length
                                            ? ''
                                            : 'demand-debounce-select-no-data',
                                    options: []
                                }
                                setFormItemDatas(initFormItemDatas)
                            }
                        }}
                    >
                        {options.map(option => (
                            <Select.Option
                                key={option[selectKey]}
                                value={option[selectValue]}
                            >
                                {option[selectName]}
                            </Select.Option>
                        ))}
                    </Select>
                )
                break
            case 'datePicker':
                item = (
                    <DatePicker
                        disabled={disabled}
                        style={{ width: 560 }}
                        format="MM/DD/yyyy"
                    />
                )
                break
            case 'multComponentBpid':
                item = (
                    <Input.Group compact style={{ width: 560 }}>
                        <Form.Item
                            name="gdpmInterLockBpid"
                            style={{ width: '50%' }}
                            rules={[
                                {
                                    message: 'BPID can only contain numbers.',
                                    pattern: rulesdata.patternNum
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="gdpmInterLockBpidYear"
                            className="api-data-picker"
                            style={{ width: '50%' }}
                            initialValue={moment(String(new Date().getFullYear()))}
                        >
                            <DatePicker format="yyyy" picker="year" />
                        </Form.Item>
                    </Input.Group>
                )
                break
            default:
                break
        }
        const { label, className, rules, validateTrigger,initialValue } = itemFormData
        const itemProps = { label, name, className, rules, validateTrigger,initialValue }
        let tips: ReactNode = renderTips()
        if (props.currentStep === 2) {
            // form list 循环
            const addProps = {
                name: [props.fieldName, name],
                fieldKey: [props.fieldKey, name]
            }
            if (name === 'demandClassification') {
                return (
                    <Form.Item {...itemProps} {...addProps} style={style}>
                        {item}
                    </Form.Item>
                )
            }
            return (
                <Form.Item {...itemProps} {...addProps} style={style}>
                    {item}
                </Form.Item>
            )
        }
        if (name === 'demandClassification') {
            // step 2 单独的特殊处理
            return (
                <>
                    <Form.Item {...itemProps} style={style}>
                        {item}
                    </Form.Item>
                    {tips}
                </>
            )
        }
        if (name === 'apiName') {
            const link: ReactNode = renderLink()
            return (
                <>
                    <Form.Item {...itemProps} style={style}>
                        {item}
                    </Form.Item>
                    {link}
                </>
            )
        }
        if (name === 'gdpmInterLockBpid' && type.includes('multComponent')) {
            delete itemProps.name
        }
        return (
            <Form.Item {...itemProps} style={style} key={name}>
                {item}
            </Form.Item>
        )
    }

    const selectOnChange = (value, name, index, itemFormData) => {
        const initFormItemDatas = [...formItemDatas]
        if (name === 'region') {
            // 处理region和site的联动
            const countries = dictUtil.dicts(value)

            initFormItemDatas[index + 1] = {
                ...initFormItemDatas[index + 1],
                options: countries
            }
            setFormItemDatas(initFormItemDatas)
            if (itemFormData.resetFields) {
                props?.dataFormRef.current.formInstance.resetFields(
                    itemFormData.resetFields
                )
            }
        }

        if (name === 'demandClassification') {
            // todo 此值是否要重置
            setInputType(value)
        }

        if (name === 'apiName') {
            // 特殊处理： API Name与Reused API Version的联动
            const { options } = itemFormData
            const selectedRow = options.filter(
                x => x.apiCatalogueId === value.value
            )
            if (
                selectedRow &&
                selectedRow.length &&
                selectedRow[0].versionList
            ) {
                if (props.fieldName === undefined) {
                    // 非嵌套
                    props?.dataFormRef.current?.formInstance?.setFieldsValue({
                        apiType: selectedRow[0].apiType
                    })
                } else {
                    const fieldValues = props?.dataFormRef.current?.formInstance?.getFieldsValue()
                    const demandInfoMod = fieldValues?.ossApiDemand
                    if (demandInfoMod && demandInfoMod[props.fieldName]) {
                        demandInfoMod[props.fieldName].apiType =
                            selectedRow[0].apiType
                        props?.dataFormRef.current?.formInstance?.setFieldsValue(
                            {
                                ...fieldValues,
                                ossApiDemand: demandInfoMod
                            }
                        )
                    }
                }

                initFormItemDatas[index + 2] = {
                    ...initFormItemDatas[index + 2],
                    options: selectedRow[0].versionList
                }
            }
            setFormItemDatas(initFormItemDatas)
        }

        if (name === 'projectName') {
            //如果返回为空，
            const { options } = itemFormData
            if (options.length) {
                const filedValues = options.find(
                    item => item.projectName === value
                )
                if (filedValues) {
                    const {
                        region,
                        receivedDate,
                        gdpmInterLockBpidYear
                    } = filedValues
                    // 处理region country联动
                    const countries = dictUtil.dicts(region)
                    const countryIndex = initFormItemDatas.findIndex(
                        item => item.name === 'country'
                    )
                    initFormItemDatas[countryIndex] = {
                        ...initFormItemDatas[countryIndex],
                        options: countries
                    }
                    setFormItemDatas(initFormItemDatas)
                    props?.dataFormRef.current.formInstance.setFieldsValue({
                        ...filedValues,
                        gdpmInterLockBpidYear:
                            isNullOrUndefined(gdpmInterLockBpidYear) ||
                            gdpmInterLockBpidYear === ''
                                ? ''
                                : moment(gdpmInterLockBpidYear),
                        receivedDate:
                            isNullOrUndefined(receivedDate) ||
                            receivedDate === ''
                                ? ''
                                : moment(filedValues.receivedDate)
                    })
                }
            }
        }

        if (name === 'reuseApiVersion') {
            const versionItem = itemFormData.options.find(
                item => item.versionId == value.value
            )
            const {
                cbSysContact,
                createByAccName,
                designReviewStatus
            } = versionItem
            if (designReviewStatus !== '4') {
                message.warn(
                    `There's a reused version is under review, please contact ${cbSysContact} or ${createByAccName} to get align on the API version.`
                )
            }
        }

        if (name === 'backEndSystem') {
            initFormItemDatas[index + 2] = {
                ...initFormItemDatas[index + 2],
                options: []
            }
            setFormItemDatas(initFormItemDatas)
        }
    }

    const limitDecimals = value => {
        const reg = /^(\-)*(\d+)\.(\d\d).*$/
        if (typeof value === 'string') {
            return !isNaN(Number(value)) ? value.replace(reg, '$1$2.$3') : ''
        } else if (typeof value === 'number') {
            return !isNaN(value) ? String(value).replace(reg, '$1$2.$3') : ''
        } else {
            return ''
        }
    }

    const inputBlur = event => {
        const fieldsValue = props?.dataFormRef.current.formInstance.getFieldsValue()
        if (
            event.target?.id.includes('apiName') ||
            event.target?.id.includes('backEndSystem')
        ) {
            if (event.target?.id.includes('ossApiDemand')) {
                const { apiName, backEndSystem } = fieldsValue?.ossApiDemand[
                    props.fieldName
                ]
                verifyAPIName(apiName, backEndSystem)
            } else {
                verifyAPIName(fieldsValue?.apiName, fieldsValue?.backEndSystem)
            }
        }
    }

    const getInputType = () => {
        const fieldValues = props?.dataFormRef.current?.formInstance?.getFieldsValue()
        if (props.fieldName === undefined) {
            // 非嵌套
            setInputType(
                fieldValues?.demandClassification
                    ? fieldValues?.demandClassification
                    : '01'
            )
        } else {
            setInputType(
                fieldValues?.ossApiDemand[props.fieldName]?.demandClassification
                    ? fieldValues?.ossApiDemand[props.fieldName]
                          ?.demandClassification
                    : '01'
            )
        }
    }

    const verifyAPIName = (apiName, backEndSystem = '') => {
        if (inputType === '01' || inputType === '02') {
            if (typeof apiName === 'string' && apiName && backEndSystem) {
                apiSevice
                    .checking(
                        new RequestParams(
                            { backEndSystem },
                            { append: [apiName] }
                        )
                    )
                    .subscribe(data => {
                        if (data.status !== 1) {
                            message.error('Api Name error')
                        }
                    })
            }
        }
    }

    useEffect(() => {
        getInputType()
    }, [props?.dataFormRef.current?.formInstance?.getFieldsValue()])

    return <>{formItemDatas.map((item, index) => renderItem(item, index))}</>
}

export default FormItemComponent
