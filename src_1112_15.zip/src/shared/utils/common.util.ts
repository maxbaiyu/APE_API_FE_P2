/**
 * date format
 * @param date
 * @param fmt date format pattern
 */
export function dateFormat(date, fmt = 'yyyy-MM-dd'): string {
    // null data return
    if (date === null || date === undefined || date === '') {
        return ''
    }

    // long timestapm ,convert to Date
    if (typeof date === 'number') {
        date = new Date(date)
    }

    let o = {
        'M+': date.getMonth() + 1, // Moneth
        'd+': date.getDate(), // date
        'h+': date.getHours(), // hour
        'm+': date.getMinutes(), // minute
        's+': date.getSeconds(), // second
        'q+': Math.floor((date.getMonth() + 3) / 3), // quarter
        S: date.getMilliseconds() // millisecond
    }

    if (/(y+)/.test(fmt))
        fmt = fmt.replace(
            RegExp.$1,
            (date.getFullYear() + '').substr(4 - RegExp.$1.length)
        )

    for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt))
            fmt = fmt.replace(
                RegExp.$1,
                RegExp.$1.length === 1
                    ? o[k]
                    : ('00' + o[k]).substr(('' + o[k]).length)
            )
    }
    return fmt
}

export function download(url, name) {
    const STORAGE_KEY = 'react-storage'
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')
    name = name || url
    // get download file object
    fetch(url, {
        method: 'GET', //
        headers: new Headers({
            Authorization: data.user.token
        })
    })
        .then(response => {
            if (response.status == 200) return response.blob()
            throw new Error(`status: ${response.status}.`)
        })
        .then(blob => {
            downloadFile(name, blob)
        })
        .catch(error => {
            console.log('failed. cause:', error)
        })
}

export function downloadFile(fileName, blob) {
    const anchor = document.createElement('a')
    const src = URL.createObjectURL(blob)
    anchor.download = fileName
    anchor.href = src
    anchor.setAttribute('style', 'visiable:hidden;')
    document.body.appendChild(anchor)
    anchor.click()
}
