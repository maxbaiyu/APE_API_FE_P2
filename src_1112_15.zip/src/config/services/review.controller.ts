/**
 * Review Service
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'review'

export const ReviewController = {
    // all
    all: {
        controller,
        action: 'all',
        type: RequestMethod.Get
    },
    // commit review comment
    comment: {
        controller,
        action: 'comment',
        type: RequestMethod.Post
    },
    // all
    comments: {
        controller,
        action: 'comments',
        type: RequestMethod.Get
    },
    // download contract, response file stream
    download: {
        controller,
        action: 'download',
        type: RequestMethod.Get
    },
    // approve review
    status: {
        controller,
        action: 'status',
        type: RequestMethod.Put
    },
    // upload review and contract info
    upload: {
        controller,
        action: 'upload',
        type: RequestMethod.Post
    },
    // get review detail
    get: {
        controller,
        type: RequestMethod.Get
    },
    // delete contract
    deleteContract: {
        controller,
        action: 'contract',
        type: RequestMethod.Delete
    },
    information: {
        controller,
        action: 'information',
        type: RequestMethod.Put
    },
    workflow: {
        controller,
        action: 'workflow',
        type: RequestMethod.Get
    },
    reopen: {
        controller,
        action: 'reopen',
        type: RequestMethod.Post
    }
}
