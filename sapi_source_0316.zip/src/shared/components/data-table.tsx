import React, { Key } from 'react'
import styled from 'styled-components'
import { Button, Table, Pagination } from 'antd'
import {
    SorterResult,
    TableCurrentDataSource,
    TablePaginationConfig,
    TableRowSelection
} from 'antd/lib/table/interface'
import { PageService } from '~/bootstrap/services/page.service'
import { layOutSize } from '~/shared/utils/common.util'

const components = {
    Wrapper: styled.section``,
    TabContainer: styled.div``,
    PageinationContainer: styled.div`
        padding: 10px 0;
    `,
    ActionContainer: styled.div`
        padding: 10px 0;
        .ant-btn {
            margin-right: 15px;
        }
    `
}

interface ComponentProp {
    rowKey: string
    page?: PageService
    dataSource: any[]
    loading?: boolean
    pageService?: PageService
    rowSelection?: TableRowSelection<Record<string, any>>
    height?: string
    actions?: React.ReactNode
    actionPosition?: 'top' | 'bottom'
    setX?: true | 'undefined'
    onPageChange?: () => void
    onChange?: (pagination: any, filters: any, sorter: any, extra: any) => void
}

interface ScrollProp {
    x?: string | number | true
    y?: number | string
}

export default class DataTable extends React.Component<
    ComponentProp
> {
    private default = {
        height: 100,
        actionPosition: 'bottom',
        setX: true
    }

    public render() {
        const { page } = this.props
        const actionPosition =
            this.props.actionPosition || this.default.actionPosition

        return (
            <components.Wrapper>
                {actionPosition === 'top' && this.renderActionContainer()}
                {this.renderTableContainer()}
                {page && this.renderPaginationContainer()}
                {actionPosition === 'bottom' && this.renderActionContainer()}
            </components.Wrapper>
        )
    }

    public renderActionContainer() {
        return (
            <components.ActionContainer>
                {this.props.actions}
            </components.ActionContainer>
        )
    }

    public renderTableContainer() {
        const {
            dataSource,
            rowSelection,
            height,
            rowKey,
            setX,
            loading,
            onChange
        } = this.props
        const scroll: ScrollProp = {
            x: setX === 'undefined' ? undefined : true,
            y: 500
        }
        if (this.props.dataSource && this.props.dataSource.length <= 10) {
            delete scroll.y
        }
        return (
            <components.TabContainer>
                <Table
                    rowKey={rowKey}
                    scroll={scroll}
                    rowSelection={
                        rowSelection
                            ? { fixed: true, ...rowSelection }
                            : rowSelection
                    }
                    dataSource={dataSource}
                    pagination={false}
                    loading={loading}
                    size={layOutSize()}
                    bordered
                    onChange={onChange}
                >
                    {this.props.children}
                </Table>
            </components.TabContainer>
        )
    }

    public renderPaginationContainer() {
        const pageConfig = this.getPageConfig()

        return (
            <components.PageinationContainer>
                <Pagination
                    showSizeChanger
                    onChange={this.onChange.bind(this)}
                    onShowSizeChange={this.onChange.bind(this)}
                    {...pageConfig}
                />
            </components.PageinationContainer>
        )
    }
    private onChange(pageIndex, pageSize) {
        const onPageChange = this.props.onPageChange
        const page = this.props.page as PageService

        page.update(pageIndex, pageSize).then(() => {
            onPageChange && onPageChange()
        })
    }

    private getPageConfig() {
        const page = this.props.page as PageService
        return {
            current: page.pageIndex,
            total: page.total,
            pageSize: page.pageSize,
            pageSizeOptions: page.pageSizeOpts,
            showTotal: () => `Total ${page.total} record(s)`
        }
    }
}
