import React, { useEffect, useRef, useCallback } from 'react'
import debounce from 'lodash/debounce'
import styled from 'styled-components'

const components = {
    Echarts: styled.div``
}

interface CardComponentsProps {
    id: string
    echarts: any
    option: any
    style?: React.CSSProperties
    className?: string
    theme?: string | Object
    opts?: {
        devicePixelRatio?: number
        renderer?: string
        width?: number | string
        height?: number | string
        locale?: string
    }
    showLoading: boolean
    loadingOption: Object
}

const EchartsComponent: React.FC<CardComponentsProps> = props => {
    // todo echarts实例直接来自子组件是否可行
    // todo 缩放事件
    const {
        id,
        option,
        className,
        style,
        theme = 'default',
        echarts,
        loadingOption = null,
        showLoading = false
    } = props

    const echartDOM: any = useRef<HTMLElement>(null)
    const echartInstance:any = useRef<any>(null)

    const resizeAll = echartInstance => {
        echartInstance?.current?.resize();
    }

    const renderChart = useCallback(() => {
        // debugger
        echartInstance.current = echarts.getInstanceByDom(echartDOM.current)
        if (!echartInstance.current) {
            // 重新创建实例
            echartInstance.current = echarts.init(echartDOM.current, theme)
            // todo 监听resize时间
            window.addEventListener('resize', resizeAll)
        }

        // // showLoading
        if (showLoading) {
            echartInstance.current.showLoading('default', loadingOption)
        } else {
            echartInstance.current.clear()
            echartInstance.current.hideLoading()
            echartInstance.current.setOption(option)
        }
    }, [option, echarts, theme, loadingOption, showLoading, echartDOM])

    const dispose = useCallback(() => {
        if (echartDOM.current) {
            try {
                // todo 卸载事件监听
                //unbind(echartDOM.current);
                window.removeEventListener('resize', resizeAll)
            } catch (error) {
                console.warn(error);
            }
            echartInstance.current.dispose(echartDOM.current)
            echartInstance.current = null;
        }
    }, [echarts, echartDOM])

    useEffect(() => {
        renderChart()
        return () => {
            echartDOM.current = null
            dispose()
        }
    }, [])

    useEffect(() => {
        renderChart()
    }, [option])

    useEffect(() => {
        dispose()
        renderChart()
    }, [theme])

    // 样式修改了，需要重新resize
    useEffect(() => {
        try {
            echartInstance.current.resize()
        } catch (error) {
            // console.warn(error);
        }
    }, [className, style, echartDOM, echarts])

    return (
        <components.Echarts
            id={id}
            ref={echartDOM}
            className={className}
            style={{
                position: 'relative',
                height: 400,
                ...style
              }}
        ></components.Echarts>
    )
}

export default EchartsComponent
