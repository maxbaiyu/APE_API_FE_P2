import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { ApiService } from '~/services/api.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import { download } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'
import moment from 'moment'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface ApiDetailState {
    demandId: string
    demandStatusid: string
    apiCatalogueId: string
    data: any
    selectVersion: any
    fieldsValues: any
    pathName: string
    searchParams: string
}

interface ApiDetailProps {}

export default class ApiDetail extends Component<
    RouteComponentProps<ApiDetailProps>,
    ApiDetailState
> {
    private dataFromRef!: React.RefObject<DataForm>

    private apiService = new ApiService()
    private dictUtil = new DictUtil()
    private applicableChannels = ''
    private applicableGbGf = ''
    private applicableCountries = ''
    private versionApplicableChannels = ''
    private versionApplicableGbGf = ''
    private versionApplicableCountries = ''
    private apiCatalogueIdTrue = ''
    constructor(props) {
        super(props)
        this.state = {
            demandId: '',
            demandStatusid: '',
            apiCatalogueId: '',
            data: {},
            selectVersion: {},
            fieldsValues: {},
            pathName: '',
            searchParams:''
        }
    }

    public componentDidMount() {
        try {
            const { apiCatalogueId } = this.props.location.state as ApiDetailState
            this.apiCatalogueIdTrue = apiCatalogueId
        } catch (error) {
            const searchArr = this.props.location.search.split('=')
            if (searchArr && searchArr.length >= 1) {
                this.apiCatalogueIdTrue = searchArr[1]
            }
        }
        this.apiService
            .getById(new RequestParams({}, { append: [this.apiCatalogueIdTrue] }))
            .subscribe(data => {
                this.setState({
                    data: data,
                    selectVersion: data.apiVersionResponses[0]
                })
            })
    }

    public render() {
        const columns = [
            {
                title: 'API Version',
                dataIndex: 'version'
            },
            {
                title: 'Consumer',
                dataIndex: 'consumer'
            },
            {
                title: 'API Lifecycle Stage',
                dataIndex: 'apiLifecycleStage',
                render: (text, record) =>
                    this.dictUtil.filter('api_lifecycle_stage', text)
            },
            {
                title: 'Applicable Countries',
                dataIndex: 'applicableCountries',
                render: (text, record) => {
                    let context = ''
                    if (record?.applicableCountries2 != null && record?.applicableCountries2 !='') {
                        context =
                            this.dictUtil.filter(
                                'applicable_countries',
                                record?.applicableCountries
                            ) +' - '+
                            record?.applicableCountries2
                    } else {
                        context = this.dictUtil.filter(
                            'applicable_countries',
                            record?.applicableCountries
                        )
                    }
                    return context
                }
            },
            {
                title: 'Edit ',
                render: (text, record) => (
                    <components.AuthDisableButton
                        type="primary"
                        onClick={() => this.openForm2(record)}
                        auth={['ROLE_01','ROLE_011']}
                    >
                        Edit
                    </components.AuthDisableButton>
                )
            }
        ]

        const { data, selectVersion } = this.state
        const { ossApi, apiVersionResponses } = data

        if (ossApi?.applicableChannels2 != null) {
            this.applicableChannels =
                this.dictUtil.filter(
                    'applicable_channels',
                    ossApi?.applicableChannels
                ) +
                '  -  ' +
                ossApi?.applicableChannels2
        } else {
            this.applicableChannels = this.dictUtil.filter(
                'applicable_channels',
                ossApi?.applicableChannels
            )
        }
        if (ossApi?.applicableGbGf2 != null) {
            this.applicableGbGf =
                this.dictUtil.filter('applicable_gb', ossApi?.applicableGbGf) +
                '  -  ' +
                ossApi?.applicableGbGf2
        } else {
            this.applicableGbGf = this.dictUtil.filter(
                'applicable_gb',
                ossApi?.applicableGbGf
            )
        }

        if (selectVersion?.applicableChannels2 != null) {
            this.versionApplicableChannels =
                this.dictUtil.filter(
                    'applicable_channels',
                    selectVersion?.applicableChannels
                ) +
                '  -  ' +
                selectVersion?.applicableChannels2
        } else {
            this.versionApplicableChannels = this.dictUtil.filter(
                'applicable_channels',
                selectVersion?.applicableChannels
            )
        }
        if (selectVersion?.applicableGbGf2 != null) {
            this.versionApplicableGbGf =
                this.dictUtil.filter(
                    'applicable_gb',
                    selectVersion?.applicableGbGf
                ) +
                '  -  ' +
                selectVersion?.applicableGbGf2
        } else {
            this.versionApplicableGbGf = this.dictUtil.filter(
                'applicable_gb',
                selectVersion?.applicableGbGf
            )
        }
        if (selectVersion?.applicableCountries2 != null) {
            this.versionApplicableCountries =
                this.dictUtil.filter(
                    'applicable_countries',
                    selectVersion?.applicableCountries
                ) +
                '  -  ' +
                selectVersion?.applicableCountries2
        } else {
            this.versionApplicableCountries = this.dictUtil.filter(
                'applicable_countries',
                selectVersion?.applicableCountries
            )
        }

        return (
            <components.PageContainer
                title="API Detail"
                noHeader={true}
                isNotNeedFlex={true}
                isNeedCenter={true}
            >
                <div
                    style={{ fontSize: 28 }}
                    className="flex-row justify-content-between"
                >
                    <div>{ossApi?.apiName}</div>
                    <div>
                        <Button
                            size="large"
                            onClick={() => {
                                // this.props.history.goBack()
                                try {
                                    const {
                                        fieldsValues,
                                        pathName,
                                        demandStatusid,
                                        demandId,
                                        searchParams
                                    } = this.props.location
                                        .state as ApiDetailState
                                    if (pathName) {
                                        this.props.history.push({
                                            pathname: pathName,
                                            state: {
                                                demandId,
                                                demandStatusid,
                                                fieldsValues
                                            },
                                            search: searchParams
                                        })
                                    } else {
                                        this.props.history.goBack()
                                    }
                                } catch (error) {
                                    this.props.history.goBack()
                                }
                            }}
                        >
                            Back
                        </Button>
                    </div>
                </div>
                {/* <Divider /> */}
                <CardContainer title="Basic Information">
                    <div className="flex-row justify-content-end">
                        {/* <components.AuthDisableButton
                            type="primary"
                            size="large"
                            onClick={() =>
                                this.openForm(ossApi?.apiCatalogueId)
                            }
                            auth={['ROLE_01']}
                        >
                            Edit
                        </components.AuthDisableButton> */}
                    </div>
                    <LabelContainer column={2} labelSpan={3}>
                        <LabelItem label="API Method">
                            {ossApi?.apiMethod}
                        </LabelItem>
                        <LabelItem label="Backend System">
                            {this.dictUtil.filter(
                                'backend_system',
                                ossApi?.backEndSystem
                            )}
                        </LabelItem>
                        <LabelItem label="API Type">
                            {this.dictUtil.filter('api_type', ossApi?.apiType)}
                        </LabelItem>
                        <LabelItem label="Applicable Countries">
                            {this.dictUtil.filter(
                                'applicable_countries',
                                ossApi?.applicableCountries
                            )}
                            {ossApi?.applicableCountries2 != null &&
                                ossApi?.applicableCountries2 != '' &&
                                ' - ' + ossApi?.applicableCountries2}
                        </LabelItem>
                        <LabelItem label="Status">
                            {this.dictUtil.filter(
                                'catalogue_status_type',
                                ossApi?.status
                            )}
                        </LabelItem>
                        <LabelItem label="Applicable Channels">
                            {/*{ossApi?.applicableChannels}*/}
                            {this.dictUtil.filter(
                                'applicable_channels',
                                ossApi?.applicableChannels
                            )}
                            {ossApi?.applicableChannels2 != null &&
                                ossApi?.applicableChannels2 != '' &&
                                ' - ' + ossApi?.applicableChannels2}
                        </LabelItem>
                        <LabelItem label="Capability">
                            {this.dictUtil.filter(
                                'capability',
                                ossApi?.capability
                            )}
                        </LabelItem>
                        <LabelItem label="Applicable GB/GF">
                            {/*{ossApi?.applicableGbGf}*/}
                            {this.dictUtil.filter(
                                'applicable_gb',
                                ossApi?.applicableGbGf
                            )}
                            {ossApi?.applicableGbGf2 != null &&
                                ossApi?.applicableGbGf2 != '' &&
                                ' - ' + ossApi?.applicableGbGf2}
                        </LabelItem>
                        <LabelItem label="Feature">
                            {this.dictUtil.filter(
                                ossApi?.capability,
                                ossApi?.feature
                            )}
                        </LabelItem>
                        <LabelItem label="Original API ID">
                            {ossApi?.originalSapiId}
                        </LabelItem>

                        <LabelItem label="Service">
                            {this.dictUtil.filter(
                                ossApi?.feature,
                                ossApi?.service
                            )}
                        </LabelItem>
                        <LabelItem label="Core Banking API ID">
                            {ossApi?.coreBankingApiId}
                        </LabelItem>
                        <LabelItem label="Latest Version">
                            {ossApi?.latestVersion}
                        </LabelItem>
                        <LabelItem label="Description">
                            {ossApi?.description}
                        </LabelItem>
                    </LabelContainer>
                    {/* <LabelContainer column={2} labelSpan={3}>
                        <LabelItem label="Description">
                            {ossApi?.description}
                        </LabelItem>
                    </LabelContainer> */}
                    <Divider />
                    <Table
                        onRow={record => {
                            return {
                                onClick: event => {
                                    this.setState({
                                        selectVersion: record
                                    })
                                }
                            }
                        }}
                        columns={columns}
                        dataSource={apiVersionResponses}
                        size="small"
                        rowKey="versionId"
                        pagination={false}
                    />
                    {/*  <Divider />
                     <div>
                             <Button
                            type="primary"
                            size="large"
                            onClick={() => this.openForm()}
                        >
                            Add version
                        </Button>
                   
                    </div> */}
                </CardContainer>
                <CardContainer
                    title={
                        selectVersion?.version
                            ? 'Version ' + selectVersion?.version
                            : 'Version Definition'
                    }
                >
                    <LabelContainer column={1} labelSpan={3}>
                        <LabelItem label="API ID">
                            {selectVersion?.trueSapiId}
                        </LabelItem>
                        <LabelItem label="API Name">
                            {selectVersion?.apiName}
                        </LabelItem>
                        <LabelItem label="API Version">
                            {selectVersion?.version}
                        </LabelItem>
                        <LabelItem label="Consumer">
                            {selectVersion?.consumer}
                        </LabelItem>
                        <LabelItem label="API Lifecycle Stage">
                            {this.dictUtil.filter(
                                'api_lifecycle_stage',
                                selectVersion?.apiLifecycleStage
                            )}
                        </LabelItem>
                        <LabelItem label="Applicable HUB Version">
                            {selectVersion?.applicableHubVersion}
                        </LabelItem>
                        <LabelItem label="Applicable Channels">
                            {this.versionApplicableChannels}
                        </LabelItem>
                        <LabelItem label="Applicable GB/GF">
                            {this.versionApplicableGbGf}
                        </LabelItem>
                        <LabelItem label="Applicable Countries">
                            {this.versionApplicableCountries}
                        </LabelItem>
                        <LabelItem label="Core Banking API ID">
                            {selectVersion?.coreBankingApiId}
                        </LabelItem>
                        <LabelItem label="HUB PGM Flow">
                            {selectVersion?.hubPgmFlow}
                        </LabelItem>
                        <LabelItem label="Enhancement">
                            {selectVersion?.enhancement}
                        </LabelItem>
                        <LabelItem label="API Review Status">
                            <Button
                                type="link"
                                className="text-left"
                                style={{ padding: 0 }}
                                onClick={() =>
                                    this.openReviewForm(selectVersion.reviewId)
                                }
                            >
                                {this.dictUtil.filter(
                                    'design_review_status',
                                    selectVersion?.apiReviewStatus
                                )}
                            </Button>
                        </LabelItem>
                        <LabelItem label="HUB API Documents">
                            <div>
                                <div className="flex-row">
                                    <div style={{ width: 200 }}>
                                        API Contract:
                                    </div>
                                    <div
                                        style={{
                                            color: '#1890ff',
                                            cursor: 'pointer',
                                            wordBreak: 'break-all',
                                            width: 500
                                        }}
                                        onClick={() => {
                                            let fileName = ''
                                            let functionType = ''
                                            download(
                                                appConfig.server +
                                                    '/file/download',
                                                selectVersion?.hubApiContract,
                                                {
                                                    fileName:
                                                        selectVersion?.hubApiContract,
                                                    functionType:
                                                        'reviewContract'
                                                }
                                            )
                                        }}
                                    >
                                        {selectVersion?.hubApiContract}
                                    </div>
                                </div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>
                                        Error Scenario:
                                    </div>
                                    <div>{selectVersion?.hubErrorScenario}</div>
                                </div>
                                <div className="flex-row ">
                                    <div style={{ width: 200 }}>
                                        Functional Design:
                                    </div>
                                    <div>
                                        {selectVersion?.hubFunctionalDesign}
                                    </div>
                                </div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>
                                        IWS Postman JSON Data:
                                    </div>
                                    <div
                                        style={{
                                            color: '#1890ff',
                                            cursor: 'pointer',
                                            wordBreak: 'break-all',
                                            width: 500
                                        }}
                                        onClick={() => {
                                            let fileName = ''
                                            let functionType = ''
                                            download(
                                                appConfig.server +
                                                    '/file/download',
                                                selectVersion?.iwsPostmanJson,
                                                {
                                                    fileName:
                                                        selectVersion?.iwsPostmanJson,
                                                    functionType:
                                                        'reviewContract'
                                                }
                                            )
                                        }}
                                    >
                                        {' '}
                                        {selectVersion?.iwsPostmanJson}
                                    </div>
                                </div>
                            </div>
                        </LabelItem>
                        <LabelItem label="Mule API Documents ">
                            <div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>
                                        CERT PCF URL:
                                    </div>
                                    <div>
                                        <div
                                            className="text-left"
                                            style={{
                                                padding: 0,
                                                color: '#1890ff',
                                                cursor: 'pointer',
                                                wordBreak: 'break-all',
                                                width: 500
                                            }}
                                            onClick={() =>
                                                window.open(
                                                    selectVersion?.apiCertPcfUrl
                                                )
                                            }
                                        >
                                            {selectVersion?.apiCertPcfUrl}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>
                                        Internal Gateway URL:
                                    </div>
                                    <div>
                                        <div
                                            className="text-left"
                                            style={{
                                                padding: 0,
                                                color: '#1890ff',
                                                cursor: 'pointer',
                                                wordBreak: 'break-all',
                                                width: 500
                                            }}
                                            onClick={() =>
                                                window.open(
                                                    selectVersion?.apiInteralGatewayUrl
                                                )
                                            }
                                        >
                                            {
                                                selectVersion?.apiInteralGatewayUrl
                                            }
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>
                                        Git Repository URL:
                                    </div>
                                    <div>
                                        <div
                                            className="text-left"
                                            style={{
                                                padding: 0,
                                                color: '#1890ff',
                                                cursor: 'pointer',
                                                wordBreak: 'break-all',
                                                width: 500
                                            }}
                                            onClick={() =>
                                                window.open(
                                                    selectVersion?.apiGitRepo
                                                )
                                            }
                                        >
                                            {selectVersion?.apiGitRepo}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-row ">
                                    <div style={{ width: 200 }}>
                                        Jenkins URL:
                                    </div>
                                    <div>
                                        <div
                                            className="text-left"
                                            style={{
                                                padding: 0,
                                                color: '#1890ff',
                                                cursor: 'pointer',
                                                wordBreak: 'break-all',
                                                width: 500
                                            }}
                                            onClick={() =>
                                                window.open(
                                                    selectVersion?.apiJenkinsUrl
                                                )
                                            }
                                        >
                                            {selectVersion?.apiJenkinsUrl}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>RAML URL:</div>
                                    <div>
                                        <div
                                            className="text-left"
                                            style={{
                                                padding: 0,
                                                color: '#1890ff',
                                                cursor: 'pointer',
                                                wordBreak: 'break-all',
                                                width: 500
                                            }}
                                            onClick={() =>
                                                window.open(
                                                    selectVersion?.apiRaml
                                                )
                                            }
                                        >
                                            {selectVersion?.apiRaml}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-row ">
                                    <div style={{ width: 200 }}>
                                        Mule Postman JSON URL:
                                    </div>
                                    <div
                                        style={{
                                            wordBreak: 'break-all',
                                            width: 500
                                        }}
                                    >
                                        {selectVersion?.apiPostmanJsonData}
                                    </div>
                                </div>
                            </div>
                        </LabelItem>
                        <LabelItem label="Certification Result">
                            <div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>URL:</div>
                                    <div>
                                        <div
                                            className="text-left"
                                            style={{
                                                padding: 0,
                                                color: '#1890ff',
                                                cursor: 'pointer',
                                                wordBreak: 'break-all',
                                                width: 500
                                            }}
                                            onClick={() =>
                                                window.open(
                                                    selectVersion?.certificatePageUrl
                                                )
                                            }
                                        >
                                            {selectVersion?.certificatePageUrl}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-row padding-y">
                                    <div style={{ width: 200 }}>
                                        PT Postman JSON Data:
                                    </div>
                                    <div
                                        style={{
                                            color: '#1890ff',
                                            cursor: 'pointer',
                                            wordBreak: 'break-all',
                                            width: 500
                                        }}
                                        onClick={() => {
                                            let fileName = ''
                                            let functionType = ''
                                            download(
                                                appConfig.server +
                                                    '/file/download',
                                                selectVersion?.ptPostmanJson,
                                                {
                                                    fileName:
                                                        selectVersion?.ptPostmanJson,
                                                    functionType:
                                                        'reviewContract'
                                                }
                                            )
                                        }}
                                    >
                                        {selectVersion?.ptPostmanJson}
                                    </div>
                                </div>
                            </div>
                        </LabelItem>
                        <LabelItem label="Sample API Call">
                            <div
                                style={{
                                    color: '#1890ff',
                                    cursor: 'pointer',
                                    wordBreak: 'break-all',
                                    width: 500
                                }}
                                onClick={() => {
                                    let fileName = ''
                                    let functionType = ''
                                    download(
                                        appConfig.server + '/file/download',
                                        selectVersion?.sampleApiCall,
                                        {
                                            fileName:
                                                selectVersion?.sampleApiCall,
                                            functionType: 'reviewContract'
                                        }
                                    )
                                }}
                            >
                                {selectVersion?.sampleApiCall}
                            </div>
                        </LabelItem>
                        <LabelItem label="Remarks">
                            <div
                                style={{
                                    wordWrap: 'break-word',
                                    wordBreak: 'break-word',
                                    width: '700px'
                                }}
                            >
                                {selectVersion?.versionRemarks}
                            </div>
                        </LabelItem>
                    </LabelContainer>
                </CardContainer>
                <CardContainer title="Testing Information">
                    <LabelContainer column={1} labelSpan={3}>
                        <LabelItem label="Testing Status">
                            {selectVersion?.testingStatus}
                        </LabelItem>
                    </LabelContainer>
                </CardContainer>
            </components.PageContainer>
        )
    }

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail-form',
            state: {
                id: apiCatalogueId
            },
            search:`id=${apiCatalogueId}`
        })
    }
    private openForm2(record) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail-version-form',
            state: {
                id: record.versionId
            },
            search:`id=${record.versionId}`
        })
    }
    private openReviewForm(reviewId) {
        this.props.history.push({
            pathname: '/pages/review-request-form',
            state: {
                reviewId
            },
            search:`reviewId=${reviewId}`
        })
    }
    private test(data) {
        if (data.applicableChannels2 != null) {
            return ' - ' + data.applicableChannels2
        }
        return ''
    }
}
