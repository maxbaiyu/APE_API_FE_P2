import React, { Component, Props } from 'react'
import styled from 'styled-components'
import { Form, Input, Button, Space } from 'antd'
import { RouteComponentProps } from 'react-router-dom'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { AuthService } from '~/services/auth.service'
import { RequestParams } from '~/core/http'
import { PageService } from '~/bootstrap/services/page.service'
import launchBoot from '~/bootstrap/boots/launch.boot'
import { DirectoryService } from '~/services/directory.service'
import { taskService } from '~/services/task'
import axios from 'axios'
import appConfig from '~/config/app.config'
const styles = (
    props?: Props<any>
): { [key: string]: React.CSSProperties } => ({
    autoFlex: {
        flex: 1,
        position: 'relative'
    },
    logo: {
        width: '177px',
        height: '38px'
    }
})
const components = {
    Wrapper: styled.section`
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        color: #e5e5e5;
        background-size: 50% auto;
        background-repeat: no-reapt;
        display: flex;
        flex-direction: column;
    `,
    HeaderContainer: styled.section`
        display: flex;
        align-items: center;
        height: 60px;
        width: 100%;
        flex-basis: 60px;
        color: rgba(255, 255, 255, 0.87);
        background-color: #1d262c;
        background-size: 100% auto;
    `,
    LinkContainer: styled.section`
        height: 50px;
        flex-basis: 50px;
        background-color: #253038;
        font-size: 12px;
        font-style: Regular;
        color: #ffffff;
        text-align: center;
        font-style: Thin;
        font-family: Univers Next;
        padding: 0 10px;
    `,
    FooterContainer: styled.section`
        height: 50px;
        flex-basis: 50px;
        background-color: #1d262c;
        font-size: 12px;
        font-style: Regular;
        color: #ffffff;
        text-align: center;
        font-style: Thin;
        font-family: UniversNextW05-Light;
    `,
    FormContainer: styled.section`
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
    `,
    FormWrapper: styled.section`
        box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.5);
        color: rgba(0, 0, 0, 0.87);
        width: 500px;
        height: 320px;
        background-color: #fff;
        .form-header {
            border-bottom: 3px solid rgba(0, 0, 0, 0.66);
            font-size: 20px;
            padding: 15px 10px;
            font-weight: bold;
        }
        .form-content {
            padding: 40px;
        }
        .form-input {
            /* width: 280px;
            height: 40px;
            margin: 10px; */
        }
        .submit-button {
            background: red;
            border: none;
            width: 120px;
            height: 50px;
            font-size: 16px;
            margin-top: 10px;
        }
        .form-password {
            .ant-form-item-control-input-content {
                width:100%;
            }
        }
    `
}

interface LoginState { }

interface LoginProps { }

const styles2 = (
    props?: Props<any>
): { [key: string]: React.CSSProperties } => ({
    split: {
        height: '23px',
        width: '1px',
        backgroundColor: 'rgba(255, 255, 255, 0.15)'
    }
})

const STORAGE_KEY = 'react-storage'

export default class Login extends Component<
    RouteComponentProps<LoginProps>,
    RouteComponentProps<LoginState>
    > {
    private pageService = new PageService()
    private authService = new AuthService()
    private taskService = new taskService()

    constructor(props) {
        super(props)
    }

    public render() {
        return (
            <components.Wrapper>
                {this.renderHeader()}
                {this.renderForm()}
                {this.renderFooter()}
                {this.renderFooter2()}
            </components.Wrapper>
        )
    }

    public renderHeader() {
        return (
            <components.HeaderContainer>
                <img alt="" src={require('~/assets/images/Logo.png')}></img>
            </components.HeaderContainer>
        )
    }

    public renderFooter() {
        return (
            <components.LinkContainer className="flex-row align-items-center">
                <div style={styles2().split}></div>
                <div className="flex-span-2">Support</div>
                <div style={styles2().split}></div>
                <div className="flex-span-2">Privacy Notice</div>
                <div style={styles2().split}></div>
                <div className="flex-span-2">Terms and Conditions</div>
                <div style={styles2().split}></div>
                <div className="flex-span-2">Cookie Policy</div>
                <div className="flex-span-6"> </div>
            </components.LinkContainer>
        )
    }

    public renderFooter2() {
        return (
            <components.FooterContainer className="flex-row align-items-center">
                <div className="flex-span-2">
                    © Copyright HSBC Group 2002-2020 all rights reserved
                </div>
                <div className="flex-span-2"></div>
                <div className="flex-span-2"></div>
                <div className="flex-span-3"></div>
                <div className="flex-span-3"></div>
            </components.FooterContainer>
        )
    }

    public renderForm() {
        return (
            <components.FormContainer>
                <Consumer of={UserStore}>
                    {userStore => (
                        <components.FormWrapper>
                            <div
                                className="form-header"
                                style={{ paddingLeft: 50 }}
                            >
                                Login
                            </div>
                            <Form
                                size="large"
                                labelCol={{ span: 6 }}
                                className="form-content"
                                name="login-form"
                                initialValues={{ remember: true }}
                                onFinish={data =>
                                    this.onSubmit(data, userStore)
                                }
                            >
                                <Form.Item
                                    label="Staff ID"
                                    name="staffId"
                                    rules={[
                                        {
                                            required: true,
                                            message:
                                                'Please input your user ID!'
                                        }
                                    ]}
                                >
                                    <Input className="form-input" />
                                </Form.Item>
                                <Form.Item
                                    label="Password"
                                    name="passWord"
                                    className="form-password"
                                    rules={[
                                        {
                                            required: true,
                                            message:
                                                'Please input your password!'
                                        }
                                    ]}
                                >
                                    <Input.Password className="form-input" />
                                </Form.Item>
                                <Form.Item>
                                    <div className="flex-row justify-content-center">
                                        <Button
                                            type="primary"
                                            htmlType="submit"
                                            className="submit-button"
                                        >
                                            Sign In
                                        </Button>
                                    </div>
                                </Form.Item>
                            </Form>
                            <div style={{ fontSize: 12 }}>
                                Powered by: Core Banking APE Working Group
                            </div>
                        </components.FormWrapper>
                    )}
                </Consumer>
            </components.FormContainer>
        )
    }
    private munNumb(token,{ task }){
        axios.defaults.headers.common['Authorization'] = token
        axios({
            url: appConfig.server + '/user-center/task',
            method: 'get',
            timeout: 5000,
        })
            .then(resp => {
              sessionStorage.setItem('messNumm',resp.data.resultBody)
              task(resp.data.resultBody)
            })
            .catch(error => {
            })
    }
    private onSubmit(formModel, { login,task }) {
        const stroageObject = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')
        if (stroageObject && stroageObject.user && stroageObject.user.token) {
            // 直接通过修改路径进入login页面重新登陆
            delete stroageObject.user
            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(stroageObject)
            )
        }
        this.authService
            .login(new RequestParams({ ...formModel, rememberMe: 1 }))
            .subscribe(data => {
                // save user info
                login(data)
                this.munNumb(data.token,{ task })
                // go to home page
                const homePagePath = '/home-page'
                let { pathname = homePagePath, staffId, state } = JSON.parse(
                    localStorage.getItem('preUserOperateInfo') || '{}'
                )
                try {
                    this.props.history.push({
                        pathname,
                        state
                    })                   
                } catch (error) {
                    this.props.history.push({
                        pathname: homePagePath
                    })
                }
                if (pathname !== homePagePath) {
                    window.history.go()
                }
                localStorage.removeItem('preUserOperateInfo')
            })
    }
}
