import React, { useState, useRef } from 'react'
import { useHistory } from 'react-router-dom'
import { Form, Button, Space, Divider } from 'antd'
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons'
import PageContainer from '~/shared/components/page-container'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import CustomizeModal from '~/shared/components/customize-modal'
import FormItemComponent from './form-item-component'
import { DemandService } from '~/services/demand.service'
import { RequestParams } from '~/core/http'
import step1Img from '~/assets/svg/demand-request-form-by-project-step1.svg'
import step2Img from '~/assets/svg/demand-request-form-by-project-step2.svg'
import { proInfoItems, demandInfoItems } from './data'
import cloneDeep from 'lodash/cloneDeep'
import moment from 'moment'
import { addNum } from '~/shared/utils/common.util'

import styled from 'styled-components'

const components = {
    PageContainer: styled(PageContainer)``
}

const demandService = new DemandService()

const DemandRequestFormByProject = () => {
    const [currentStep, setCurrentStep] = useState<Number>(1)
    const dataFormStep1Ref: any = useRef<HTMLDivElement>(null)
    const dataFormStep2Ref: any = useRef<HTMLDivElement>(null)
    const [successModalVisible, setModalVisible] = useState<boolean>(false)

    const demandInfoItemsCloneDeep = cloneDeep(demandInfoItems)

    const history = useHistory()

    const renderFormAction = () => {
        return (
            <div
                style={{ width: '100%' }}
                className="flex-row justify-content-end"
            >
                <Button
                    type="primary"
                    danger
                    onClick={() => {
                        dataFormStep1Ref.current?.formInstance
                            ?.validateFields()
                            .then(res => {
                                setCurrentStep(2)
                            })
                    }}
                >
                    Next
                </Button>
            </div>
        )
    }

    const onFormValueChange = (changeValue, values) => {
        for (let key in changeValue) {
            if (key === 'ossApiDemand') {
                for (let i = 0; i < changeValue[key].length; i++) {
                    const item = changeValue[key][i]
                    if (
                        typeof item === 'object' &&
                        Object.keys(item).length > 1
                    ) {
                        console.log('it is add')
                        return
                    }
                }
                const index = changeValue[key].findIndex(item => item)
                if (index !== -1) {
                    const demandInfoMod = values[key]
                    Object.keys(changeValue[key][index]).forEach(item => {
                        if (item === 'demandClassification') {
                            demandInfoMod[index] = {
                                ...demandInfoMod[index],
                                apiName: '',
                                reuseApiVersion: '',
                                apiType: ''
                            }
                        } else if (
                            item === 'ossApiL0Estimates' ||
                            item === 'cbSystemL0Estimates'
                        ) {
                            demandInfoMod[index] = {
                                ...demandInfoMod[index],
                                totalApiL0Estimates: addNum(
                                    demandInfoMod[index].ossApiL0Estimates,
                                    demandInfoMod[index].cbSystemL0Estimates
                                )
                            }
                        } else if (
                            item === 'backEndSystem' ||
                            (item === 'apiName' &&
                                typeof changeValue === 'object')
                        ) {
                            const fieldsValue = dataFormStep2Ref.current.formInstance.getFieldsValue()
                            const {
                                demandClassification
                            } = fieldsValue?.ossApiDemand[index]
                            if (
                                demandClassification !== '01' &&
                                demandClassification !== '02'
                            ) {
                                if (item === 'apiName') {
                                    demandInfoMod[index] = {
                                        ...demandInfoMod[index],
                                        reuseApiVersion: ''
                                    }
                                }
                                if (item === 'backEndSystem') {
                                    demandInfoMod[index] = {
                                        ...demandInfoMod[index],
                                        apiName: '',
                                        reuseApiVersion: ''
                                    }
                                }
                            }
                        }
                    })
                    dataFormStep2Ref.current.formInstance.setFieldsValue({
                        values,
                        ossApiDemand: demandInfoMod
                    })
                }
                return
            }
        }
        // 处理非嵌套
        Object.keys(changeValue).forEach(item => {
            if (item === 'demandClassification') {
                dataFormStep2Ref.current.formInstance.setFieldsValue({
                    values,
                    apiName: '',
                    reuseApiVersion: '',
                    apiType: ''
                })
            } else if (
                item === 'ossApiL0Estimates' ||
                item === 'cbSystemL0Estimates'
            ) {
                dataFormStep2Ref.current.formInstance.setFieldsValue({
                    values,
                    totalApiL0Estimates: addNum(
                        values.ossApiL0Estimates,
                        values.cbSystemL0Estimates
                    )
                })
            } else if (
                item === 'backEndSystem' ||
                (item === 'apiName' && typeof changeValue === 'object')
            ) {
                const fieldsValue = dataFormStep2Ref.current.formInstance.getFieldsValue()
                const { demandClassification } = fieldsValue
                if (
                    demandClassification !== '01' &&
                    demandClassification !== '02'
                ) {
                    if (item === 'apiName') {
                        dataFormStep2Ref.current.formInstance.setFieldsValue({
                            values,
                            reuseApiVersion: ''
                        })
                    }
                    if (item === 'backEndSystem') {
                        dataFormStep2Ref.current.formInstance.setFieldsValue({
                            values,
                            apiName: '',
                            reuseApiVersion: ''
                        })
                    }
                }
            }
        })
    }

    const formatData = (infoType, data) => {
        if (infoType === 'projectInfor') {
            return {
                ...data,
                gdpmInterLockBpid: data.gdpmInterLockBpid,
                gdpmInterLockBpidYear:
                    moment(data.gdpmInterLockBpidYear).isValid() &&
                    data.gdpmInterLockBpidYear
                        ? data.gdpmInterLockBpidYear.format('YYYY')
                        : null,
                receivedDate: data?.receivedDate?.format('MM/DD/YYYY')
            }
        }
        if (infoType === 'ossApiDemand') {
            let ossApiDemandArr: any[] = []
            if (data.ossApiDemand) {
                ossApiDemandArr = data.ossApiDemand
                delete data.ossApiDemand
            }
            ossApiDemandArr.push(data)
            return ossApiDemandArr.map(item => {
                const {
                    apiName,
                    targetLiveDate,
                    reuseApiVersion,
                    ossApiL0Estimates,
                    cbSystemL0Estimates,
                    apiType
                } = item
                return {
                    ...item,
                    apiType,
                    apiLifecycleStage: '',
                    channelAgnostic: '',
                    multiCountry: '',
                    nextMiletoneRagStatus: '',
                    originalSapiId: '',
                    overallDeliveryRagStatus: '',
                    platform: '',
                    reusabilityScore: '',
                    targetDateOfNextMilestone: '',
                    targetDateOverallDelivery: '',
                    trueSapiId: '',
                    apiName:
                        typeof apiName == 'string' ? apiName : apiName.label,
                    apiCatalogueId:
                        typeof apiName == 'string' ? '' : apiName.value,
                    targetLiveDate: targetLiveDate.format('MM/DD/YYYY'),
                    reuseApiVersionId: reuseApiVersion?.value,
                    reuseApiVersion: reuseApiVersion?.label,
                    ossApiL0Estimates: Number(ossApiL0Estimates),
                    cbSystemL0Estimates: Number(cbSystemL0Estimates)
                }
            })
        }
    }

    const renderModal = () => {
        return (
            <CustomizeModal
                title="Success!"
                visible={successModalVisible}
                okText="Demand List -->"
                cancelText="Close"
                content="Check Status in Demand List."
                onOk={() => {
                    history.push({
                        pathname: '/pages/api-demand-request-list'
                    })
                }}
                onCancel={() => {
                    setModalVisible(false)
                }}
            ></CustomizeModal>
        )
    }

    const submitData = submitType => {
        dataFormStep2Ref.current?.formInstance
            ?.validateFields()
            .then(res => {
                const ossApiProjectInfo = formatData(
                    'projectInfor',
                    dataFormStep1Ref.current?.formInstance?.getFieldsValue()
                )
                const ossApiDemand = formatData('ossApiDemand', res)
                demandService
                    .multiplePost(
                        new RequestParams({
                            functionType: submitType,
                            ossApiProjectInfo,
                            ossApiDemand
                        })
                    )
                    .subscribe(data => {
                        setModalVisible(true)
                    })
            })
            .catch(error => {
                console.log(error)
            })
    }
    
    return (
        <components.PageContainer
            title="Demand Request Form"
            noHeader={true}
            width={'85%'}
            isNotNeedFlex={true}
            isNeedCenter={true}
        >
            <img
                width="100%"
                src={currentStep === 1 ? step1Img : step2Img}
                style={{ padding: '1.5rem 1.5rem 0' }}
            ></img>
            <div
                style={{ display: currentStep === 1 ? 'block' : 'none' }}
                className={'demand-request-project-pro-info'}
            >
                <CardContainer title="Project Information">
                    <DataForm
                        name="project-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        // formWidth={900}
                        ref={dataFormStep1Ref}
                        actions={renderFormAction()}
                    >
                        <FormItemComponent
                            dataFormRef={dataFormStep1Ref}
                            formItemDatas={proInfoItems}
                        />
                    </DataForm>
                </CardContainer>
            </div>
            <div
                style={{ display: currentStep === 2 ? 'block' : 'none' }}
                className={'demand-request-project-info-form'}
            >
                <CardContainer title="Demand Information">
                    <p
                        style={{
                            width: '10px',
                            position: 'absolute',
                            fontWeight: 'bold',
                            lineHeight: '30px'
                        }}
                    >
                        1
                    </p>
                    <DataForm
                        name="demand-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        onValuesChange={onFormValueChange}
                        // formWidth={900}
                        ref={dataFormStep2Ref}
                    >
                        <div style={{ marginLeft: 18 }}>
                            <FormItemComponent
                                dataFormRef={dataFormStep2Ref}
                                formItemDatas={demandInfoItemsCloneDeep}
                            />
                        </div>

                        <Divider></Divider>
                        <Form.List name="ossApiDemand">
                            {(fields, { add, remove }) => (
                                <>
                                    {fields.map((field, index) => (
                                        <>
                                            <p
                                                style={{
                                                    width: '10px',
                                                    position: 'absolute',
                                                    left: '10px',
                                                    fontWeight: 'bold',
                                                    lineHeight: '30px'
                                                }}
                                            >
                                                {index + 2}
                                            </p>
                                            <Space
                                                key={field.key}
                                                style={{
                                                    display: 'flex',
                                                    marginBottom: 8,
                                                    marginLeft: 18
                                                }}
                                                align="baseline"
                                            >
                                                <FormItemComponent
                                                    dataFormRef={
                                                        dataFormStep2Ref
                                                    }
                                                    currentStep={currentStep}
                                                    formItemDatas={
                                                        demandInfoItemsCloneDeep
                                                    }
                                                    fieldName={field.name}
                                                    fieldKey={field.fieldKey}
                                                />
                                                <MinusCircleOutlined
                                                    className="dynamic-delete-button"
                                                    onClick={() => {
                                                        const currentValue = cloneDeep(
                                                            dataFormStep2Ref.current.formInstance.getFieldsValue()
                                                                .ossApiDemand
                                                        )
                                                        currentValue.splice(
                                                            field.name,
                                                            1
                                                        )
                                                        dataFormStep2Ref.current.formInstance.setFieldsValue(
                                                            {
                                                                ...dataFormStep2Ref.current.formInstance.getFieldsValue(),
                                                                ossApiDemand: !currentValue.length ? undefined : currentValue
                                                            }
                                                        )
                                                    }}
                                                />
                                            </Space>
                                            <Divider></Divider>
                                        </>
                                    ))}

                                    <Form.Item>
                                        <Button
                                            type="dashed"
                                            onClick={() => add()}
                                            block
                                            icon={<PlusOutlined />}
                                        >
                                            Demand API
                                        </Button>
                                    </Form.Item>
                                </>
                            )}
                        </Form.List>
                        <Form.Item>
                            <Button
                                onClick={() => {
                                    setCurrentStep(1)
                                }}
                                className="flex-row justify-content-start"
                            >
                                Back{' '}
                            </Button>
                            <div className={'save-submit-btn'}>
                                <Button
                                    onClick={() => {
                                        submitData('SAVE')
                                    }}
                                >
                                    Save{' '}
                                </Button>
                                <Button
                                    type="primary"
                                    onClick={() => {
                                        submitData('SUBMIT')
                                    }}
                                >
                                    Submit{' '}
                                </Button>
                            </div>
                        </Form.Item>
                    </DataForm>
                </CardContainer>
                {renderModal()}
            </div>
        </components.PageContainer>
    )
}

export default DemandRequestFormByProject
