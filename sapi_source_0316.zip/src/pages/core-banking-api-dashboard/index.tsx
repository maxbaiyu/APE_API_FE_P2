import React, { useState, useRef, useEffect } from 'react'
import PageContainer from '~/shared/components/page-container'
import StatisticsCard from './statistics-card'
import ReusabilityPieChartCard from './reusability-pie-chart'
import DeliveryDurationChartCard from './delivery-duration'
import TrackingChartCard from './tracking'
import TopApiReusedChartCard from './top-api-reused'
import StatusChartCard from './status'

import styled from 'styled-components'

const components = {
    PageContainer: styled(PageContainer)``,
    Content: styled.div`
        padding: 1rem;
        display: flex;
        box-sizing: border-box;
        .dashboard-left-area {
            width: 40%;
            padding-right: 1rem;
            box-sizing: border-box;
        }
        .dashboard-right-area {
            flex: 1 1;
        }
    `
}

const CoreBankingAPIDashboard: React.FC = () => {
    useEffect(() => {}, [])
    return (
        <components.PageContainer
            width={'100%'}
            title="Core Banking API Dashboard"
            noHeader={true}
            isNotNeedFlex={true}
            isNeedCenter={true}
            className={'core-banking-api-dashboard'}
        >
            <components.Content>
                <div className={'dashboard-left-area'}>
                    <StatisticsCard />
                    <ReusabilityPieChartCard />
                    <DeliveryDurationChartCard />
                </div>
                <div className={'dashboard-right-area'}>
                    <TrackingChartCard />
                    <TopApiReusedChartCard />
                    <StatusChartCard />
                </div>
            </components.Content>
        </components.PageContainer>
    )
}

export default CoreBankingAPIDashboard
