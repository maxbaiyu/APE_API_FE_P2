import React, { ReactNode } from 'react'
import { Descriptions } from 'antd'
import DashboardCardComponent from './dashboard-card-component'
import { outApprovalItems, averageCostItems } from './type'

const StatisticsCard: React.FC = props => {
    return (
        <DashboardCardComponent
            title={'Dashboard'}
            className={'statistics-card'}
        >
            <Descriptions
                title="Outstanding Approval"
                layout="vertical"
                className={'outstanding-approval'}
                // column={5}
            >
                {outApprovalItems.map((item, index) => (
                    <Descriptions.Item
                        key={`outstanding-approval${index}`}
                        label={item.label}
                        contentStyle={{ color: item.color }}
                        //span={item.span ? item.span : 1}
                    >
                        {item.contentProKey ? item.contentProKey : '0'}
                    </Descriptions.Item>
                ))}
            </Descriptions>

            <Descriptions
                title="Average Cost by Reuse Category"
                layout="vertical"
                className={'average-cost-by-reuse-category'}
                column={5}
            >
                {averageCostItems.map((item, index) => (
                    <Descriptions.Item
                        key={`average-cost${index}`}
                        label={item.label}
                        contentStyle={{ color: item.color }}
                        span={item.span ? item.span : 1}
                    >
                        {item.contentProKey ? `${item.contentProKey}k` : '0k'}
                    </Descriptions.Item>
                ))}
            </Descriptions>
        </DashboardCardComponent>
    )
}

export default StatisticsCard
