import React, { ReactNode, useState, useEffect, useRef } from 'react'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import 'echarts/lib/chart/bar'
import { Select } from 'antd'
import DashboardCardComponent from './dashboard-card-component'
import { DictUtil } from '~/shared/utils/dict.util'
import { statusChartOption } from './dashboardInitData'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { Series } from 'viser-react'

const { Option } = Select
const dictUtil = new DictUtil()
const reviewService = new ReviewService()

const StatusChartCard: React.FC = props => {
    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [apiType, setApiType] = useState<string>('')
    const [year, setYear] = useState<string>('')
    const [yearList, setYearList] = useState<any>([])
    const [option, setOption] = useState<any>(statusChartOption)

    const getYear = () => {
        reviewService.date(new RequestParams()).subscribe(data => {
            setYearList(data)
        })
    }

    const getOption = (apiType = '', date = '') => {
        reviewService
            .details(
                new RequestParams({
                    date: date,
                    apiType: apiType
                })
            )
            .subscribe(data => {
                const xAxisData: string[] = []
                const discovery: number[] = []
                const development: number[] = []
                const sit: number[] = []
                const uat: number[] = []
                const deploymentReadiness: number[] = []
                const production: number[] = []
                data.forEach(item => {
                    xAxisData.push(item.cbSysName)
                    discovery.push(item.discovery)
                    development.push(item.development)
                    sit.push(item.sit)
                    uat.push(item.uat)
                    deploymentReadiness.push(item.deploymentReadiness)
                    production.push(item.production)
                })
                setOption({
                    ...option,
                    xAxis: [
                        {
                            type: 'category',
                            axisTick: { show: false },
                            data: xAxisData
                        }
                    ],
                    series: option.series.map(item => {
                        if (item.name === 'Discovery') {
                            return {
                                ...item,
                                data: discovery
                            }
                        } else if (item.name === 'Development') {
                            return {
                                ...item,
                                data: development
                            }
                        } else if (item.name === 'SIT') {
                            return {
                                ...item,
                                data: sit
                            }
                        } else if (item.name === 'UAT') {
                            return {
                                ...item,
                                data: uat
                            }
                        } else if (item.name === 'Deployment Readiness') {
                            return {
                                ...item,
                                data: deploymentReadiness
                            }
                        } else if (item.name === 'Production') {
                            return {
                                ...item,
                                data: production
                            }
                        }
                    })
                })
            })
    }

    useEffect(() => {
        getYear()
        setShowLoading(false)
        getOption()
        // setOption({
        //     ...option,
        //     series: option.series.map(item => ({
        //         ...item,
        //         data: [
        //             320,
        //             332,
        //             301,
        //             334,
        //             390,
        //             320,
        //             332,
        //             301,
        //             334,
        //             390,
        //             320,
        //             332
        //         ]
        //     }))
        // })
    }, [])

    return (
        <DashboardCardComponent
            title={'API Demand Order Status'}
            className={'status-chart-card'}
            extra={
                <div>
                    <Select
                        style={{ width: 130, marginRight: 10 }}
                        value={apiType}
                        onChange={value => {
                            setApiType(value)
                            getOption(value, year)
                        }}
                    >
                        <Select.Option value="">All</Select.Option>
                        {dictUtil.dicts('api_type', dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                    <Select
                        style={{ width: 130 }}
                        value={year}
                        onChange={value => {
                            setYear(value)
                            getOption(apiType, value)
                        }}
                    >
                        <Option value="">Overall</Option>
                        {yearList.map(item => (
                            <Option
                                key={item.createDate}
                                value={item.createDate}
                            >
                                {item.createDate}
                            </Option>
                        ))}
                    </Select>
                </div>
            }
        >
            <ReactEchartsCore
                echarts={echarts}
                option={option}
                loadingOption={loadingOption}
                showLoading={showLoading}
                style={{ height: 400 }}
            />
        </DashboardCardComponent>
    )
}

export default StatusChartCard
