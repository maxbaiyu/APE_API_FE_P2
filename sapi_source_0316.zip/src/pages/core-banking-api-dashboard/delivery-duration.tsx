import React, { useState, useEffect } from 'react'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import 'echarts/lib/chart/bar'
import DashboardCardComponent from './dashboard-card-component'
import { deliveryDurationChartOption } from './dashboardInitData'

const DeliveryDurationChartCard: React.FC = props => {
    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [pieOption, setPieOption] = useState<any>(deliveryDurationChartOption)

    useEffect(() => {
        setShowLoading(false)
        const duration = require('./duration.json');
        setPieOption({
            ...pieOption,
            series: [
                {
                    ...pieOption.series[0],
                    data: duration.map(item=>item.count)
                }
            ]
        })
    }, [])

    return (
        <DashboardCardComponent
            title={'API Demand Order Delivery Duration'}
            className={'delivery-duration-chart-card'}
        >
            <ReactEchartsCore
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                style={{ width: '100%', height: 470 }}
            />
        </DashboardCardComponent>
    )
}

export default DeliveryDurationChartCard
