import React, { ReactNode, useState, useEffect, useRef } from 'react'
import { Select } from 'antd'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import 'echarts/lib/chart/bar'
import DashboardCardComponent from './dashboard-card-component'
import { topApiReusedOption } from './dashboardInitData'
import { reuseCategory } from './mock'

const { Option } = Select

interface ChartDataProps {
    yAxisData: string[]
    data: number[]
}

interface MockProps {
    name: string
    count: number
}

const TopApiReusedChartCard: React.FC = props => {
    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [groupBy, setGroupBy] = useState<string>('apiName')
    const [reusedCatagory, setReusedCatagory] = useState<string>('all')
    const [pieOption, setPieOption] = useState<any>(topApiReusedOption)

    const dataMap = useRef<Map<any, any>>(new Map())

    const initStatic = () => {
        const mockData = require('./top10.json')
        let apiNameAllData: MockProps[] = []
        const apiNameAll: ChartDataProps = {
            yAxisData: [],
            data: []
        }
        const apiName03: ChartDataProps = {
            yAxisData: [],
            data: []
        }
        const apiName04: ChartDataProps = {
            yAxisData: [],
            data: []
        }
        const apiName05: ChartDataProps = {
            yAxisData: [],
            data: []
        }
        const featureAllData: ChartDataProps = {
            yAxisData: [],
            data: []
        }
        mockData.forEach(item => {
            if (item.groupBy == 'apiName') {
                // if (item.reusedCatagory == 'all') {
                if (item.demandClassfication == '03') {
                    apiName03.yAxisData.push(item.name)
                    apiName03.data.push(item.count)
                } else if (item.demandClassfication == '04') {
                    apiName04.yAxisData.push(item.name)
                    apiName04.data.push(item.count)
                } else if (item.demandClassfication == '05') {
                    apiName05.yAxisData.push(item.name)
                    apiName05.data.push(item.count)
                }

                const index = apiNameAllData.findIndex(ele => {
                    return ele.name === item.name
                })
                if (index !== -1) {
                    apiNameAllData[index].count =
                        item.count + apiNameAllData[index].count
                } else {
                    apiNameAllData.push({
                        name: item.name,
                        count: item.count
                    })
                }
            } else {
                featureAllData.yAxisData.push(item.name)
                featureAllData.data.push(item.count)
            }
        })
        if (apiNameAllData.length) {
            const top10Arr = apiNameAllData
                .sort((a, b) => b.count - a.count)
                .slice(0, 10)
            top10Arr.forEach(item => {
                apiNameAll.yAxisData.push(item.name)
                apiNameAll.data.push(item.count)
            })
        }

        dataMap.current.set('apiName03', apiName03)
        dataMap.current.set('apiName04', apiName04)
        dataMap.current.set('apiName05', apiName05)
        dataMap.current.set('apiNameall', apiNameAll)
        dataMap.current.set('featureall', featureAllData)
    }
    
    const selectChange = (groupBy, reusedCatagory) => {
        setShowLoading(false)
        const { yAxisData, data } = dataMap.current.get(
            `${groupBy}${reusedCatagory}`
        )
        const dataMod = data.sort((a,b)=>a-b)
        setPieOption({
            ...pieOption,
            yAxis: {
                ...pieOption.yAxis,
                data: yAxisData
            },
            series: [
                {
                    ...pieOption.series[0],
                    data:dataMod
                }
            ]
        })
    }

    useEffect(() => {
        setShowLoading(false)
        initStatic()
        selectChange('apiName', 'all')
    }, [])

    return (
        <DashboardCardComponent
            title={'TOP 10 of API Reused'}
            className={'reusability-pie-chart-card'}
            extra={
                <>
                    <span style={{ paddingRight: '1rem' }}>Group by</span>
                    <Select
                        style={{ width: 200 }}
                        value={groupBy}
                        onChange={value => {
                            setGroupBy(value)
                            setReusedCatagory('all')
                            selectChange(value, 'all')
                        }}
                    >
                        <Option value="apiName">API name</Option>
                        <Option value="feature">Feature</Option>
                    </Select>
                </>
            }
        >
            {groupBy === 'apiName' ? (
                <div className={'group-by-select'}>
                    <span>Reused Catagory</span>
                    <Select
                        style={{ width: 200 }}
                        value={reusedCatagory}
                        onChange={value => {
                            setReusedCatagory(value)
                            selectChange(groupBy, value)
                        }}
                    >
                        <Option value="all">All</Option>
                        {reuseCategory.map(item => (
                            <Option value={item.value}>{item.name}</Option>
                        ))}
                    </Select>
                </div>
            ) : null}

            <ReactEchartsCore
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                notMerge={true}
                style={{ height: 400 }}
            />
        </DashboardCardComponent>
    )
}

export default TopApiReusedChartCard
