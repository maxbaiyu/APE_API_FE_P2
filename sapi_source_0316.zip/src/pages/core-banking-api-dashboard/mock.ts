// tracking
export const trackProduct = ['HUB', 'OBS', 'RPS', 'HOGAN']

export const regionMarket = {
    ASP: ['Australia', 'China', 'India', 'Indonesia'],
    EU: ['French', 'Germany', 'Israel', 'Russia'],
    MENA: ['Egypt', 'Qatar', 'UAE'],
    NA: ['Canada', 'Mexico', 'US']
}

export const gbOrGF = ['CMB', 'Digital', 'Finance', 'GBM', 'RBWM']

// top10
export const reuseCategory = [
    // 'New',
    // 'New to Replace',
    { name: 'Reuse with Version Change', value: '03' },
    { name: 'Reuse with Minor Change', value: '04' },
    { name: 'Reuse Direct', value: '05' }
]

// pie Chart
export const reuseCategoryTwo = [
    { name: 'New', value: '01' },
    { name: 'New to Replace', value: '02' },
    { name: 'Reuse with Version Change', value: '03' },
    { name: 'Reuse with Minor Change', value: '04' },
    { name: 'Reuse Direct', value: '05' }
]

export const groupByList = ['Product', 'Region', 'Capability', 'GB/GF']
