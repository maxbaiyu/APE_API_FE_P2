import CreateDemand from '~/assets/svg/home-page/CreateDemand.svg'
import DemandAndDesignApproval from '~/assets/svg/home-page/Demand_Design_Approval.svg'
import InputDesignInfo from '~/assets/svg/home-page/InputDesignInfo.svg'
import Testing from '~/assets/svg/home-page/Testing.svg'
import Development from '~/assets/svg/home-page/Development-unable.svg'
import Catalogue from '~/assets/svg/home-page/APICatalogue&CBServiceCatalogue.svg'
import Deployment from '~/assets/svg/home-page/Deployment.svg'
import ProductionTracker from '~/assets/svg/home-page/ProductionTracker.svg'

interface homePageJumpDatasPro {
    title: String
    iconSrc: any
    histroyGo?: any
    arrow1?: any
    power?: any
    fontColor?: string
}

export const homePageJumpDatas: homePageJumpDatasPro[] = [
    {
        title: 'Create Demand',
        iconSrc: CreateDemand,
        histroyGo: '/pages/demand-request-form',
        power: ['ROLE_01'],
        fontColor:'#305A85'
    },
    {
        title: 'Demand Approval',
        iconSrc: DemandAndDesignApproval,
        histroyGo: '/pages/api-demand-request-list',
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_011'
        ],
        fontColor:'#00847F'
    },
    {
        title: 'Input Design Info',
        iconSrc: InputDesignInfo,
        histroyGo: '/pages/api-demand-request-list',
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_011'
        ],
        fontColor:'#305A85'
    },
    {
        title: 'Design Review',
        iconSrc: DemandAndDesignApproval,
        histroyGo: '/pages/api-review-request-list',
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_011'
        ],
        fontColor:'#00847F'
    },
    {
        title: 'Testing',
        iconSrc: Testing,
        histroyGo: '',
        power: [],
        fontColor:'#D7D8D6'
    },
    {
        title: 'Development',
        iconSrc: Development,
        histroyGo: '',
        power: [],
        // fontColor:'#FFBB33',
        fontColor:'#D7D8D6'
    },
    {
        title: 'API Catalogue',
        iconSrc: Catalogue,
        histroyGo: '/pages/api-catalogue',
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_10',
            'ROLE_011'
        ],
        fontColor:'#305A85'
    },
    {
        title: 'Design Approval',
        iconSrc: DemandAndDesignApproval,
        histroyGo: '/pages/api-review-request-list',
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_011'
        ],
        fontColor:'#00847F'
    },
    {
        title: 'Deployment',
        iconSrc: Deployment,
        histroyGo: '',
        power: [],
        fontColor:'#D7D8D6'
    },
    {
        title: 'Production Tracker',
        iconSrc: ProductionTracker,
        histroyGo: '',
        power: [],
        fontColor:'#D7D8D6'
    },
    {
        title: 'CB Service Catalogue',
        iconSrc: Catalogue,
        histroyGo: '/pages/capability-catalogue',
        arrow1: null,
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_10',
            'ROLE_011'
        ],
        fontColor:'#305A85'
    }
]
