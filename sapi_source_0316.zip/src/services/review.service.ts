/**
 * Review Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { ReviewController } from '~/config/services/review.controller'
import { homepageController } from '~/config/services/homepage.controller'
export class ReviewService {
    /**
     * all
     */
    @Request({
        server: ReviewController.all
    })
    public all(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * commit review commentReviewService
     */
    @Request({
        server: ReviewController.comment
    })
    public comment(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * all
     */
    @Request({
        server: ReviewController.comments
    })
    public comments(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * download contract, response file stream
     */
    @Request({
        server: ReviewController.download
    })
    public download(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * approve review
     */
    @Request({
        server: ReviewController.status
    })
    public status(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * upload review and contract info
     */
    @Request({
        server: ReviewController.upload
    })
    public upload(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get review detail
     */
    @Request({
        server: ReviewController.get
    })
    public get(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    /**
     * delete contract
     */
    @Request({
        server: ReviewController.deleteContract
    })
    public deleteContract(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: ReviewController.information
    })
    public information(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: ReviewController.workflow
    })
    public workflow(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: ReviewController.reopen
    })
    public reopen(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: homepageController.messageGet
    })
    public messageGet(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: homepageController.messagePost
    })
    public messagePost(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: homepageController.messageDelete
    })
    public messageDelete(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: homepageController.details
    })
    public details(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: homepageController.date
    })
    public date(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: homepageController.outstandingApproval
    })
    public outstandingApproval(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: ReviewController.taskAll
    })
    public taskAll(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: ReviewController.taskSubmit
    })
    public taskSubmit(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
