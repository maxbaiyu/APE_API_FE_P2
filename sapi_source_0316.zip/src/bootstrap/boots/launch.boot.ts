import { DirectoryService } from '~/services/directory.service'
import { RequestParams } from '~/core/http'
import { EmptyTokenService } from '../services/empty-token.service'

const DICT_STORE_KEY = 'react-storage'
/**
 * before launch
 */
export default async function () {
    await readySystemDirectory()
}

/**
 * get data dicts
 */
async function readySystemDirectory() {
    const directoryService = new DirectoryService()
    directoryService
        .directories(
            new RequestParams(
                {},
                {
                    deleteToken: new EmptyTokenService()
                }
            )
        )
        .subscribe(data => {
            const storage = localStorage.getItem(DICT_STORE_KEY) || '{}'
            const stroageObject = JSON.parse(storage)

            stroageObject.dict = {
                dicts: data.data
            }

            localStorage.setItem(DICT_STORE_KEY, JSON.stringify(stroageObject))
        })
}
