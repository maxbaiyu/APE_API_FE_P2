/**
 * Directory Controller
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'directory'

export const DirectoryController = {
    // get all data dicts
    directories: {
        controller,
        action: 'directories',
        type: RequestMethod.Get
    },
    // get data dicts by type
    getDirectoryByType: {
        controller,
        action: 'getDirectoryByType',
        type: RequestMethod.Get
    }
}
