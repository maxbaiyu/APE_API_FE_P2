/**
 * Review Service
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'api'

export const CapabilityController = {
    // service
    service: {
        controller,
        action: 'catalogue/service',
        type: RequestMethod.Get
    },
    details:{
        controller,
        action: 'catalogue/service/details',
        type: RequestMethod.Get
    }
}
