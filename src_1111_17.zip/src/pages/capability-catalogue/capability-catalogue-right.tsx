import React, { useState, useRef, useEffect, useImperativeHandle } from 'react';
import { Input, Select, Button, Table } from 'antd';
import CardContainer from '~/shared/components/card-container';
import DataForm from '~/shared/components/data-form';
import DataTable from '~/shared/components/data-table';
import { PageService } from '~/bootstrap/services/page.service';
import { CapabilityService } from '~/services/capability.service';
import { DictUtil } from '~/shared/utils/dict.util';
import { RequestParams } from '~/core/http';
import { serviceTableColumnConst, ServiceTableData } from './data';
import styled from 'styled-components';

const { Column, ColumnGroup } = Table;
const dictUtil = new DictUtil();
const pageService = new PageService();
const capabilityService = new CapabilityService();

interface Props {
    dataSource: any;
    feature: Number;
    service: Number;
    getServiceData: any;
    openKey: string[];
    selectedKey: string[];
    totalServiceCont: number;
    cRef: any;
};

const CapabilityCatalogueManagement = ({ dataSource, feature, service, openKey,
    selectedKey, totalServiceCont, getServiceData, cRef }: Props) => {

    const [serviceDataDetails, setServiceDataDetails] = useState<ServiceTableData[][]>([[]]);
    const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>([]);

    const dataFormRef: any = useRef<HTMLDivElement>(null);

    const renderFormAction = () => {
        return (
            <Button type="primary" danger onClick={() => {
                setExpandedRowKeys([]);
                setServiceDataDetails([[]]);
                getServiceData({ fileValues: dataFormRef.current.formInstance.getFieldsValue() })
            }}>
                Search
            </Button>
        )
    };

    const getServiceDataDetails = ({ capability, feature, serviceDefault }, index) => {
        const fileValues: any = dataFormRef.current.formInstance.getFieldsValue();
        fileValues.service = serviceDefault;
        capabilityService
            .details(new RequestParams(Object.assign(
                { capability, feature, ...fileValues },
                {}), { page: pageService })).subscribe(data => {
                    let serviceData: ServiceTableData[] = [];
                    for (let i = 0; i < data.length; i++) {
                        const { apiType, status, capability, feature, service, backEndSystem, site } = data[i];
                        serviceData.push({
                            ...data[i],
                            key: `${index}_${i}`,
                            apiType: dictUtil.filter('api_type', apiType),
                            status: dictUtil.filter('catalogue_status_type', status),
                            capability: dictUtil.filter('capability', capability),
                            feature: dictUtil.filter(capability, feature),
                            service: dictUtil.filter(feature, service),
                            backEndSystem: dictUtil.filter('backend_system', backEndSystem),
                            site: dictUtil.filter('country', site),
                        });

                    }
                    const allServiceDataDetails = [...serviceDataDetails];
                    allServiceDataDetails[index] = serviceData;
                    setServiceDataDetails(allServiceDataDetails);
                });
    };

    const getExpandTableTitle = () => {
        const serviceTableColumn = serviceTableColumnConst.map(item => {
            const { title, dataIndex, key } = item;
            return <Column
                title={title}
                dataIndex={dataIndex}
                key={key}
            />
        });
        return serviceTableColumn;
    };

    const onExpand = (expanded, record) => {
        const { serviceCode, key } = record;
        if (expanded) {
            setExpandedRowKeys([...expandedRowKeys, key]);
            getServiceDataDetails({ capability: openKey, feature: selectedKey, serviceDefault: serviceCode }, key);
        } else {
            const index = expandedRowKeys.indexOf(key);
            const expandedOldRowKeys = [...expandedRowKeys];
            expandedOldRowKeys.splice(index, 1);
            setExpandedRowKeys(expandedOldRowKeys);
        }
    };

    const expandedRowRender = (record, index, indent, expanded) => {
        const { serviceCode, key } = record;
        const detailsRequestParams = {
            capability: openKey, feature: selectedKey, serviceDefault: serviceCode
        };
        if (serviceDataDetails.length && serviceDataDetails[index]) {
            return <DataTable
                key={`capabilityCatalogue${index}`}
                rowKey={`capabilityCatalogue${index}`}
                dataSource={serviceDataDetails[index]}
                page={pageService}
                onPageChange={() => { getServiceDataDetails(detailsRequestParams, key) }}
                onChange={() => {
                    getServiceDataDetails(detailsRequestParams, key)
                }}
            >
                {getExpandTableTitle()}
            </DataTable>
        }
       
    };

    useImperativeHandle(cRef, () => ({
        getDataFormVal: () => {
            const fileValues: any = dataFormRef.current.formInstance.getFieldsValue();
            return fileValues;
        }
    }));

    useEffect(() => {
        // 切换submenu初始化数据
        setExpandedRowKeys([]);
        setServiceDataDetails([[]]);
    }, [selectedKey]);

    return (
        <div className='flex-auto' style={{ width: '80%' }}>
            <div style={{ padding: '1rem 1.5rem 0 1.5rem' }}>
                <div className='flex-row flex-nowrap justify-content-between'>
                    <h1 style={{ fontSize: '1.5rem' }}>{dictUtil.filter('capability', openKey[0])}</h1>
                    <div>
                        <div style={{ display: "inline-block", width: "auto", marginRight: "0.5rem", verticalAlign: "top", fontWeight: 500 }}>Total:</div>
                        <div style={{ display: "inline-block" }}>
                            <div><span style={{ display: "inline-block", width: '3.5rem' }}>{"Feature"}</span><span>{feature}</span></div>
                            <div><span style={{ display: "inline-block", width: '3.5rem' }}>{"Service"}</span><span>{service}</span></div>
                        </div>
                    </div></div>
                <span style={{ fontSize: '1.1rem' }}>{dictUtil.filter(openKey[0], selectedKey[0])}</span>
            </div>
            <CardContainer title="Search">
                <DataForm
                    name="demo-form"
                    column={2}
                    labelCol={{ span: 6 }}
                    labelAlign="left"
                    ref={dataFormRef}
                    actions={renderFormAction()}
                >
                    <DataForm.Item
                        name="service"
                        label="Service"
                        initialValue=""
                    >
                        <Input />
                    </DataForm.Item>
                    <DataForm.Item
                        name="apiName"
                        label="API Name"
                        initialValue=""
                    >
                        <Input />
                    </DataForm.Item>
                    <DataForm.Item
                        name="apiType"
                        label="API Type"
                        initialValue=""
                    >
                        <Select allowClear>
                            {dictUtil.dicts('api_type', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="status"
                        label="Status"
                        initialValue=""
                    >
                        <Select allowClear>
                            {dictUtil.dicts(
                                'catalogue_status_type',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="backEndSystem"
                        label="Backend System"
                        initialValue=""
                    >
                        <Select allowClear>
                            {dictUtil.dicts('backend_system', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="site"
                        label="Sites"
                        initialValue=""
                    >
                        <Select allowClear>
                            {dictUtil.dicts('country', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                </DataForm>
            </CardContainer>
            <CardContainer title="Service Catalogue">
                <Table
                    key={'capability-catalogue'}
                    size="small"
                    dataSource={dataSource}
                    onExpand={onExpand}
                    expandable={{ expandedRowRender }}
                    expandedRowKeys={expandedRowKeys}
                    pagination={{
                        showSizeChanger: true,
                        total: totalServiceCont,
                        onShowSizeChange: ((current, size) => {
                            const fileValues: any = dataFormRef.current.formInstance.getFieldsValue();
                            getServiceData({ page: current, size, fileValues })
                        }),
                        onChange: ((page, pageSize) => {
                            const fileValues: any = dataFormRef.current.formInstance.getFieldsValue();
                            getServiceData({ page, size: pageSize, fileValues })
                        }
                        )
                    }}
                >
                    <ColumnGroup title="Basic Information">
                        <Column title='No.' dataIndex='serviceNo' key='serviceNo' />
                        <Column title='Services' dataIndex='service' key='service' />
                    </ColumnGroup>
                    <ColumnGroup title="# of MQ Messages" className="blue">
                        <Column title='Total' dataIndex='mqTotal' key='mqTotal' />
                        <Column title='HUB' dataIndex='mqHub' key='mqHub' />
                        <Column title='OBS' dataIndex='mqObs' key='mqObs' />
                        <Column title='RPS' dataIndex='mqRps' key='mqRps' />
                        <Column title='HOGON' dataIndex='mqHogan' key='mqHogan' />
                    </ColumnGroup>
                    <ColumnGroup title="# of API" className="green">
                        <Column title='Total' dataIndex='apiTotal' key='apiTotal' />
                        <Column title='HUB' dataIndex='apiHub' key='apiHub' />
                        <Column title='OBS' dataIndex='apiObs' key='apiObs' />
                        <Column title='RPS' dataIndex='apiRps' key='apiRps' />
                        <Column title='HOGON' dataIndex='apiHogan' key='apiHogan' />
                    </ColumnGroup>
                    <ColumnGroup title="">
                        <Column title='Batch' dataIndex='batch' key='batch' />
                    </ColumnGroup>
                </Table>
                {/* {renderPaginationContainer()} */}
            </CardContainer>
        </div >
    )
};

export default CapabilityCatalogueManagement;