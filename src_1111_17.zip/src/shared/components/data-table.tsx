import React, { Key } from 'react'
import styled from 'styled-components'
import { Button, Table, Pagination } from 'antd'
import {
    SorterResult,
    TableCurrentDataSource,
    TablePaginationConfig,
    TableRowSelection
} from 'antd/lib/table/interface'
import { PageService } from '~/bootstrap/services/page.service'

const components = {
    Wrapper: styled.section``,
    TabContainer: styled.div``,
    PageinationContainer: styled.div`
        padding: 10px 0;
    `,
    ActionContainer: styled.div`
        padding: 10px 0;
        .ant-btn {
            margin-right: 15px;
        }
    `
}

interface ComponentProp {
    rowKey: string
    page?: PageService
    dataSource: any[]
    pageService?: PageService
    rowSelection?: TableRowSelection<Record<string, any>>
    height?: string
    actions?: React.ReactNode
    actionPosition?: 'top' | 'bottom'
    onPageChange?: () => void
    onChange?: (pagination: any, filters: any, sorter: any, extra: any) => void
}

export default class DataTable extends React.Component<ComponentProp> {
    private default = {
        height: 100,
        actionPosition: 'bottom'
    }
    public render() {
        const { page } = this.props
        const actionPosition =
            this.props.actionPosition || this.default.actionPosition

        return (
            <components.Wrapper>
                {actionPosition === 'top' && this.renderActionContainer()}
                {this.renderTableContainer()}
                {page && this.renderPaginationContainer()}
                {actionPosition === 'bottom' && this.renderActionContainer()}
            </components.Wrapper>
        )
    }

    public renderActionContainer() {
        return (
            <components.ActionContainer>
                {this.props.actions}
            </components.ActionContainer>
        )
    }

    public renderTableContainer() {
        const {
            dataSource,
            rowSelection,
            height,
            rowKey,
            onChange
        } = this.props
        const setX  = Boolean(dataSource.length) ? true : undefined;

        return (
            <components.TabContainer>
                <Table
                    rowKey={rowKey}
                    scroll={{
                        x: setX
                    }}
                    rowSelection={rowSelection}
                    dataSource={dataSource}
                    pagination={false}
                    size="small"
                    bordered
                    onChange={onChange}
                >
                    {this.props.children}
                </Table>
            </components.TabContainer>
        )
    }

    public renderPaginationContainer() {
        const pageConfig = this.getPageConfig()

        return (
            <components.PageinationContainer>
                <Pagination
                    showSizeChanger
                    onChange={this.onChange.bind(this)}
                    onShowSizeChange={this.onChange.bind(this)}
                    {...pageConfig}
                />
            </components.PageinationContainer>
        )
    }
    private onChange(pageIndex, pageSize) {
        const onPageChange = this.props.onPageChange
        const page = this.props.page as PageService

        page.update(pageIndex, pageSize).then(() => {
            onPageChange && onPageChange()
        })
    }

    private getPageConfig() {
        const page = this.props.page as PageService

        return {
            current: page.pageIndex,
            total: page.total,
            pageSize: page.pageSize,
            pageSizeOptions: page.pageSizeOpts,
            showTotal: () =>
                `Total ${Math.ceil(page.total / page.pageSize)} Pages`
        }
    }
}
