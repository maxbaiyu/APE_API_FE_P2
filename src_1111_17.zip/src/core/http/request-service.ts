import axios, { AxiosInstance, AxiosResponse } from 'axios'
import { RequestOption } from './request-option'
import { RequestInterceptor } from './request-interceptor'
import { ExtendService } from './extend-service'
export class RequestService {
    // server config
    public static config = {
        server: '',
        timeout: 1000 * 60 * 15
    }

    // Request Singleton instance
    private static instance: RequestService

    // interceptors
    public static interceptors = {
        // before interceptors
        before: [],
        // after interceptors
        after: [],
        // status interceptor
        status: new RequestInterceptor<boolean>(),
        // success interceptor
        success: new RequestInterceptor(),
        // error interceptor
        error: new RequestInterceptor()
    }

    // Get Request Url
    public static getRequestUrl: (option: RequestOption) => string

    // Get Request Header
    public static getRequestHeader: (option: RequestOption) => any

    // Request Catch Handle
    public static requestCatchHandle: (respone: AxiosResponse) => void

    // Global Extend Services
    public static extendServices: ExtendService[] = []

    /**
     * set http request config 
     * @param param
     */
    public static setConfig({ server, timeout }) {
        RequestService.config.server = server
        RequestService.config.timeout = timeout
    }

    /**
     * install Extend Service
     * @param service
     */
    public static installExtendService(service: ExtendService) {
        RequestService.extendServices.push(service)
    }

    /**
     * get request instance
     */
    public static getInstance() {
        if (this.instance) {
            return this.instance
        }

        return new RequestService()
    }

    // axios Instance
    private axiosInstance: AxiosInstance

    /**
     * constructor
     */
    constructor() {
        RequestService.instance = this
        // create axios Instance
        this.axiosInstance = axios.create({
            baseURL: RequestService.config.server,
            timeout: RequestService.config.timeout,
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        })
    }

    /**
     * send http request
     * @param param
     */
    public send(requestOption: RequestOption) {
        // get request Option
        const options = requestOption.getOptions()

        // send http requst
        return this.axiosInstance
            .request({
                // default options
                ...options
            })
            .then((response: AxiosResponse<any>) => {
                // no status interceptor return success
                if (!RequestService.interceptors.status.defined) {
                    return RequestService.interceptors.success.defined
                        ? RequestService.interceptors.success.interceptor(
                              response
                          )
                        : response
                }

                // check http reqeust status
                if (RequestService.interceptors.status.interceptor(response)) {
                    // success
                    return RequestService.interceptors.success.defined
                        ? RequestService.interceptors.success.interceptor(
                              response
                          )
                        : response
                } else {
                    // error
                    return RequestService.interceptors.error.defined
                        ? RequestService.interceptors.error.interceptor(
                              response
                          )
                        : response
                }
            })
            .catch(ex => {
                if (RequestService.requestCatchHandle) {
                    RequestService.requestCatchHandle(ex.response)
                }
                return Promise.reject(ex)
            })
    }
}
