module.exports = {
    '/api': {
        target: 'http://47.104.172.105:8080/',
        ws: true,
        changeOrigin: true,
        pathRewrite: {
            '^/api': ''
        }
    }
}


