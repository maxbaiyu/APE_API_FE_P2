/**
 * Tools for code generation controller
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'tools'

export const ToolsController = {
    // generate iws code
    iws: {
        controller,
        action: 'iws',
        type: RequestMethod.Post
    },
    // generate mule code
    muleProject: {
        controller,
        action: 'mule-project',
        type: RequestMethod.Post
    },
    // generate raml code
    raml: {
        controller,
        action: 'raml',
        type: RequestMethod.Post
    }
}
