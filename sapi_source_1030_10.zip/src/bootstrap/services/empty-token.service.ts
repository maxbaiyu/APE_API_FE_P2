import { ExtendService, RequestParams } from '~/core/http'
const STORAGE_KEY = 'react-storage'

// 认证信息服务
export class EmptyTokenService extends ExtendService {
    public before = params => {
        params.options.header && delete params.options.header['Authorization']
    }
}
