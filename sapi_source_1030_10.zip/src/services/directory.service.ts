/**
 * Directory service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { DirectoryController } from '~/config/services/directory.controller'

export class DirectoryService {
    /**
     * get all data dicts
     */
    @Request({
        server: DirectoryController.directories
    })
    public directories(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get data dicts by type
     */
    @Request({
        server: DirectoryController.getDirectoryByType
    })
    public getDirectoryByType(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
