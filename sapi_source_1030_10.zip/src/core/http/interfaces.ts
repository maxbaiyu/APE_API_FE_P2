import { RequestMethod } from './enums'

/**
 * Request Server config interface
 */
export interface IRequestServerConfig {
    service?: string
    controller: string
    action?: string
    type: RequestMethod
}

/**
 * Request params interface 
 */
export interface IRequestParamsOption {
    append?: any[]
    header?: any
    [propName: string]: any
}

export interface IExtendServiceResult {
    override: boolean
    data: any
}
