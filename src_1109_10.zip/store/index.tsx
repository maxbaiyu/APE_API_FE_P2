import React from 'react'

import { UserStoreProvider, UserStore } from './user.store'
import { PageStoreProvider, PageStore } from './page.store'
import { DictStoreProvider, DictStore } from './dict.store'

import { Presist } from './plugins/persist'

const providers: any[] = [
    UserStoreProvider,
    PageStoreProvider,
    DictStoreProvider
]
const stores: any[] = [UserStore, DictStore]

const ProvidersComposer = props =>
    props.providers.reduceRight(
        (children, Parent) => <Parent>{children}</Parent>,
        props.children
    )

export const Provider = props => (
    <ProvidersComposer providers={providers}>
        <Presist stores={stores}>{props.children}</Presist>
    </ProvidersComposer>
)
