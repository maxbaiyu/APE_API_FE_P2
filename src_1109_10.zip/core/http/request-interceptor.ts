import { AxiosResponse } from 'axios'

/**
 * Request Interceptor
 */
export class RequestInterceptor<T> {
    /**
     * Interceptor status
     */
    public defined: boolean = false

    /**
     * Interceptor
     */
    public interceptor!: (response: AxiosResponse) => T

    /**
     * register interceptor
     * @param callback
     */
    public use(callback: (response: AxiosResponse) => T) {
        this.defined = true
        this.interceptor = callback
    }
}
