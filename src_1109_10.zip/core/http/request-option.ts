import Qs from 'qs'
import { IRequestServerConfig } from './interfaces'
import { RequestParams } from './request-params'
import { RequestMethod } from './enums'
import { RequestService } from './request-service'

/**
 * RequestOption
 */
export class RequestOption {
    // Request Server
    private readonly requestServer: IRequestServerConfig
    // Request Params
    private readonly requestParams: RequestParams
    /**
     * constructor
     * @param requestServer Request Server
     * @param params Params
     */
    constructor(
        requestServer: IRequestServerConfig,
        requestParams: RequestParams
    ) {
        this.requestServer = requestServer
        this.requestParams = requestParams
    }

    /**
     * get reqeust options
     */
    public getOptions() {
        for (const service of this.requestParams.getExtendService()) {
            service.before && service.before(this.requestParams)
        }

        return {
            url: RequestService.getRequestUrl
                ? RequestService.getRequestUrl(this)
                : this.getRequestUrl(),
            headers: RequestService.getRequestHeader
                ? RequestService.getRequestHeader(this)
                : this.requestParams.options.header,
            method: this.requestServer.type,
            // get post requst params
            data: this.getParamsByMethod(false),
            // get get requst params
            params: this.getParamsByMethod(true),
            // params Serializer:use for get request
            paramsSerializer: params =>
                Qs.stringify(params, {
                    arrayFormat: 'repeat',
                    skipNulls: true,
                    allowDots: true
                })
        }
    }

    /**
     * get Request Url
     */
    public getRequestUrl() {
        if (!this.requestServer) {
            throw new Error('server config error,please check server config')
        }

        // request Server Array
        // URL pattern: baseUrl/service/controller/action/append
        const requestServerArray = [
            this.requestServer.service || '',
            this.requestServer.controller || '',
            this.requestServer.action || '',
            ...(this.requestParams.options.append
                ? this.requestParams.options.append
                : [])
        ]

        return requestServerArray.filter(x => x).join('/')
    }

    /**
     * get Params By Method
     */
    private getParamsByMethod(isGet: boolean) {
        if (this.isGetMethod() !== isGet) {
            return {}
        }

        // if reqeust method is get filter empty data
        if (isGet) {
            return this.filterEmptyData(this.requestParams.data)
        } else {
            return this.requestParams.data
        }
    }

    /**
     * is Get Method
     */
    private isGetMethod() {
        return [RequestMethod.Get, RequestMethod.Delete].includes(
            this.requestServer.type
        )
    }

    /**
     * filter Empty Data
     * @param data
     */
    private filterEmptyData(values) {
        // copy data
        const data = { ...values }

        // filter data
        Object.entries(data)
            .filter(([key, value]: [any, any]) => {
                // filter blank data
                if (value === undefined || value === '') {
                    return true
                }

                // filter empty array
                if (
                    value instanceof Array &&
                    (value.length === 0 || value.every(x => x === ''))
                ) {
                    return true
                }

                return false
            })
            .forEach(([key, value]) => {
                delete data[key]
            })

        return data
    }
}
