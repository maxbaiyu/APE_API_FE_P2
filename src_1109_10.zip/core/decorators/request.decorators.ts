import { RequestObject } from '../http/request-object'
import { RequestParams } from '../http/request-params'
import { IRequestServerConfig } from '../http/interfaces'
import { Model } from '../model'
/**
 * http request decorator
 */
export function Request({
    server,
    model,
    force
}: {
    server: IRequestServerConfig
    model?: { prototype: Model }
    force?: boolean
}) {
    return (target, name, descriptor) => {
        const generateRequestObject = () => {
            // request object
            const object = new RequestObject(server)

            // set response model
            if (model) {
                object.setResponseModel(model)
            }

            return object
        }

        const requestObject = generateRequestObject()

        // save history
        const _value = descriptor.value

        // set new request
        descriptor.value = (requestParams: RequestParams) => {
            if (force) {
                requestParams.setRequestObject(generateRequestObject())
            } else {
                // set request object
                requestParams.setRequestObject(requestObject)
            }

            // update new reqeuts object
            return _value.call(target, requestParams)
        }

        return descriptor
    }
}
