import React from 'react'
import styled from 'styled-components'
import { Button, Table, Pagination, Form, Row, Col } from 'antd'
import { FormItemProps } from 'antd/lib/form'
import * as R from 'ramda'
const components = {
    Wrapper: styled.section``
}

interface ComponentProp extends FormItemProps {
    collapse?: boolean
}

export default class DataForm extends React.Component<ComponentProp> {
    public render() {
        const props = R.omit(['collapse'], this.props)
        return <Form.Item {...props}>{this.props.children}</Form.Item>
    }
}
