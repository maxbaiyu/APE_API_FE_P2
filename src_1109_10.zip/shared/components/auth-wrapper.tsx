import React, { Component } from 'react'
import * as R from 'ramda'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'

export enum AuthMode {
    default,
    disable
}

export const AuthWrapper = (
    ComposedComponent,
    mode: AuthMode = AuthMode.default
) =>
    class AuthComponent extends React.Component<any, any> {
        private renderModelList = new Map<AuthMode, Function>([
            [AuthMode.default, this.defaultAuthRender],
            [AuthMode.disable, this.disableAuthRender]
        ])

        /**
         * get role state
         * @param store
         */
        private getRoleState(store) {
            const roleList = R.path(['state', 'roleList'], store) as any[]
            const { auth } = this.props
            if (!roleList || !auth) {
                return
            }

            return auth.some(role =>
                roleList.map(x => x.authority).includes(role)
            )
        }

        public render() {
            return (
                <Consumer of={UserStore}>
                    {store => this.authRender(store)}
                </Consumer>
            )
        }

        /**
         * auth components render
         * @param store
         */
        public authRender(store) {
            const isAuth = this.getRoleState(store)
            const props = R.omit(['auth'], this.props)
            const render = this.renderModelList.get(mode)

            if (render) {
                return render(isAuth, props)
            }
        }

        public defaultAuthRender(isAuth, props) {
            if (isAuth) {
                return <ComposedComponent {...props}></ComposedComponent>
            } else {
                return <></>
            }
        }

        public disableAuthRender(isAuth, props) {
            return (
                <ComposedComponent
                    disabled={!isAuth}
                    {...props}
                ></ComposedComponent>
            )
        }
    }
