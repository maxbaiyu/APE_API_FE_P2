export default {
    server: process.env.REACT_APP_SERVER, // app server adddress
    debug: process.env.NODE_ENV === 'development',
    timeout: process.env.REACT_APP_TIMEOUT
}
