import { IRequestServerConfig } from '../core/http'

export type ControllerConfig = { [key: string]: IRequestServerConfig }
