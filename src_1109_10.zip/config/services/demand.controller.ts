/**
 * Demand Controller
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'demand'

export const DemandController = {
    // create demand
    post: {
        controller,
        type: RequestMethod.Post
    },
    // update demand
    put: {
        controller,
        type: RequestMethod.Put
    },
    // all
    all: {
        controller,
        action: 'all',
        type: RequestMethod.Get
    },
    // demand approve
    status: {
        controller,
        action: 'status',
        type: RequestMethod.Put
    },
    get: {
        controller,
        type: RequestMethod.Get
    }
}
