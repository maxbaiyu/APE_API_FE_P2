/**
 * Login Controller
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'auth'

export const AuthController = {
    // login
    login: {
        controller,
        action: 'login',
        type: RequestMethod.Post
    }
}
