import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { ApiService } from '~/services/api.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import CustomizeModal from '~/shared/components/customize-modal'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface ApiDetailFormState {
    id: string
    data: any
    successModalVisible: boolean
    featureData: any[]
    serviceData: any[]
}

interface ApiDetailFormProps {}

export default class ApiDetailForm extends Component<
    RouteComponentProps<ApiDetailFormProps>,
    ApiDetailFormState
> {
    private dataFromRef!: React.RefObject<DataForm>

    private apiService = new ApiService()
    private dictUtil = new DictUtil()
    private applicableChannels = ''
    private applicableGb = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            successModalVisible: false,
            featureData: [],
            serviceData: []
        }
    }

    public componentDidMount() {
        const { id } = this.props.location.state as ApiDetailFormState
        this.apiService
            .getById(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    data: data.ossApi
                })

                this.dataForm.formInstance.setFieldsValue(data.ossApi)
            })
    }

    public render() {
        const { data, featureData, serviceData } = this.state
        if (data?.applicableChannels2 != null) {
            this.applicableChannels =
                this.dictUtil.filter(
                    'applicable_channels',
                    data?.applicableChannels
                ) +
                '-' +
                data?.applicableChannels2
        } else {
            this.applicableChannels = this.dictUtil.filter(
                'applicable_channels',
                data?.applicableChannels
            )
        }
        if (data?.applicableGB2 != null) {
            this.applicableGb =
                this.dictUtil.filter('applicable_gb', data?.applicableGb) +
                '-' +
                data?.applicableGb2
        } else {
            this.applicableGb = this.dictUtil.filter(
                'applicable_gb',
                data?.applicableGb
            )
        }

        return (
            <components.PageContainer title="API Detail">
                <div
                    style={{ fontSize: 28 }}
                    className="flex-row justify-content-between"
                >
                    <div>Customer Credit Card Creation</div>
                    <div>
                        <Button
                            onClick={() => {
                                this.props.history.goBack()
                            }}
                        >
                            Back
                        </Button>
                    </div>
                </div>
                <Divider />
                <CardContainer title="Basic Information">
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                    >
                        <LabelContainer column={1} labelSpan={4}>
                            <LabelItem label="Applicable Channels">
                                {this.applicableChannels}
                            </LabelItem>
                            <LabelItem label="Applicable GB">
                                {this.applicableGb}
                            </LabelItem>
                            <LabelItem label="Latest Version">
                                {data?.latestVersion}
                            </LabelItem>
                        </LabelContainer>
                        <Form.Item name="apiType" label="API Type">
                            <Select>
                                {this.dictUtil.dicts('api_type', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item name="apiMethod" label="API Method">
                            <Select>
                                <Select.Option value="GET">GET</Select.Option>
                                <Select.Option value="POST">POST</Select.Option>
                                <Select.Option value="PUT">PUT</Select.Option>
                                <Select.Option value="DELETE">
                                    DELETE
                                </Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item name="status" label="Status">
                            <Select>
                                {this.dictUtil.dicts(
                                    'catalogue_status_type',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item name="capability" label="Capability">
                            <Select
                                onChange={value => {
                                    const features = this.dictUtil.dicts(value)
                                    this.setState({
                                        featureData: features
                                    })
                                    this.dataForm.formInstance.resetFields([
                                        'service',
                                        'feature'
                                    ])
                                }}
                            >
                                {this.dictUtil.dicts('capability', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item name="feature" label="Feature">
                            <Select
                                onChange={value => {
                                    const services = this.dictUtil.dicts(value)
                                    this.setState({
                                        serviceData: services
                                    })
                                    this.dataForm.formInstance.resetFields([
                                        'service'
                                    ])
                                }}
                            >
                                {featureData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item name="service" label="Service">
                            <Select>
                                {serviceData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="globalOrRegOrLoc"
                            label="Global/Regional/Local"
                        >
                            <Select>
                                <Select.Option value="Global">
                                    Global
                                </Select.Option>
                                <Select.Option value="Regional">
                                    Regional
                                </Select.Option>
                                <Select.Option value="Local">
                                    Local
                                </Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item name="hubApiId" label="HUB API ID">
                            <Input />
                        </Form.Item>
                        <Form.Item name="description" label="Description">
                            <Input />
                        </Form.Item>
                    </DataForm>
                    <Divider />
                    <div
                        style={{ width: '100%' }}
                        className="flex-row justify-content-end"
                    >
                        <components.AuthDisableButton
                            type="primary"
                            size="large"
                            danger
                            onClick={() => this.submit()}
                            auth={['ROLE_01']}
                        >
                            Submit
                        </components.AuthDisableButton>
                    </div>
                </CardContainer>
                {this.renderModal()}
            </components.PageContainer>
        )
    }

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="API Catalogue -->"
                cancelText="Close"
                content="Check Status in API Catalogue."
                onOk={() => {
                    this.props.history.push('/pages/api-catalogue')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }

    private submit() {
        const { data } = this.state
        this.apiService
            .update(
                new RequestParams({
                    ...this.dataForm.formInstance.getFieldsValue(),
                    apiCatalogueId: data.apiCatalogueId
                })
            )
            .subscribe(data => {
                this.openSuccessModal()
            })
    }

    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
}
