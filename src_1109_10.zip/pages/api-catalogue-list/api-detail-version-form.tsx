import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { ApiService } from '~/services/api.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import CustomizeModal from '~/shared/components/customize-modal'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface ApiVersionDetailFormState {
    id: string
    data: any
    successModalVisible: boolean
}

interface ApiVersionDetailFormProps {}

export default class ApiDetailForm extends Component<
    RouteComponentProps<ApiVersionDetailFormProps>,
    ApiVersionDetailFormState
> {
    private dataFromRef!: React.RefObject<DataForm>

    private apiService = new ApiService()
    private dictUtil = new DictUtil()
    private versionApplicableChannels = ''
    private versionApplicableGb = ''
    private versionApplicableCountries = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            successModalVisible: false
        }
    }

    public componentDidMount() {
        const { id } = this.props.location.state as ApiVersionDetailFormState
        this.apiService
            .getVersionById(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    data: data
                })

                this.dataForm.formInstance.setFieldsValue(data)
            })
    }

    public render() {
        const { data } = this.state
        console.log(data)
        if (data?.applicableChannels2 != null) {
            this.versionApplicableChannels =
                this.dictUtil.filter(
                    'applicable_channels',
                    data?.applicableChannels
                ) +
                '-' +
                data?.applicableChannels2
        } else {
            this.versionApplicableChannels = this.dictUtil.filter(
                'applicable_channels',
                data?.applicableChannels
            )
        }
        if (data?.applicableGb2 != null) {
            this.versionApplicableGb =
                this.dictUtil.filter('applicable_gb', data?.applicableGb) +
                '-' +
                data?.applicableGb2
        } else {
            this.versionApplicableGb = this.dictUtil.filter(
                'applicable_gb',
                data?.applicableGb
            )
        }
        if (data?.applicableCountries2 != null) {
            this.versionApplicableCountries =
                this.dictUtil.filter(
                    'applicable_countries',
                    data?.applicableCountries
                ) +
                '-' +
                data?.applicableCountries2
        } else {
            this.versionApplicableCountries = this.dictUtil.filter(
                'applicable_countries',
                data?.applicableCountries
            )
        }
        return (
            <components.PageContainer title="API Version Detail" noHeader={true}>
                <div
                    style={{ fontSize: 28 }}
                    className="flex-row justify-content-between"
                >
                    <div>Customer Credit Card Creation</div>
                    <div>
                        <Button
                            size="large"
                            onClick={() => {
                                this.props.history.goBack()
                            }}
                        >
                            Back
                        </Button>
                    </div>
                </div>
                <Divider />

                <CardContainer title="Version v1.0.0">
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                    >
                        <LabelContainer column={1} labelSpan={4}>
                            <LabelItem label="API Name">
                                {data?.apiName}
                            </LabelItem>
                            <LabelItem label="API Version">
                                {data?.version}
                            </LabelItem>
                            <LabelItem label="Core Banking API ID">
                                {data?.hubApiId}
                            </LabelItem>
                            <LabelItem label="Applicable Channels">
                                {this.versionApplicableChannels}
                            </LabelItem>
                            <LabelItem label="Applicable GB/GF">
                                {this.versionApplicableGb}
                            </LabelItem>
                            <LabelItem label="Applicable Countries">
                                {this.versionApplicableCountries}
                            </LabelItem>
                        </LabelContainer>
                        <Form.Item name="trueSapiId" label="API ID">
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="applicableHubVersion"
                            label="Applicable HUB Version"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="apiLifecycleStage"
                            label="API Lifecycle Stage"
                        >
                            <Select disabled>
                                {this.dictUtil.dicts(
                                    'api_lifecycle_stage',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item name="hubPgmFlow" label="HUB PGM Flow">
                            <Input />
                        </Form.Item>
                        <Form.Item name="enhancement" label="Enhancement">
                            <Input />
                        </Form.Item>
                        <LabelContainer column={1}>
                            <LabelItem label="HUB API Documents">
                                <div className="full-width">
                                    <Form.Item
                                        name="hubApiContract"
                                        label="API Contract"
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="hubErrorScenario"
                                        label="Error Scenario"
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="hubFunctionalDesign"
                                        label="Funtional Design"
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="iwsPostmanJson"
                                        label="IWS Postman JSON Data"
                                    >
                                        <Input />
                                    </Form.Item>
                                </div>
                            </LabelItem>
                            <LabelItem label="Mul API Documents">
                                <div className="full-width">
                                    <Form.Item
                                        name="apiCertPcfUrl"
                                        label="CERT PCF URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiInteralGatewayUrl"
                                        label="Internal Gateway URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiGitRepo"
                                        label="Git Repository URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiJenkinsUrl"
                                        label="Jenkins URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiRaml"
                                        label="RAML URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiPostmanJsonData"
                                        label="Mule Postman JSON Data"
                                    >
                                        <Input />
                                    </Form.Item>
                                </div>
                            </LabelItem>
                            <LabelItem label="Certification Result">
                                <div className="full-width">
                                    <Form.Item
                                        name="certificatePageUrl"
                                        label="URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="ptPostmanJson"
                                        label="PT Postman JSON Data"
                                    >
                                        <Input />
                                    </Form.Item>
                                </div>
                            </LabelItem>
                        </LabelContainer>

                        <Form.Item name="sampleApiCall" label="Sample API Call">
                            <Input />
                        </Form.Item>
                    </DataForm>
                    <div
                        style={{ width: '100%' }}
                        className="flex-row justify-content-end"
                    >
                        <components.AuthDisableButton
                            type="primary"
                            size="large"
                            danger
                            onClick={() => this.submit()}
                            auth={['ROLE_01']}
                        >
                            Submit
                        </components.AuthDisableButton>
                    </div>
                </CardContainer>
                {this.renderModal()}
            </components.PageContainer>
        )
    }

    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="API Catalogue -->"
                cancelText="Close"
                content="Check Status in API Catalogue."
                onOk={() => {
                    this.props.history.push('/pages/api-catalogue')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private submit() {
        const { data } = this.state
        this.apiService
            .updateVersion(
                new RequestParams({
                    ...this.dataForm.formInstance.getFieldsValue(),
                    versionId: data.versionId
                })
            )
            .subscribe(data => {
                this.openSuccessModal()
            })
    }

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }

    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
}
