import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import { Chart, Tooltip, Facet, Legend, Axis, Bar } from 'viser-react'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    message,
    Button,
    Select,
    Card,
    Col,
    Row,
    Space
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import StepItem from '~/shared/components/step-item'
import { truncate } from 'fs/promises'
import { DictUtil } from '~/shared/utils/dict.util'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'

const components = {
    PageContainer: styled(PageContainer)`
        .ant-card-head {
            border-bottom: 1px solid transparent !important;
        }
    `,
    Card: styled(Card)`
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        .ant-card-head {
            border-bottom: 1px solid transparent !important;
        }
    `
}

interface HomePageState {}

interface HomePageProps {}

export default class HomePage extends Component<
    RouteComponentProps<HomePageProps>,
    HomePageState
> {
    private dictUtil = new DictUtil()

    constructor(props) {
        super(props)
    }

    public componentDidMount() {}

    public render() {
        return (
            <components.PageContainer
                width="100%"
                title="Homepage"
                noHeader={true}
            >
                {this.renderPageContent()}
            </components.PageContainer>
        )
    }
    private renderPageContent() {
        return (
            <div className="ant-card-body">
                <Row gutter={[14, 14]}>
                    <Col span={12}>
                        <Space
                            direction="vertical"
                            style={{ width: '100%' }}
                            size="middle"
                        >
                            <components.Card title="API Summary">
                                {this.renderApiSummaryChart()}
                            </components.Card>

                            {this.renderAnnouncement()}
                        </Space>
                    </Col>

                    <Col span={12}>
                        <Space
                            direction="vertical"
                            style={{ width: '100%' }}
                            size="middle"
                        >
                            {this.renderGuidelines()}
                        </Space>
                    </Col>
                </Row>
            </div>
        )
    }

    private renderAnnouncement() {
        return (
            <components.Card
                title={
                    <div>
                        <div>Announcement</div>
                    </div>
                }
            >
                <Card>
                    <div style={{ fontSize: 12 }}>2020-09-21 09:00</div>
                    API Governance Tool - APE V1.0.0 Production Release.
                </Card>
            </components.Card>
        )
    }
    private renderGuidelines() {
        return (
            <components.Card title="Core Banking TRUE SAPI Guidelines and Standards">
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/pages/viewpage.action?pageId=445920102'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI Architecture
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/API+Header'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI API Header
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Authorization+Framework'
                        )
                    }}
                >
                    • Authorization Framework
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Reusability+Design'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI Reusability Design
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Contract+Standard'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI Contract Standard
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Terminology'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI Terminology
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Versioning'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI Versioning
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Naming+Convention'
                        )
                    }}
                >
                    • Core Banking TRUE SAPI Naming Convention
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Channel+Agnostic+Design+Principles'
                        )
                    }}
                >
                    • Channel Agnostic Design Principles
                </Button>
                <br />
                <Button
                    type="link"
                    onClick={() => {
                        window.open(
                            'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/IWS+Coding+Standards'
                        )
                    }}
                >
                    • IWS Coding Standards
                </Button>
            </components.Card>
        )
    }
    private renderApiSummaryChart() {
        const data = [
            {
                type: 'API',
                soon: 655,
                live: 268
            },
            {
                type: 'TRUESAPI',
                soon: 155,
                live: 50
            }
        ]
        const scale = [{
            dataKey: 'sales',
            tickInterval: 20,
          }];
        const eachView = function (view, facet) {
            var [data] = facet.data
            const dataSource = Object.entries(data)
                .filter(([key, value]) => key !== 'type')
                .map(([key, value]) => ({
                    type: key,
                    value: value as number
                }))

            const sum = dataSource.reduce((sum, x) => (sum += x.value), 0)

            view.source(dataSource)

            view.coord('theta', {
                radius: 0.8,
                innerRadius: 0.75
            })

            view.intervalStack()
                .position('value')
                .color('type', ['#1087EF', '#4E9C2D'])
                .opacity(1)
                .label('value', {
                    offset: 16,
                    labelLine: {
                        lineWidth: 2,
                        stroke: 'rgba(0, 0, 0, 0.5)'
                    },
                    useHtml: true,
                    htmlTemplate: (text, item) => {
                        const percent = (
                            (item.point.value / sum) *
                            100
                        ).toFixed(2)
                        return `<span style="font-weight:bold;padding-right:10px;">${item.point.value}</span><span style="font-weight:bold;color:rgba(0,0,0,0.5);">${percent}%</span>`
                    },
                    offsetY: 5 //偏移量
                })

            view.guide().html({
                position: ['50%', '50%'],
                html: `<div style="font-size:36px;color:rgba(0,0,0,0.4);text-align:center;"><div style="width: 100px; word-break: break-all;">${data.type}</div></div>`
            })
        }
        return (
            <Chart forceFit data={data} height={400} scale={scale} padding="auto" >
                <Tooltip />
                {/* <Axis />
              <Bar position="year*sales" /> */}
                <Legend textStyle={{ fontSize: 24 }} itemWidth={100} />
                <Facet
                    type="list"
                    cols={2}
                    fields={['type']}
                    padding={20}
                    showTitle={false}
                    eachView={eachView}
                />
            </Chart>
        )
    }
}
