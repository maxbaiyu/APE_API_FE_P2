export interface TableListItem {
    key: Number;
    serviceNo: String;
    service: String;
    mqTotal: Number;
    mqHub: String;
    mqObs: String;
    mqRps: String;
    mqHogan: String;
    apiTotal: Number;
    apiHub: String;
    apiObs: String;
    apiRps: String;
    apiHogan: String;
    batch: String;
};

export interface ServiceTableData {
    key: Number;
    apiId: String;
    apiName: String;
    apiType: String;
    status: String;
    capability: String;
    feature: String;
    service: String;
    backEndSystem: String;
    site: String;
};



export const serviceTableColumnConst = [
    { title: 'Ref No', dataIndex: 'apiId', key: 'apiId' },
    { title: 'API Name', dataIndex: 'apiName', key: 'apiName' },
    {
        title: 'API Type',
        key: 'apiType',
        dataIndex: 'apiType',
    },
    { title: 'Status', dataIndex: 'status', key: 'status' },
    {
        title: 'Capability',
        dataIndex: 'capability',
        key: 'capability'
    },
    {
        title: 'Feature',
        dataIndex: 'feature',
        key: 'feature'
    },
    {
        title: 'Service',
        dataIndex: 'service',
        key: 'service'
    },
    {
        title: 'Backend System',
        dataIndex: 'backEndSystem',
        key: 'backEndSystem'
    },
    {
        title: 'Site',
        dataIndex: 'site',
        key: 'site'
    }
];
