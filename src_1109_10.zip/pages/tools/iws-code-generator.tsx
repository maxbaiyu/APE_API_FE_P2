import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { Consumer } from 'reto'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Button,
    Upload,
    Row,
    Col,
    Avatar,
    Tooltip,
    List,
    Comment,
    message,
    Alert
} from 'antd'
import { UserStore } from '~/store/user.store'
import DataForm from '~/shared/components/data-form'
import { ArrowDownOutlined, UploadOutlined } from '@ant-design/icons'
import { ToolsService } from '~/services/tools.service'
import { RequestParams } from '~/core/http'
import { ok } from 'assert'
import appConfig from '~/config/app.config'
import { FileService } from '~/services/file.service'
import { isNullOrUndefined } from 'util'
const components = {
    PageContainer: styled(PageContainer)``
}

interface IwsGeneratorState {
    contractPath: string
}

interface IwsGeneratorProps {}

export default class IwsGenerator extends Component<
    RouteComponentProps<IwsGeneratorProps>,
    IwsGeneratorState
> {
    private dataFromRef!: React.RefObject<DataForm>
    private toolsService = new ToolsService()
    private fileService = new FileService()

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.state = {
            contractPath: ''
        }
    }

    public render() {
        return (
            <Consumer of={UserStore}>
                {userStore => this.renderForm(userStore)}
            </Consumer>
        )
    }

    private renderForm(userStore) {
        const uploadProps = {
            name: 'file',
            action: appConfig.server + '/file/upload',
            headers: {
                // Authorization: 'authorization-text',
                'Content-Type': 'multipart/form-data'
            },
            beforeUpload: file => {
                this.uploadFile(file)
                return false
            },
            onChange(info) {
                if (info.file.status !== 'uploading') {
                    console.log(info.file, info.fileList)
                }
                if (info.file.status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully`
                    )
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }

        return (
            <components.PageContainer title="IWS API Program Generator">
                <CardContainer title="Contract Upload">
                    <DataForm
                        name="contractPath"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                        ref={this.dataFromRef}
                    >
                        <Form.Item>
                            <Upload {...uploadProps}>
                                <Button
                                    style={{
                                        width: 300,
                                        textAlign: 'center'
                                    }}
                                >
                                    <UploadOutlined /> Browse
                                </Button>
                            </Upload>
                        </Form.Item>
                    </DataForm>
                    <Form.Item>
                        <div
                            style={{ width: '100%' }}
                            className="flex-row justify-content-end"
                        >
                            <Button
                                type="primary"
                                htmlType="submit"
                                className="submit-button"
                                onClick={() => this.submit()}
                            >
                                Submit
                            </Button>
                        </div>
                    </Form.Item>
                </CardContainer>
            </components.PageContainer>
        )
    }
    private uploadFile(file) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('functionType', 'IWS')
        this.fileService
            .upload(
                new RequestParams(formData, {
                    header: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
            )
            .subscribe(data => {
                message.success('upload file success!')
                this.setState({
                    contractPath: data.filePath
                })
            })
    }
    private submit() {
        const { contractPath } = this.state
        if (contractPath === '') {
            message.error('Please upload contract.')
        } else {
            this.toolsService
                .iws(
                    new RequestParams({
                        ...this.dataForm.formInstance.getFieldsValue(),
                        contractPath: contractPath
                    })
                )
                .subscribe(
                    data => {
                        this.props.history.push({
                            pathname: '/pages/tools/result-code-generator',
                            state: {
                                result: data,
                                functionType: 'IWS',
                                title: 'IWS API Program Generator',
                                status: true
                            }
                        })
                    },
                    error => {
                        message.error(error.message)
                        if (!isNullOrUndefined(error.resultBody)) {
                            this.props.history.push({
                                pathname: '/pages/tools/result-code-generator',
                                state: {
                                    result: error.resultBody,
                                    functionType: 'IWS',
                                    title: 'IWS API Program Generator',
                                    status: false
                                }
                            })
                        }
                    }
                )
        }
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
}
