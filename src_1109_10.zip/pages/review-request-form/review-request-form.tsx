import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { DownOutlined } from '@ant-design/icons';
import {
    Form,
    Input,
    Select,
    Table,
    Divider,
    Button,
    Avatar,
    Modal,
    List,
    message,
    Steps,
    Typography,
    Popover,
    Collapse   
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { InboxOutlined, UserOutlined,SolutionOutlined, LoadingOutlined, SmileOutlined } from '@ant-design/icons'
import NotificationContainer from '~/shared/components/notification-container'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import { DictUtil } from '~/shared/utils/dict.util'
import Dragger from 'antd/lib/upload/Dragger'
import appConfig from '~/config/app.config'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import ReplyCommont from '~/components/reply-commont'
import { download } from '~/shared/utils/common.util'
import { isNullOrUndefined } from 'util'
import { FormInstance } from 'antd/lib/form'
// import ReopenIcon from '~/assets/svg/Reopen-Approve.svg'
import 'braft-editor/dist/index.css'
import 'braft-extensions/dist/table.css'
import BraftEditor from 'braft-editor'
import BraftEditorTable from 'braft-extensions/dist/table'
import { spawn } from 'child_process'
import { divide } from 'ramda'
BraftEditor.use(BraftEditorTable({
    defaultColumns: 2,
  defaultRows: 3,
  withDropdown: true,
  columnResizable: true,
  exportAttrString: 'border="1" style="border-collapse: collapse"'
}));
const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

const { TextArea } = Input

interface ReviewRequestFormState {
    id: string
    data: any
    dataSource: any[]
    reviewModalVisible: boolean
    successModalVisible: boolean
    applicableChannelsSpecficDisplay: boolean
    applicableCountriesSpecficDisplay: boolean
    applicableGbSpecficDisplay: boolean
    contractInformationStatus: boolean
    commontsTree: any
    show:boolean
    disabledEdit:boolean
    editorState:any
    ReopenIcon:any
    CreateRequest:any
    threeIcon:any
    onestatus:any
    fourIcon:any
    fiveIcon:any
    sixIcon:any
    RejectIcon:any
    InProgresIcon:any
    ApproveIcon:any
    // controlsecd:any[]
}

interface ReviewRequestFormProps {}

export default class ReviewRequestForm extends Component<
    RouteComponentProps<ReviewRequestFormProps>,
    ReviewRequestFormState
> {
    private dataFromRef!: React.RefObject<DataForm>

    private reviewService = new ReviewService()
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private contractInformationFromRef!: React.RefObject<DataForm>
    private reviewType = ''
    private reviewStatus = ''
    private file: File
    private formRef = React.createRef<FormInstance>()

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.actionFromRef = React.createRef()
        this.contractInformationFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            dataSource: [],
            reviewModalVisible: false,
            successModalVisible: false,
            applicableChannelsSpecficDisplay: false,
            applicableCountriesSpecficDisplay: false,
            applicableGbSpecficDisplay: false,
            contractInformationStatus: false,
            commontsTree: [],
            show:false,
            disabledEdit:true,
            onestatus:'wait',
            editorState: BraftEditor.createEditorState(null),
            ReopenIcon: require('~/assets/svg/Reopen-Approve.svg'),
            CreateRequest:require('~/assets/svg/UploadContract-Approve.svg'),
            threeIcon:require('~/assets/svg/AssignReviewer-Reopen.svg'),
            fourIcon:require('~/assets/svg/GTDR-Approve.svg'),
            fiveIcon:require('~/assets/svg/GTDR-Reject.svg'),
            sixIcon:require('~/assets/svg/GTDR-InProgress.svg'),
            RejectIcon:require('~/assets/svg/Reject.svg'),
            InProgresIcon:require('~/assets/svg/InProgress.svg'),
            ApproveIcon:require('~/assets/svg/Approve.svg')
        }
    }

    public componentDidMount() {
        // const htmlContent =await fetchEditorContent()
        const { id } = this.props.location.state as ReviewRequestFormState

        this.getReview()
        this.getComments()
    }
      handleEditorChange = (editorState) => {
          console.log(editorState)
        // const htmlString = editorState.toHTML()
        this.setState({ 
            editorState:editorState
         })
        console.log(this.state.editorState)
      }
    private getReview() {
        const { id } = this.props.location.state as ReviewRequestFormState

        this.reviewService
            .get(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    data: data,
                    dataSource: data.contracts,
                    contractInformationStatus:
                        data.gbdrReviewStatus > 3 ||
                        data.gtdrReviewStatus > 3 ||
                        data.rdrReviewStatus > 3,
                    applicableChannelsSpecficDisplay:
                        data.applicableChannels === '04',
                    applicableCountriesSpecficDisplay:
                        data.applicableGbGF === '04',
                    applicableGbSpecficDisplay:
                        data.applicableCountries === '02' ||
                        data.applicableCountries === '03' ||
                        data.applicableCountries === '04'
                })
                this.contractInformationFrom.formInstance.setFieldsValue(data)
                if(data.gbdrReviewStatus==4||data.gbdrReviewStatus==5){
                    this.setState({
                        disabledEdit: true
                    })
                }else{
                    this.setState({
                        disabledEdit: false
                    })
                }
            })
    }

    private getComments() {
        const { id } = this.props.location.state as ReviewRequestFormState

        this.reviewService
            .comments(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                const action = node => {
                    const children = data.filter(
                        x => x.parentId === node.commentId
                    )
                    console.log(children)
                    node.children = children
                    children.length && children.forEach(action)
                    return node
                }

                const tree = data.filter(x => !x.parentId).map(action)
                this.setState({
                    commontsTree: tree
                })
            })
    }
    private openEdit() {
        const ids  = this.props.location.state as ReviewRequestFormState
        console.log(ids.id)
        this.props.history.push({
            pathname: '/pages/review-request-edit',
            state: {
                id: ids.id
            }
        })
    }
    private openUpdate(){
        const ids  = this.props.location.state as ReviewRequestFormState
        console.log(ids.id)
        this.props.history.push({
            pathname: '/pages/review-request-update',
            state: {
                id: ids.id
            }
        })
    }
    public render() {
        const { data,editorState} = this.state
        return (
            <components.PageContainer title="Review Request Form"  noHeader={true}>
                {/* {this.renderPageHeader()} */}
                <div
                    // className="flex-row justify-content-end"
                    className="flex-row justify-content-between"
                    style={{ paddingTop: 10 }}
                >
                      <div   style={{ fontSize: 28,marginLeft: 20}}>{data.apiName}</div>
                      <div>
                      <Button
                        size="large"
                        onClick={() => {
                            this.props.history.goBack()
                        }}
                    >
                        Back
                    </Button> 
                      </div>
                </div>
                {/* <Divider /> */}
                <CardContainer title="Basic Information">
                <div>
                            <Button
                       type="primary"
                        size="large"
                        style={
                            {
                                position: 'absolute',
                                right: 0,
                                zIndex:99
                            }
                        }
                        onClick={() => {
                            this.openEdit()
                        }}
                    >
                        Edit
                    </Button> 
                        </div>
                    <LabelContainer column={2} labelSpan={3}>
                   
                        <LabelItem label="API Name">
                            <components.AuthDisableButton
                                type="link"
                                className="text-left"
                                style={{ padding: 0 }}
                                onClick={() =>
                                    this.openForm(data.apiCatalogueId)
                                }
                                auth={[
                                    'ROLE_01',
                                    'ROLE_02',
                                    'ROLE_03',
                                    'ROLE_04',
                                    'ROLE_05',
                                    'ROLE_06',
                                    'ROLE_07',
                                    'ROLE_08'
                                ]}
                            >
                                {data?.apiName}
                            </components.AuthDisableButton>
                        </LabelItem>
                        <LabelItem label="Project Name">
                            {data?.projectName}
                        </LabelItem>
                        
                        <LabelItem label="Demand Classfication">
                            {this.dictUtil.filter(
                                'api_classification',
                                data?.demandClassification
                            )}
                        </LabelItem>
                        <LabelItem label="Requester">
                            {data?.requester}
                        </LabelItem>
                        <LabelItem label="Reuse API Version">
                            {data?.reuseApiVersion}
                        </LabelItem>
                         <LabelItem label="Submit Date">
                            {data?.gbdrReviewDate}
                        </LabelItem>
                         <LabelItem label="Original API ID">
                            {data?.originalSapiId}
                        </LabelItem>
                        <LabelItem label="Region">{data?.region}</LabelItem>
                        <LabelItem label="Backend System">
                            {this.dictUtil.filter(
                                'backend_system',
                                data?.backEndSystem
                            )}
                        </LabelItem>
                        <LabelItem label="Country">
                            {data?.country}
                        </LabelItem>
                        <LabelItem label="API ID">{data?.trueSapiId}</LabelItem>
                         <LabelItem label="Multi-Country">
                            {data?.multiCountry}
                        </LabelItem>
                         <LabelItem label="Core Banking API ID">
                         {data?.coreBankingApiId}
                        </LabelItem>
                         

                        <LabelItem label="API Type">
                            {this.dictUtil.filter('api_type', data?.apiType)}
                        </LabelItem>
                        <LabelItem label="API Method">
                            {data?.apiMethod}
                        </LabelItem>
                       
                       
                       
                      
                        <LabelItem label="Capability">
                            {this.dictUtil.filter(
                                'capability',
                                data?.capability
                            )}
                            
                            {/* {data?.capability} */}
                        </LabelItem>
                        <LabelItem label="Platform">
                        {data?.platform}
                        </LabelItem>
                        <LabelItem label="Feature">
                            {this.dictUtil.filter(
                                // 'feature',
                                // data?.feature
                                data?.capability,
                                data?.feature
                            )}
                            {/* {data?.feature} */}
                        </LabelItem>
                        <LabelItem label="Channel Agnostic">
                            {this.dictUtil.filter(
                                'channel_agnostic',
                                data?.channelAgnostic
                            )}
                        </LabelItem>
                        <LabelItem label="Service">
                        {this.dictUtil.filter(
                            //    'service',
                            //     data?.service
                            data?.feature,
                            data?.service
                            )}
                              {/* {data?.service} */}
                        </LabelItem>
                        <LabelItem label="Description">
                            {/* {this.dictUtil.filter(data?.feature, data?.service)}
                             */}
                                {data?.description}
                        </LabelItem>
                        </LabelContainer>
                
                  
                </CardContainer>
                {this.renderContractInformation()}
                {this.StepsContract()} 
                <CardContainer title="Approval Status">
                    {this.renderrdrViewBox()}
                    {this.renderGbdrViewBox()}
                    {this.renderGtdrViewBox()}
                    {this.renderModal()}
                    {this.renderReviewModal()}

                    <Divider dashed />
                    <CardContainer title="Comments">
                        <Consumer of={UserStore}>
                            {userStore => (
                                <Form
                                    name="reply-form"
                                    ref={this.formRef}
                                    onFinish={values =>
                                        this.sumbmitComment(
                                            data,
                                            values,
                                            userStore
                                        )
                                    }
                                >
                                    <div className="flex-row">
                                        <Avatar
                                            style={{
                                                backgroundColor: '#b50015'
                                            }}
                                            icon={<UserOutlined />}
                                        />
                                        <div
                                            style={{
                                                paddingLeft: 30,
                                                width: '100%'
                                            }}
                                        >
                                            <Form.Item
                                                name="comments"
                                                style={{ width: '100%' }}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message:
                                                            'Please Post your Comment here...'
                                                    }
                                                ]}
                                            >
                                                {/* <TextArea
                                                    rows={4}
                                                    style={{
                                                        width: '100%',
                                                        textAlign: 'left'
                                                    }}
                                                    maxLength={4000}
                                                /> */}
                                                {/* <div style={{
                                                    height:240
                                                }}> */}
                                              <BraftEditor

                                                 language='en'
                                                    className="my-editor"
                                                    value={editorState}
                                                    onChange={this.handleEditorChange}
                                                    // onSave={this.submitContent}
                                                    placeholder="Please enter the body content"
                                                />
                                                {/* </div> */}
                                                
                                            </Form.Item>
                                        </div>
                                    </div>
                                    <div className="flex-row justify-content-end">
                                        <div style={{ paddingRight: 20 }}>
                                            <Button
                                                type="primary"
                                                htmlType="submit"
                                                className="submit-button"
                                                danger
                                                size="large"
                                            >
                                                Submit
                                            </Button>
                                        </div>
                                    </div>
                                </Form>
                            )}
                        </Consumer>

                        {this.renderComment()}
                    </CardContainer>
                </CardContainer>
            </components.PageContainer>
        )
    }
    private sumbmitComment(data, values, userStore) {
        let request = {
            commentatorStaffId: userStore.state.staffId,
            comments: this.state.editorState.toHTML(),
            reviewId: data.reviewId
        }
        console.log(this.state.editorState.toHTML())
        this.reviewService
            .comment(new RequestParams(request))
            .subscribe(data => {
                this.getComments()
                message.success('Comment Submitted')
                //this.formRef && this.formRef?.current?.resetFields()
                this.formRef?.current?.resetFields()
            })
    }
    private renderContractInformation() {
        const {
            applicableChannelsSpecficDisplay,
            applicableCountriesSpecficDisplay,
            applicableGbSpecficDisplay,
            contractInformationStatus
        } = this.state

        const testData = {
            reviewId: 1,
            applicableChannels: '1'
        }

        const uploadProps = {
            name: 'file',
            multiple: false,
            action: appConfig.server + '/review/upload',
            data: testData,
            beforeUpload: file => {
                this.file = file
                return false
            },
            onChange(info) {
                const { status } = info.file

                if (status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully.`
                    )
                } else if (status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }
        const columns = [
            {
                title: 'Documents',
                dataIndex: 'contractName',
                render: (text, record) => (
                    <Button
                        type="link"
                        className="text-left"
                        onClick={() => {
                            download(
                                appConfig.server +
                                    '/review/download?fileName=' +
                                    text,
                                text
                            )
                        }}
                    >
                        {text}
                    </Button>
                )
            },
            {
                title: 'Upload Date',
                dataIndex: 'createDate'
            },
            {
                title: 'Upload Person',
                dataIndex: 'accName'
            },
            // {
            //     title: 'Delete ',
            //     render: (text, record) => (
            //         <components.AuthDisableButton
            //             onClick={() => this.deleteContract(record)}
            //             auth={['ROLE_01']}
            //         >
            //             Delete
            //         </components.AuthDisableButton>
            //     )
            // }
        ]
        
        const { dataSource,data,disabledEdit} = this.state
        // console.log(this.contractInformationFromRef)
        return (
            <CardContainer title="Contract Information">
                <div   className="flex-row justify-content-between">
                    <Button
                      disabled={disabledEdit}
                       type="primary"
                        size="large"
                        style={
                            {
                                position: 'absolute',
                                right: 0,
                                zIndex:99
                            }
                        }
                        onClick={() => {
                            this.openUpdate()
                        }}
                    >
                        Edit
                    </Button>
                </div>
                   
                <LabelContainer column={2} labelSpan={3}>
                      <LabelItem label="API Version">
                          {data.version}
                        </LabelItem>
                        <LabelItem label="Applicable Channels">
                         {this.dictUtil.filter(
                                'applicable_channels',
                                data?.applicableChannels
                            )}{data?.applicableChannels2!=null && data?.applicableChannels2!='' && ' - '  +  data?.applicableChannels2}
                        </LabelItem>
                        <LabelItem label="Applicable GB/GF">
                        {this.dictUtil.filter(
                                'applicable_gb',
                                data?.applicableGbGf
                            )}{data?.applicableGbGf2!=null && data?.applicableGbGf2!=''&&  ' - ' + data?.applicableGbGF2}
                        </LabelItem>
                        <LabelItem label="Applicable Countries">
                        {this.dictUtil.filter(
                                'applicable_countries',
                                data?.applicableCountries
                            )}{data?.applicableCountries2!=null && data?.applicableCountries2!=''&& ' - ' + data?.applicableCountries2}
                        </LabelItem>
                        <LabelItem label="Reusability Score">
                        {/* {data.reusabilityScore} */}
                        {this.dictUtil.filter(
                                'reusability_score',
                                data?.reusabilityScore
                            )}
                        </LabelItem>
                </LabelContainer>
                <DataForm
                    name="contractInformationFrom"
                    ref={this.contractInformationFromRef}
                    column={2}
                    labelCol={{ span: 8 }}
                    labelAlign="left"
                >
                    {/* <DataForm.Item name="version" label="API Version">
                        <Input disabled={contractInformationStatus} />
                    </DataForm.Item> */}
                    {/* <DataForm.Item
                        name="applicableChannels"
                        label="Applicable Channels"
                    >
                        <Select
                            onChange={value => {
                                if (value === '04') {
                                    this.setState({
                                        applicableChannelsSpecficDisplay: true
                                    })
                                } else {
                                    this.setState({
                                        applicableChannelsSpecficDisplay: false
                                    })
                                }
                            }}
                            disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts(
                                'applicable_channels',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item> */}
                    {/* <DataForm.Item name="applicableGb" label="Applicable GB/GF">
                        <Select
                            onChange={value => {
                                if (value === '04') {
                                    this.setState({
                                        applicableGbSpecficDisplay: true
                                    })
                                } else {
                                    this.setState({
                                        applicableGbSpecficDisplay: false
                                    })
                                }
                            }}
                            disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts('applicable_gb', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item> */}
                    {/* <DataForm.Item
                        name="applicableCountries"
                        label="Applicable Countries"
                    >
                        <Select
                            onChange={value => {
                                if (
                                    value === '02' ||
                                    value === '03' ||
                                    value === '04'
                                ) {
                                    this.setState({
                                        applicableCountriesSpecficDisplay: true
                                    })
                                } else {
                                    this.setState({
                                        applicableCountriesSpecficDisplay: false
                                    })
                                }
                            }}
                            disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts(
                                'applicable_countries',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item> */}
                    {/* <DataForm.Item
                        name="reusabilityScore"
                        label="Reusability Score"
                    >
                        <Select disabled={contractInformationStatus}>
                            {this.dictUtil.dicts('reusability_score', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item> */}
                    {/* <DataForm.Item name="commentDesc" label="Contract Comment">
                        <Input disabled={contractInformationStatus} />
                    </DataForm.Item> */}
                </DataForm>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    size="small"
                    rowKey="contractId"
                    pagination={false}
                />
                {/* <Dragger
                    {...uploadProps}
                    style={styles().input(!contractInformationStatus)}
                >
                    <p className="ant-upload-drag-icon">
                        <InboxOutlined />
                    </p>
                    <p className="ant-upload-text">
                        Click or drag file to this area to upload
                    </p>
                    <p className="ant-upload-hint">
                        Support for a single or bulk upload. Strictly prohibit
                        from uploading company data or other band files
                    </p>
                </Dragger> */}
                {/* <div className="flex-row justify-content-end padding-y">
                    <components.AuthDisableButton
                        type="primary"
                        htmlType="submit"
                        className="submit-button"
                        size="large"
                        style={styles().input(!contractInformationStatus)}
                        onClick={() => {
                            console.log(this.file)
                            if (isNullOrUndefined(this.file)) {
                                message.error(
                                    'Please upload contract before you submit.'
                                )
                                return
                            }
                            const formData = new FormData()
                            formData.append('file', this.file)
                            formData.append(
                                'reviewId',
                                this.state.data.reviewId === null
                                    ? ''
                                    : this.state.data.reviewId
                            )
                            formData.append(
                                'versionId',
                                this.state.data.versionId === null
                                    ? ''
                                    : this.state.data.versionId
                            )
                            const data = this.contractInformationFrom.formInstance.getFieldsValue()
                            Object.entries(
                                data
                            ).forEach(([key, value]: [string, any]) =>
                                formData.append(key, value || '')
                            )
                            console.log(formData.forEach(console.log))
                            const STORAGE_KEY = 'react-storage'
                            const storageData = JSON.parse(
                                localStorage.getItem(STORAGE_KEY) || '{}'
                            )
                            this.reviewService
                                .upload(
                                    new RequestParams(formData, {
                                        header: {
                                            'Content-Type':
                                                'multipart/form-data',
                                            Authorization:
                                                storageData.user.token
                                        }
                                    })
                                )
                                .subscribe(
                                    () => {
                                        this.openSuccessModal()
                                    },
                                    () => {}
                                )
                        }}
                        auth={['ROLE_01']}
                    >
                        Submit
                    </components.AuthDisableButton>
                </div> */}
            </CardContainer>
        )
    }
    private StepsContract(){
        const { Step } = Steps;
        const { Title } = Typography;
        const { ReopenIcon, CreateRequest,onestatus,threeIcon,fourIcon,fiveIcon,sixIcon,RejectIcon,ApproveIcon, InProgresIcon} = this.state
        const { Panel } = Collapse;
        const customDot = (dot, { status, index }) => (
            <Popover
              content={
                <span>
                  step {index} status: {status}
                </span>
              }
            >
                   <img src={ReopenIcon}/>
              
            </Popover>
          );
        return (
              <CardContainer title="Review Process">
                   <Title level={4}>Current Process</Title>
                   <div className='oneSteps'>
                       <Steps   style={{marginTop:20,width:'100%'}} >
                        <Step  status={onestatus} style={{color:'#333'}} icon={<img style={{width:50,height:50}} src={ReopenIcon}/>}  title="Reopen"  description="Jenny Wilson 20/10/2020"/>
                        <Step  status="process" style={{color:'#00847F'}}   title="Submit Contract" icon={<img style={{width:50,height:50}} src={CreateRequest}/>} description="Floyd Miles  20/10/2020"/>
                        <Step  status="finish"  title="Assign Reviewer" icon={<img style={{width:50,height:50}} src={threeIcon}/>}/>
                        <Step  status="process"  title="RDR"  icon={<img style={{width:50,height:50}} src={fourIcon}/>} description="Cody Fisger  20/10/2020"/>
                        <Step  status="error"  title="GBDR"icon={<img style={{width:50,height:50}} src={fiveIcon}/>} description="Wade  Warrount  20/10/2020"/>
                        <Step  status="finish"   title="GTDR"  icon={<img style={{width:50,height:50}} src={sixIcon}/>}/>
                    </Steps> 
                   </div>
                   <Divider />
                    <Collapse style={{marginTop:20}} ghost>
                    <Panel header="History Process" key="1">
                            <div className='twoSteps'>
                            <Steps>
                                        <Step icon={<img style={{width:25,height:25}} src={ApproveIcon}/>} status="process" title="Creact Request" description="Jennifer Lei" />
                                        <Step icon={<img style={{width:25,height:25}} src={ApproveIcon}/>} status="process" title="Submit Contract" description="Floyd Miles" />
                                        <Step icon={<img style={{width:25,height:25}} src={ApproveIcon}/>} status="process" title="Assign Reviewer" description="Floyd Miles" />
                                        <Step icon={<img style={{width:25,height:25}} src={RejectIcon}/>}  status="error" title="RDR" description="Floyd Miles" />
                                        <Step icon={<img style={{width:25,height:25}} src={InProgresIcon}/>}status="finish" title="GBDR" description="Cody Fisger" />
                                        <Step icon={<img style={{width:25,height:25}} src={InProgresIcon}/>}status="finish" title="GTDR" description="Wade  Warrount" />
                            </Steps>
                            </div>
                    </Panel>
                    </Collapse> 

            </CardContainer>  
        )
       
    }
    private deleteContract(record) {
        this.reviewService
            .deleteContract(
                new RequestParams({}, { append: [record.contractId] })
            )
            .subscribe(data => {
                message.success('contract delete success')

                this.getReview()
            })
    }
    private renderComment() {
        const { commontsTree } = this.state

        return (
            <List
                className="comment-list"
                header={`${commontsTree.length} replies`}
                itemLayout="horizontal"
                dataSource={commontsTree}
                renderItem={(item: any) => (  
                    <li  key={item.commentId}>
                        {this.renderCommontItem(item)}
                        </li>
                )}
                
            />
        )
    }
    private renderCommontItem(item) {
        const data = item.children
        return (
            <ReplyCommont
                item={item}
                onSubmit={() => {
                    this.getComments()
                }}
            >
                {data &&
                    data.map(m => {
                        console.log(m)
                        return (
                            <div key={m.commentId}>
                                {m && this.renderCommontItem(m)}
                            </div>
                        )
                    })}
            </ReplyCommont>
        )
    }

    private renderrdrViewBox() {
        const { data } = this.state
        const { rdrReviewStatus } = data
        switch (rdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="approved"
                        status={rdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.rdrReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.rdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.rdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="rejected"
                        status={rdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.rdrReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.rdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.rdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="verify"
                        status={rdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_03']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_03']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="inProgress"
                        status={rdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderGbdrViewBox() {
        const { data } = this.state
        const { gbdrReviewStatus } = data
        // console.log(gbdrReviewStatus)
        switch (gbdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="approved"
                        status={gbdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gbdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gbdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gbdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gbdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="rejected"
                        status={gbdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gbdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gbdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gbdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gbdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="verify"
                        status={gbdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_04', 'ROLE_05']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_04', 'ROLE_05']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="inProgress"
                        status={gbdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderGtdrViewBox() {
        const { data } = this.state
        const { gtdrReviewStatus } = data
        switch (gtdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="approved"
                        status={gtdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gtdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gtdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gtdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gtdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="rejected"
                        status={gtdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gtdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gtdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gtdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gtdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="verify"
                        status={gtdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_06', 'ROLE_07']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_06', 'ROLE_07']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="inProgress"
                        status={gtdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }

    private renderReviewModal() {
        let strroletype = ''
        if (this.reviewType === 'RDR') {
            strroletype = 'Regional Review Group'
        }
        if (this.reviewType === 'GBDR') {
            strroletype = 'Global Business Design Group'
        }
        if (this.reviewType === 'GTDR') {
            strroletype = 'Global Technical Design Group'
        }
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {/* {(this.staffId = userStore.state.staffId)} */}
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        {strroletype}
                                    </LabelItem>
                                </LabelContainer>
                                {/*  <DataForm.Item label="Team">
                                    {userStore.state.roleList.map(
                                        val => val.authority + ' '
                                    )}
                                </DataForm.Item> */}
                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private submitAction(staffId) {
        const { data } = this.state
        this.actionForm.formInstance.validateFields().then((...data1) => {
            this.reviewService
                .status(
                    new RequestParams({
                        reviewId: [data.reviewId],
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        reviewStatus: this.reviewStatus,
                        reviewType: this.reviewType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }

    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Review Detail -->"
                cancelText="Close"
                content="Check Status in Review List."
                onOk={() => {
                    this.getReview()
                    this.closeSuccessModal()
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private openReviewModal() {
        this.setState({
            reviewModalVisible: true
        })
    }
    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private get contractInformationFrom(): DataForm {
        return this.contractInformationFromRef.current as DataForm
    }

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Customer Address Creation
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                id: apiCatalogueId
            }
        })
    }
}
