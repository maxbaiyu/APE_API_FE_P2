import React from 'react'
import styled from 'styled-components'
import { Comment, Form, Input, Button, Avatar, Tooltip } from 'antd'
import { UserOutlined } from '@ant-design/icons'
import moment from 'moment'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { FormInstance } from 'antd/lib/form'

const components = {
    Wrapper: styled.section`
        width: 100%;
    `
}

interface ComponentProp {
    item: any
    onSubmit?: Function
}
interface ComponentState {
    display: boolean
}

export default class ReplyCommont extends React.Component<
    ComponentProp,
    ComponentState
> {
    private reviewService = new ReviewService()
    private formRef = React.createRef<FormInstance>()

    constructor(props) {
        super(props)

        this.state = {
            display: false
        }
    }
    public render() {
        const { display } = this.state
        const item = this.props.item
        return (
            <components.Wrapper>
                <Comment
                    actions={[
                        <span
                            key="comment-list-reply-to-0"
                            onClick={() => {
                                this.setState({
                                    display: true
                                })
                            }}
                        >
                            Reply to
                        </span>
                    ]}
                    author={item.commentator}
                    // dangerouslySetInnerHTML={{__html:item.comments}}
                    avatar={
                        <Avatar
                            style={{ backgroundColor: '#b50015' }}
                            icon={<UserOutlined />}
                        />
                    }
                    // content={item.comments}
                    content={<div dangerouslySetInnerHTML={{__html:item.comments}}/>}
                    datetime={
                        <Tooltip
                            title={moment(
                                item.createTime,
                                'MM/DD/YYYY HH:mm:ss'
                            ).format('MM/DD/YYYY HH:mm:ss')}
                        >
                            <span>{moment().from(item.createTime)}</span>
                        </Tooltip>
                    }
                >
                    <Consumer of={UserStore}>
                        {userStore => (
                            <Form
                                name="reply-form"
                                ref={this.formRef}
                                onFinish={values =>
                                    this.sumbmitReply(values, userStore, item)
                                }
                            >
                                {display && (
                                    <div className="flex-row">
                                        <Form.Item
                                            name="comments"
                                            style={{ width: '60%' }}
                                            rules={[
                                                {
                                                    required: true,
                                                    message:
                                                        'Post your Comment here...'
                                                }
                                            ]}
                                        >
                                            <Input
                                                maxLength={4000}
                                                style={{
                                                    textAlign: 'left'
                                                }}
                                            />
                                        </Form.Item>
                                        <Button
                                            type="primary"
                                            htmlType="submit"
                                        >
                                            Submit
                                        </Button>
                                    </div>
                                )}
                            </Form>
                        )}
                    </Consumer>
                    {this.props.children}
                </Comment>
            </components.Wrapper>
        )
    }
    private sumbmitReply(values, userStore, item) {
        let request = {
            commentatorStaffId: userStore.state.staffId,
            comments: values.comments,
            parentId: item.commentId,
            reviewId: item.reviewId
        }
        this.reviewService
            .comment(new RequestParams(request))
            .subscribe(data => {
                this.setState({
                    display: false
                })
                console.log(data)
                const { onSubmit } = this.props
                onSubmit && onSubmit()
                //this.formRef && this.formRef?.current?.resetFields()
                this.formRef?.current?.resetFields()
            })
    }
}
