import { ExtendService, RequestParams } from '~/core/http'

/**
 * page service
 */
export class PageService extends ExtendService {
    // default page config
    public default = {
        pageSize: 10,
        pageIndex: 1,
        total: 0,
        pageSizeOpts: ['10', '20', '50', '100']
    }

    // current page config
    public pageSize: number
    public pageIndex: number
    public total: number
    public pageSizeOpts: string[]

    constructor(data?: any) {
        super()

        // set page config
        if (data) this.default = { ...this.default, ...data }

        this.pageSize = this.default.pageSize
        this.pageIndex = this.default.pageIndex || 1
        this.total = this.default.total
        this.pageSizeOpts = this.default.pageSizeOpts
    }

    /**
     * page complete status
     */
    public get finished() {
        return this.total > 0 && this.total <= this.pageIndex * this.pageSize
    }

    /**
     * before page
     */
    public before = params => {
        params.data = {
            ...params.data,
            size: this.pageSize,
            page: this.pageIndex
        }
    }

    /**
     * after page
     */
    public after = (data: any, params) => {
        this.total = data.totalElements
        return {
            override: true,
            data: data.content
        }
    }

    /**
     * 重置分页信息
     */
    public reset() {
        this.pageIndex = this.default.pageIndex
        this.pageSize = this.default.pageSize
        this.total = 0
    }

    /**
     * 分页前进操作
     * @param callback
     */
    public next(callback) {
        if (!this.finished) {
            this.pageIndex++
            callback()
        }
    }

    /**
     * 更新分页配置
     * @param pageIndex
     * @param pageSize
     */
    public update(pageIndex, pageSize) {
        this.pageIndex = pageIndex
        this.pageSize = pageSize
        return Promise.resolve()
    }
}
