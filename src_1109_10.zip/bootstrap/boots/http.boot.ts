import { RequestService } from '~/core/http'
import appConfig from '~/config/app.config'
import * as R from 'ramda'
import { message } from 'antd'
import { TokenService } from '../services/token.service'

export default async function () {
    // config http sever infos
    RequestService.setConfig({
        server: appConfig.server,
        timeout: appConfig.timeout
    })

    // status interceptor
    RequestService.interceptors.status.use(respone => {
        return respone.data.status === 200
    })

    // success interceptor
    RequestService.interceptors.success.use(respone => {
        return respone.data.resultBody
    })

    RequestService.requestCatchHandle = R.pipe(
        R.path<string>(['data', 'message']),
        R.defaultTo<string>('The Request Interface Response Error'),
        message.error
    )

    RequestService.installExtendService(new TokenService())
}
