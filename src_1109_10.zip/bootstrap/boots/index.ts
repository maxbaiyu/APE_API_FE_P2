import httpBoot from './http.boot'
import launchBoot from './launch.boot'

export default async function () {
    await httpBoot()
    await launchBoot()
}
