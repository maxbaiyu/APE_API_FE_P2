/**
 *  API Catalogue Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { ApiController } from '~/config/services/api.controller'

export class ApiService {
    /**
     * update apiCatalogue
     */
    @Request({
        server: ApiController.cataloguePut
    })
    public update(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    /**
     * all
     */
    @Request({
        server: ApiController.catalogueAll
    })
    public catalogueAll(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get ApiList By ApiName
     */
    @Request({
        server: ApiController.catalogueApiList
    })
    public getApiListByName(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * check api submit
     */
    @Request({
        server: ApiController.catalogueChecking
    })
    public checking(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * update apiCatalogue version
     */
    @Request({
        server: ApiController.catalogueVersionPut
    })
    public updateVersion(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get apiCatalogue version detail
     */
    @Request({
        server: ApiController.catalogueVersionGet
    })
    public getVersionById(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get apiCatalogue detail
     */
    @Request({
        server: ApiController.catalogueGetById
    })
    public getById(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: ApiController.service
    })
    public service(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
