/**
 * Demand Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { DemandController } from '~/config/services/demand.controller'

export class DemandService {
    /**
     * create demand
     */
    @Request({
        server: DemandController.post
    })
    public post(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * update demand
     */
    @Request({
        server: DemandController.put
    })
    public put(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * all
     */
    @Request({
        server: DemandController.all
    })
    public all(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    /**
     * demand approve
     */
    @Request({
        server: DemandController.status
    })
    public status(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get demand detail
     */
    @Request({
        server: DemandController.get
    })
    public get(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
