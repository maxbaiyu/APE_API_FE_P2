/**
 * Login Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { AuthController } from '~/config/services/auth.controller'

export class AuthService {
    /**
     * login
     */
    @Request({
        server: AuthController.login
    })
    public login(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
