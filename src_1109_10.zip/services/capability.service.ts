/**
 * Review Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { CapabilityController } from '~/config/services/capability.catalogue';

export class CapabilityService {
    
    @Request({
        server: CapabilityController.service
    })
    public service(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: CapabilityController.details
    })
    public details(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
