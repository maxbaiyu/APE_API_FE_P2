import DefaultLayout from '~/layout/default/default.layout'
import WorkspaceLayout from '~/layout/workspace/workspace.layout'

import Login from '~/pages/login/login'
import APIDemandRequestList from '~/pages/api-demand-request-list/api-demand-request-list'
import APIDemandEdit from '~/pages/api-demand-request-list/api-demand-edit'
import APIReviewRequestList from '~/pages/api-review-request-list/api-review-request-list'
import ReviewRequestForm from '~/pages/review-request-form/review-request-form'
import ReviewRequestEdit from '~/pages/review-request-form/review-request-edit'
import ReviewRequestUpdate from '~/pages/review-request-form/review-request-update'
import DemandRequestFormDetail from '~/pages/demand-request-form/demand-request-form-detail'
import DemandRequestFormDetailTWO from '~/pages/demand-request-form/demand-request-form-exhibition'
import APICatalogueList from '~/pages/api-catalogue-list/api-catalogue-list'
import ApiDetail from '~/pages/api-catalogue-list/api-detail'
import ApiDetailForm from '~/pages/api-catalogue-list/api-detail-form'
import ApiDetailVersionForm from '~/pages/api-catalogue-list/api-detail-version-form'
import UserProfile from '~/pages/user-profile/user-profile'
import iwscodegenertor from '~/pages/tools/iws-code-generator'
import ramlgenertor from '~/pages/tools/raml-generator'
import mulegenertor from '~/pages/tools/mule-code-generator'
import AccountAuthority from '~/pages/account-authority/account-authority'
import DemandStepForm from '~/pages/demand-request-form/demand-step-form'
import HomePage from '~/pages/home-page/home-page'
import ResultGenerator from '~/pages/tools/result-code-generator'
import Dashboard from '~/pages/dashboard/dashboard'
import CapabilityCatalogue from '~/pages/capability-catalogue/capability-catalogue';
import APIReviewTaskAssignment from '~/pages/api-review-task-assignment/api-review-task-assignment';
import DemandRequestFormByProject from '~/pages/demand-request-form-by-project';
import UserCenter from '~/pages/user-center';

export const routes = [
    { path: '/', exact: true, redirect: '/login' },
    {
        path: '/login',
        exact: true,
        component: Login,
        layout: DefaultLayout,
        auth: false
    },
    {
        path: '/dashboard',
        exact: true,
        component: Dashboard,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-demand-request-list',
        exact: true,
        component: APIDemandRequestList,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-demand-edit',
        exact: true,
        component: APIDemandEdit,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/demand-request-form',
        exact: true,
        component: DemandStepForm,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-review-request-list',
        exact: true,
        component: APIReviewRequestList,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/review-request-form',
        exact: true,
        component: ReviewRequestForm,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/review-request-edit',
        exact: true,
        component: ReviewRequestEdit,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/review-request-update',
        exact: true,
        component: ReviewRequestUpdate,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/demand-request-form-detail',
        exact: true,
        component: DemandRequestFormDetail,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/demand-request-form-exhibition',
        exact: true,
        component: DemandRequestFormDetailTWO,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-catalogue',
        exact: true,
        component: APICatalogueList,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-catalogue/api-detail',
        exact: true,
        component: ApiDetail,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-catalogue/api-detail-form',
        exact: true,
        component: ApiDetailForm,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-catalogue/api-detail-version-form',
        exact: true,
        component: ApiDetailVersionForm,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/user-profile',
        exact: true,
        component: UserProfile,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/account-authotiry',
        exact: true,
        component: AccountAuthority,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/tools/iws-code-generator',
        exact: true,
        component: iwscodegenertor,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/tools/raml-generator',
        exact: true,
        component: ramlgenertor,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/tools/mule-code-generator',
        exact: true,
        component: mulegenertor,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/home-page',
        exact: true,
        component: HomePage,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/tools/result-code-generator',
        exact: true,
        component: ResultGenerator,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/capability-catalogue',
        exact: true,
        component: CapabilityCatalogue,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/api-review-task-assignment',
        exact: true,
        component: APIReviewTaskAssignment,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/demand-request-form-by-project',
        exact: true,
        component: DemandRequestFormByProject,
        layout: WorkspaceLayout,
        auth: true
    },
    {
        path: '/pages/user-center',
        exact: true,
        component: UserCenter,
        layout: WorkspaceLayout,
        auth: true
    },
]
