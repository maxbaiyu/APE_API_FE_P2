/**
 * File service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { FileController } from '~/config/services/file.controller'

export class FileService {
    /**
     * download file
     */
    @Request({
        server: FileController.download
    })
    public download(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * upload file
     */
    @Request({
        server: FileController.upload
    })
    public upload(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: FileController.demand
    })
    public demand(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

}
