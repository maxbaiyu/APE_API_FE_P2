/**
 * date format
 * @param date
 * @param fmt date format pattern
 */
import axios from 'axios'
export function dateFormat(date, fmt = 'yyyy-MM-dd'): string {
    // null data return
    if (date === null || date === undefined || date === '') {
        return ''
    }

    // long timestapm ,convert to Date
    if (typeof date === 'number') {
        date = new Date(date)
    }

    let o = {
        'M+': date.getMonth() + 1, // Moneth
        'd+': date.getDate(), // date
        'h+': date.getHours(), // hour
        'm+': date.getMinutes(), // minute
        's+': date.getSeconds(), // second
        'q+': Math.floor((date.getMonth() + 3) / 3), // quarter
        S: date.getMilliseconds() // millisecond
    }

    if (/(y+)/.test(fmt))
        fmt = fmt.replace(
            RegExp.$1,
            (date.getFullYear() + '').substr(4 - RegExp.$1.length)
        )

    for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt))
            fmt = fmt.replace(
                RegExp.$1,
                RegExp.$1.length === 1
                    ? o[k]
                    : ('00' + o[k]).substr(('' + o[k]).length)
            )
    }
    return fmt
}

export function download(url, name,query) {
    const STORAGE_KEY = 'react-storage'
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')
    name = name || url
    for (let item in query) {
        if(query[item] == ''){
            delete query[item]
        }
      }    
   axios.defaults.headers.common['Authorization'] = data.user.token
    axios({
        url: encodeURI(url),
        method: 'get',
        responseType: 'blob',
        params: query,
        timeout: 5000,
    })
        .then(resp => {
            if (window.navigator.msSaveOrOpenBlob) {
                // 兼容ie11
                try {
                    window.navigator.msSaveOrOpenBlob(new Blob([resp.data]), name);
                } catch (e) {
                    console.log(e);
                }
            } else {
            var blob = new Blob([resp.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8' })
            var downloadElement = document.createElement('a');
            var href = window.URL.createObjectURL(blob); // 创建下载的链接
            downloadElement.href = href;
            downloadElement.download =  name; // 下载后文件名
            document.body.appendChild(downloadElement);
            downloadElement.click(); // 点击下载
            document.body.removeChild(downloadElement); // 下载完成移除元素
            window.URL.revokeObjectURL(href); // 释放掉blob对象
            }
        })
        // .then(data => {
        //     downloadFile(name, data)

        // })
        .catch(error => {
        })
}