import moment from 'moment';

const RANGE_FORMAT = 'YYYY-MM-DD';
const DATE_FORMAT = 'MM/DD/YYYY';

export const dataConvert = (isShow, datas) => {
    // 遍历，当为日期组件时，需转换格式
    for (let key in datas) {
        if (key == 'apiLifecycleStage') {
            continue;
        }
        const item = datas[key];
        if (isShow) {
            if (Array.isArray(item) && item.length && isNaN(item[0]) && !isNaN(Date.parse(item[0]))) {
                // range picker
                const [startDate, endDate] = item;
                datas[key] = [moment(startDate, RANGE_FORMAT), moment(endDate, RANGE_FORMAT)]
            } else if (isNaN(item) && !isNaN(Date.parse(item))) {
                // data picker
                datas[key] = moment(item, DATE_FORMAT);
            }

        } else {
            // save
            if (Array.isArray(item) && item.length && moment(item[0]).isValid()) {
                const [startDate, endDate] = item;
                datas[key] = [startDate.format(RANGE_FORMAT), endDate.format(RANGE_FORMAT)];
            } else if (typeof item === 'object' && moment(item).isValid()) {
                datas[key] = item.format(DATE_FORMAT);
            }
        }
    }
    return datas;
};