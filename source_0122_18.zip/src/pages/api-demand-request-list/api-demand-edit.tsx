import React, { Component, ReactNode } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import DataTable from '~/shared/components/data-table'
import Column from 'antd/lib/table/Column'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import LabelItem from '~/shared/components/label-item'
import {
    Modal,
    Form,
    Input,
    Select,
    DatePicker,
    Button,
    Divider,
    message,
    Spin,
    Popover
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import ColumnGroup from 'antd/lib/table/ColumnGroup'
import { PageService } from '~/bootstrap/services/page.service'
import { DictUtil } from '~/shared/utils/dict.util'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { DemandService } from '~/services/demand.service'
import { RequestParams } from '~/core/http'
import CustomizeModal from '~/shared/components/customize-modal'
import moment from 'moment';
import {
    apiReviewDemandListHeader,
    APIReviewDemandListColumnProps
} from './data';
import {
    apiReviewDemandListHeaderGove,
    APIReviewDemandListColumnPropsGove
} from './dateGovernance ';
import Item from 'antd/lib/list/Item'
import { add, values } from 'ramda'
const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}
interface APIDemandEditState {
    dataSource: any[]
    selectedRowKeys: any[]
    selectedRows: string
    countryData: any[]
    FeatureData: any[]
    ServiceData: any[]
    selecteData: any
    disabledStues: boolean
    Loading: boolean
    selectobejct: {
        DemandClassificationData: any[]
        regionData: any[]
        backendsystemData: any[]
        channelData: any[]
        apicontactData: any[]
        systemcontactData: any[]
        BankingData:any
        GBGFData: any[]
        lifecycleData: any[]
        PlatformData: any[]
        apitypeData: any[]
        channelAgnosticData: any[]
        reusabilityscoreData: any[]
    }
    fieldsValues: any
    pathName: string
    dateFormat: any
    disabledReviewStues: boolean
    successModalVisible: boolean
    reviewModalVisible: boolean
}

interface APIDemandEditProps { }

interface selenData {
    DemandClassificationData: any
    regionData: any
    backendsystemData: any
    channelData: any
    apicontactData: any
    systemcontactData: any
    BankingData:any
    GBGFData: any
    lifecycleData: any
    PlatformData: any
    apitypeData: any
    channelAgnosticData: any
    reusabilityscoreData: any
}

export default class APIDemandEdit extends Component<
    RouteComponentProps<APIDemandEditProps>,
    APIDemandEditState
    > {
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private demandService = new DemandService()
    private pageService = new PageService()
    private selectDatas: selenData;
    private searchFormRef!: React.RefObject<DataForm>
    // private commontFormRef!: React.RefObject<Form>

    constructor(props) {
        super(props)
        this.actionFromRef = React.createRef()
        this.searchFormRef = React.createRef()
        // this.commontFormRef = React.createRef()
        this.selectDatas = {
            DemandClassificationData: [],
            regionData: [],
            backendsystemData: [],
            channelData: [],
            apicontactData: [],
            systemcontactData: [],
            BankingData:[],
            GBGFData: [],
            lifecycleData: [],
            PlatformData: [],
            apitypeData: [],
            channelAgnosticData: [],
            reusabilityscoreData: []
        };
        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            selectedRows: '',
            selecteData: {},
            countryData: [],
            FeatureData: [],
            ServiceData: [],
            disabledStues: false,
            disabledReviewStues: false,
            successModalVisible: false,
            reviewModalVisible: false,
            Loading: true,
            dateFormat: 'MM/DD/yyyy',
            fieldsValues: {},
            pathName: '',
            selectobejct: {
                DemandClassificationData: [],
                regionData: [],
                backendsystemData: [],
                channelData: [],
                apicontactData: [],
                systemcontactData: [],
                BankingData:[],
                GBGFData: [],
                lifecycleData: [],
                PlatformData: [],
                apitypeData: [],
                channelAgnosticData: [],
                reusabilityscoreData: []
            }

        }
    }

    public componentDidMount() {
        const { selectedRows } = this.props.location.state as APIDemandEditState
        const selectedRowsArr = JSON.parse(selectedRows);
        selectedRowsArr.map(item => {
                if(item.demandClassification>2){
                    item.apinameStues=true
                }else if(item.demandStatus>3){
                    item.apinameStues=true
                }else{
                    item.apinameStues=false
                }
            if (item.demandStatus > 3) {
                 item.disabledStues=true
            }else{
                 item.disabledStues=false
            }
            if(item.reviewStatusFlag=='N'){
                item.disabledReviewStues=true
            }else if (item.designReviewStatus > 3 || item.designStatus> 3) {
                 item.disabledReviewStues=true
            }else{
                 item.disabledReviewStues=false
            }
        })
        this.setState((pvevState)=>({
            dataSource: selectedRowsArr,
        }))
        this.selectData()
    }
    private selectData() {
        {
            this.dictUtil.dicts('region', dict => {
                this.selectDatas.regionData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('platform', dict => {
                this.selectDatas.PlatformData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('backend_system', dict => {
                this.selectDatas.backendsystemData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('channel', dict => {
                this.selectDatas.channelData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('cb_api_contact', dict => {
                this.selectDatas.apicontactData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('api_lifecycle_stage', dict => {
                this.selectDatas.systemcontactData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('cb_system_contact', dict => {
                this.selectDatas.BankingData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('gb_gf', dict => {
                this.selectDatas.GBGFData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }

        {
            this.dictUtil.dicts('api_type', dict => {
                this.selectDatas.apitypeData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('channel_agnostic', dict => {
                this.selectDatas.channelAgnosticData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        {
            this.dictUtil.dicts('reusability_score', dict => {
                this.selectDatas.reusabilityscoreData.push(
                    <Select.Option
                        key={dict.dirCode}
                        value={dict.dirCode}
                    >
                        {dict.dirName}
                    </Select.Option>
                )
            })
        }
        this.setState({
            selectobejct: this.selectDatas,
            // Loading:false
        }, () => {
            this.setState({
                Loading: false,
            })
        })
        // this.mesgData()
        // this.state.selectobejct=this.a
    }
    private limitDecimals(value){
        if (typeof value === 'string') {
            return  value.replace(/[^\w\s-\0-9]/g,'') 
        } else {
            return ''
        }
    }
    private limitBPid(value){
        if (typeof value === 'string') {
            return  value.replace(/[^0-9]/g,'') 
        } else {
            return ''
        }
    }
    private limitEstimates(value):any{
        if (typeof value === 'string') {
            return !isNaN(Number(value)) && Number(value) > 100 ? '100'  : value
        }
    }
    public getExpandTableTitle = () => {
        const { disabledStues } = this.state
        const serviceTableColumn = apiReviewDemandListHeader.map(item => {
            const {
                title,
                dataIndex,
                key,
                isSelect,
                Selectvalue
            } = item;
            const renderProps: APIReviewDemandListColumnProps = {
                title
            };

            renderProps.render = (element, record) => {
                if (title == 'Region') {
                    return (
                        <Select
                            disabled={record.disabledStues}
                            style={{width:150}}
                            value={record[dataIndex]}
                            onChange={(value, row: any) => {
                                record.country=''
                                const countryData = this.dictUtil.dicts(value)
                                this.setState({
                                    countryData: countryData
                                })
                                record[dataIndex] = value;
                                this.forceUpdate()
                            }}
                        >
                            {this.dictUtil.dicts(Selectvalue, dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    )
                }
                if (title == 'Site') {
                    const countryData = this.dictUtil.dicts(record.region)
                    return (
                        <Select
                           disabled={record.disabledStues}
                           style={{width:100}}
                            value={record[dataIndex]}
                            onChange={value => {
                                record[dataIndex] = value;
                                this.forceUpdate()
                            }}
                        >
                            {countryData.map(x => (
                                <Select.Option
                                    key={x.dirCode}
                                    value={x.dirCode}
                                >
                                    {x.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    )
                }
            }
            return <Column ellipsis={true} dataIndex={dataIndex} key={key} {...renderProps} />;
        })
        return (<>{serviceTableColumn}</>);
    }
    public getExpandTableTitleGove = () => {
        const { disabledReviewStues } = this.state
        const serviceTableColumnGove = apiReviewDemandListHeaderGove.map(item => {
            const {
                title,
                dataIndex,
                key,
                detaSelect,
                inputSelect,
                isSelect,
                disabled,
                Selectvalue
            } = item;
            const renderProps: APIReviewDemandListColumnPropsGove = {
                title
            };
            if (isSelect) {
                renderProps.render = (element, record) => {
                    if (title == 'Capability') {
                        return (
                            <Select style={{width:250}}
                                disabled={record.disabledReviewStues}
                                value={record[dataIndex]}
                                onChange={value => {
                                    record.feature=''
                                    record.service=''
                                    const Feature = this.dictUtil.dicts(value)
                                    this.setState({
                                        FeatureData: Feature
                                    }, () => {
                                        // this.getDetails()
                                    })
                                    record[dataIndex] = value;
                                    this.forceUpdate()
                                }}
                            >
                                {this.dictUtil.dicts(Selectvalue, dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        )
                    }
                    if (title == 'Feature') {
                        const FeatureData = this.dictUtil.dicts(record.capability)
                        return (
                            <Select style={{width:250 }}
                                disabled={record.disabledReviewStues}
                                value={record[dataIndex]}
                                onChange={value => {
                                    record.service=''
                                    const Service = this.dictUtil.dicts(value)
                                    this.setState({
                                        ServiceData: Service
                                    }, () => {
                                        // this.getDetails()
                                    })
                                    record[dataIndex] = value;
                                    this.forceUpdate()
                                }}
                            >
                                {FeatureData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        )
                    }
                    if (title == 'Service') {
                        const ServiceData = this.dictUtil.dicts(record.feature)
                        return (
                            <Select style={{width:250}}
                            disabled={record.disabledReviewStues}
                                value={record[dataIndex]}
                                onChange={value => {
                                    record[dataIndex] = value;
                                    this.forceUpdate()
                                }}
                            >
                                {ServiceData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        )
                    }
                }
            }
            return <Column ellipsis={true} dataIndex={dataIndex} key={key} {...renderProps} />;
        })
        return (<>{serviceTableColumnGove}</>);
    }
    public render() {
        return (
            <components.PageContainer title="API Demand Update" noHeader={true}>
                {this.renderTableContainer()}
                {this.renderModal()}
                {/* {this.renderReviewModal()} */}
            </components.PageContainer>
        )
    }
    private editLink() {

    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand Request List -->"
                cancelText="Close"
                content="Check Information in Demand  List."
                onOk={() => {
                    this.props.history.goBack()
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private submitEdit() {
        this.state.dataSource.map(item=>{
            delete item.disabledStues
            delete item.apinameStues
            delete item.disabledReviewStues
        })
        this.demandService
            .multiple(
                new RequestParams(
                    this.state.dataSource
                )
            )
            .subscribe(data => {
                this.openSuccessModal()
            })
    }
    private check(value){
        const reg = /^\w+[\w\s-]*$/
        return value.replace(/[^0-9]/g,'')
    }
    public renderTableContainer() {
        const { dataSource, selectedRowKeys, disabledStues, dateFormat, countryData,
            selectobejct, Loading } = this.state
        return (
            <CardContainer title="API Demand Update">
                <Button
                    size="large"
                    onClick={() => {
                        const { fieldsValues, pathName } = this.props.location
                            .state as APIDemandEditState
                        if (pathName) {
                            this.props.history.push({
                                pathname: pathName,
                                state: {
                                    fieldsValues
                                }
                            })
                        } else {
                            this.props.history.goBack()
                        }
                    }}
                    style={{
                        marginTop: -75,
                        float: 'right'
                    }}
                >
                    Back
                </Button>
                {Loading ? null : (
                    <DataTable
                        dataSource={dataSource}
                        // page={this.pageService}
                        // onPageChange={() => this.getDemandList()}
                        rowKey="demandId"
                    >
                        <ColumnGroup title="Demand Governance" className="blue">
                            {/* {this.getExpandTableTitle()} */}
                            <Column
                                title="Entry Created Date"
                                dataIndex="createDate"
                                key="createDate"
                                ellipsis={true}
                                sorter
                            />
                            <Column
                                title="Order Received Date"
                                dataIndex="receivedDate"
                                key="receivedDate"
                                ellipsis={true}
                                sorter
                                render={(record, row: any, value) => (
                                    <DatePicker
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        format={dateFormat}
                                        defaultValue={moment(
                                            row.receivedDate,
                                            dateFormat
                                        )}
                                        onChange={(e, data) => {
                                            row.receivedDate = data
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="Project Name"
                                dataIndex="projectName"
                                key="projectName"
                                sorter
                                render={(record, row: any, value) => (
                                    <Input
                                        // onBlur={()=>{this.check(record)}}
                                        // onKeyUp={()=> this.check(record)}
                                        // onBlur={value => this.limitDecimals(row.projectName)}
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={record}
                                        onChange={e => {
                                            row.projectName = this.limitDecimals(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />

                            <Column
                                title="API Name"
                                dataIndex="apiName"
                                key="apiName"
                                ellipsis={true}
                                sorter
                                render={(record, row: any, value) => (
                                    <Input
                                        disabled={row.apinameStues}
                                        style={{ width: 150 }}
                                        value={record}
                                        onBlur={() => {
                                            this.check(record)
                                        }}
                                        onChange={e => {
                                            row.apiName = this.limitDecimals(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="Demand Classification"
                                dataIndex="demandClassification"
                                ellipsis={true}
                                render={value =>
                                    this.dictUtil.filter(
                                        'api_classification',
                                        value
                                    )
                                }
                            />
                            {this.getExpandTableTitle()}
                            <Column
                                title="Backend System"
                                dataIndex="backEndSystem"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={row.backEndSystem}
                                        onChange={value => {
                                            row.backEndSystem = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {
                                            this.state.selectobejct
                                                .backendsystemData
                                        }
                                    </Select>
                                )}
                            />
                            <Column
                                title="Channel"
                                dataIndex="channel"
                                key="channel"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={row.channel}
                                        onChange={value => {
                                            row.channel = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {this.state.selectobejct.channelData}
                                    </Select>
                                )}
                            />
                            <Column
                                title="Consumer"
                                dataIndex="consumer"
                                key="consumer"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Input
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={record}
                                        onChange={e => {
                                            row.consumer = this.limitDecimals(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="Requester"
                                dataIndex="requester"
                                key="requester"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Input
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={record}
                                        onChange={e => {
                                            row.requester = this.limitDecimals(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="Core Banking API Contact"
                                dataIndex="cbApiContact"
                                key="cbApiContact"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledStues}
                                        style={{ width: '100%' }}
                                        value={row.cbApiContact}
                                        onChange={value => {
                                            row.cbApiContact = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {this.state.selectobejct.apicontactData}
                                    </Select>
                                )}
                            />

                            <Column
                                title="Core Banking System Contact"
                                dataIndex="cbSysContact"
                                key="cbSysContact"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledStues}
                                        style={{ width: '100%' }}
                                        value={row.cbSysContact}
                                        onChange={value => {
                                            row.cbSysContact = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {this.state.selectobejct.BankingData}
                                    </Select>
                                )}
                            />
                            <Column
                                title="GB/GF"
                                dataIndex="gbOrGF"
                                key="gbOrGF"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledStues}
                                        style={{ width: 110 }}
                                        value={row.gbOrGF}
                                        onChange={value => {
                                            row.gbOrGF = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {this.state.selectobejct.GBGFData}
                                    </Select>
                                )}
                            />
                            <Column
                                title="API Lifecycle Stage"
                                dataIndex="apiLifecycleStage"
                                key="apiLifecycleStage"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        style={{ width: 150 }}
                                        value={row.apiLifecycleStage}
                                        onChange={value => {
                                            row.apiLifecycleStage = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {
                                            this.state.selectobejct
                                                .systemcontactData
                                        }
                                    </Select>
                                )}
                            />
                            <Column
                                title="Target Live Date"
                                dataIndex="targetLiveDate"
                                key="targetLiveDate"
                                ellipsis={true}
                                sorter
                                render={(record, row: any, value) => (
                                    <DatePicker
                                        style={{ width: 150 }}
                                        format={dateFormat}
                                        defaultValue={moment(
                                            row.targetLiveDate,
                                            dateFormat
                                        )}
                                        onChange={(e, data) => {
                                            row.targetLiveDate = data
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="Total API L0 Estimates"
                                dataIndex="totalApiL0Estimates"
                                key="totalApiL0Estimates"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Input
                                        type="number"
                                        prefix="$"
                                        suffix="K (USD)"
                                        disabled
                                        max="100"
                                        style={{ width: 150 }}
                                        value={
                                            Number(row.ossApiL0Estimates) +
                                            Number(row.cbSystemL0Estimates)
                                        }
                                        onChange={e => {
                                            row.totalApiL0Estimates =
                                                e.target.value
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />

                            <Column
                                title="Mule API L0 Estimates"
                                dataIndex="ossApiL0Estimates"
                                key="ossApiL0Estimates"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Input
                                        type="number"
                                        prefix="$"
                                        suffix="K (USD)"
                                        min={0}
                                        step={0.01}
                                        max={100}
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={row.ossApiL0Estimates}
                                        onChange={e => {
                                            row.ossApiL0Estimates = this.limitEstimates(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="CB System L0 Estimates"
                                dataIndex="cbSystemL0Estimates"
                                key="cbSystemL0Estimates"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Input
                                        type="number"
                                        prefix="$"
                                        suffix="K (USD)"
                                        min={0}
                                        step={0.01}
                                        disabled={row.disabledStues}
                                        style={{ width: 150 }}
                                        value={row.cbSystemL0Estimates}
                                        onChange={e => {
                                            row.cbSystemL0Estimates = this.limitEstimates(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="BPID"
                                dataIndex="gdpmInterLockBpid"
                                key="gdpmInterLockBpid"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Input
                                        style={{ width: 100 }}
                                        value={record}
                                        onChange={e => {
                                            row.gdpmInterLockBpid = this.limitBPid(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />

                            <Column
                                title="Demand Approval Status"
                                dataIndex="demandStatus"
                                key="demandStatus"
                                ellipsis={true}
                                render={value =>
                                    this.dictUtil.filter(
                                        'design_review_status',
                                        value
                                    )
                                }
                            />
                            <Column
                                title="Demand Approval Date"
                                dataIndex="demandDate"
                                key="demandDate"
                                ellipsis={true}
                                sorter
                            />
                        </ColumnGroup>
                        <ColumnGroup
                            title="Design Governance"
                            className="green"
                        >
                            {/* getExpandTableTitleGove */}
                            {this.getExpandTableTitleGove()}
                            <Column
                                title="Platform"
                                dataIndex="platform"
                                key="platform"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledReviewStues}
                                        style={{ width: 150 }}
                                        value={row.platform}
                                        onChange={value => {
                                            row.platform = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {this.state.selectobejct.PlatformData}
                                    </Select>
                                )}
                            />
                            <Column
                                title="API Type"
                                dataIndex="apiType"
                                key="apiType"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledReviewStues}
                                        style={{ width: 150 }}
                                        value={row.apiType}
                                        onChange={value => {
                                            row.apiType = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {this.state.selectobejct.apitypeData}
                                    </Select>
                                )}
                            />
                            <Column
                                title="Channel Agnostic"
                                dataIndex="channelAgnostic"
                                key="channelAgnostic"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledReviewStues}
                                        style={{ width: 150 }}
                                        value={row.channelAgnostic}
                                        onChange={value => {
                                            row.channelAgnostic = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {
                                            this.state.selectobejct
                                                .channelAgnosticData
                                        }
                                    </Select>
                                )}
                            />
                            <Column
                                title="Reusability Score"
                                dataIndex="reusabilityScore"
                                key="reusabilityScore"
                                ellipsis={true}
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledReviewStues}
                                        style={{ width: 150 }}
                                        value={row.reusabilityScore}
                                        onChange={value => {
                                            row.reusabilityScore = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        {
                                            this.state.selectobejct
                                                .reusabilityscoreData
                                        }
                                    </Select>
                                )}
                            />
                            <Column
                                title="API ID"
                                dataIndex="trueSapiId"
                                key="trueSapiId"
                                ellipsis={true}
                                sorter
                                render={(record, row: any, value) => (
                                    <Input
                                        style={{ width: 150 }}
                                        value={row.trueSapiId}
                                        onChange={e => {
                                            row.trueSapiId = this.limitDecimals(
                                                e.target.value
                                            )
                                            this.forceUpdate()
                                        }}
                                    />
                                )}
                            />
                            <Column
                                title="Multi-Site"
                                dataIndex="multiCountry"
                                key="multiCountry"
                                render={(record, row: any, value) => (
                                    <Select
                                        disabled={row.disabledReviewStues}
                                        style={{ width: 100 }}
                                        value={row.multiCountry}
                                        onChange={value => {
                                            row.multiCountry = value
                                            this.forceUpdate()
                                        }}
                                    >
                                        <Select.Option value="Y">
                                            Y
                                        </Select.Option>
                                        <Select.Option value="N">
                                            N
                                        </Select.Option>
                                    </Select>
                                )}
                            />
                            <Column
                                title="Original API ID"
                                dataIndex="originalSapiId"
                                key="originalSapiId"
                                ellipsis={true}
                            />
                            <Column
                                title="Design Review Status"
                                dataIndex="designReviewStatus"
                                key="designReviewStatus"
                                ellipsis={true}
                                render={value =>
                                    this.dictUtil.filter(
                                        'design_review_status',
                                        value
                                    )
                                }
                            />
                            <Column
                                title="Design Review Date"
                                dataIndex="designReviewDate"
                                key="designReviewDate"
                                ellipsis={true}
                                sorter
                            />
                            <Column
                                title="Design Approval Status"
                                dataIndex="designStatus"
                                key="designStatus"
                                ellipsis={true}
                                render={value =>
                                    this.dictUtil.filter(
                                        'design_review_status',
                                        value
                                    )
                                }
                            />
                            <Column
                                title="Design Approval Date"
                                dataIndex="designDate"
                                key="designDate"
                                ellipsis={true}
                                sorter
                            />
                        </ColumnGroup>
                    </DataTable>
                )}

                <Button
                    type="primary"
                    size="large"
                    onClick={() => {
                        this.submitEdit()
                    }}
                    style={{
                        marginTop: 15,
                        float: 'right'
                    }}
                >
                    Submit
                </Button>
            </CardContainer>
        )
    }
}
