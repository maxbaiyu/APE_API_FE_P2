import { ReactNode } from 'react'
export interface apiReviewDemandList {
    title:string
    dataIndex: string
    key:string
    Selectvalue?:string
    detaSelect?:Boolean
    inputSelect?:Boolean
    isSelect?:Boolean
    disabled?:Boolean
}
export const apiReviewDemandListHeader:apiReviewDemandList[] = [
    // { title: 'Entry Created Date',
    //   dataIndex: 'createDate',
    //   key: 'createDate',
    //   detaSelect:true 

    // },
    // { title: 'Order Received Date', 
    //   dataIndex: 'receivedDate',
    //   key: 'receivedDate',
    //   detaSelect:true 
    //  },
    // {
    //     title: 'Project Name',
    //     key: 'projectName',
    //     dataIndex: 'projectName',
    //     inputSelect:true
    // },
    // {
    //     title: 'API Name',
    //     dataIndex: 'apiName',
    //     key: 'apiName',
    //     inputSelect:true
    // },
    // {
    //     title: 'Demand Classification',
    //     key: 'demandClassification',
    //     dataIndex: 'demandClassification',
    //     isSelect: true,
    //     Selectvalue:'api_classification'
    // },
    {
        title: 'Region',
        dataIndex: 'region',
        key: 'region',
        isSelect: true,
        Selectvalue:'region'
    },
    {
        title: 'Site',
        dataIndex: 'country',
        key: 'country',
        isSelect: true,
        Selectvalue:'country'
    },
    // {
    //     title: 'Backend System',
    //     dataIndex: 'backEndSystem',
    //     key: 'backEndSystem',
    //     isSelect: true,
    //     Selectvalue:'backend_system'
    // },
    // {
    //     title: 'Channel',
    //     dataIndex: 'channel',
    //     key: 'channel',
    //     isSelect: true,
    //     Selectvalue:'channel'
    // },
    // {
    //     title: 'Consumer',
    //     dataIndex: 'consumer',
    //     key: 'consumer',
    //     inputSelect:true
    // },
    // {
    //     title: 'Requester',
    //     dataIndex: 'requester',
    //     key: 'requester',
    //     inputSelect:true
    // },
    // {
    //     title: 'Core Banking API Contact',
    //     dataIndex: 'cbApiContact',
    //     key: 'cbApiContact',
    //     isSelect: true,
    //     Selectvalue:'cb_api_contact'
    // },
    // {
    //     title: 'Core Banking System Contact',
    //     dataIndex: 'cbSysContact',
    //     key: 'cbSysContact',
    //     isSelect: true,
    //     Selectvalue:'cb_system_contact'
    // },
    // {
    //     title: 'GB/GF',
    //     dataIndex: 'gbOrGF',
    //     key: 'gbOrGF',
    //     isSelect: true,
    //     Selectvalue:'gb_gf'
    // },
    // // {
    // //     title: 'Multi-Site',
    // //     dataIndex: 'multiCountry',
    // //     key: 'multiCountry',
    // //     inputSelect:true
    // // },
    // {
    //     title: 'API Lifecycle Stage',
    //     dataIndex: 'apiLifecycleStage',
    //     key: 'apiLifecycleStage',
    //     isSelect: true,
    //     Selectvalue:'api_lifecycle_stage'
    // },
    // {
    //     title: 'Target Live Date',
    //     dataIndex: 'targetLiveDate',
    //     key: 'targetLiveDate',
    //     detaSelect:true 
    // },
    // {
    //     title: 'Total API L0 Estimates',
    //     dataIndex: 'totalApiL0Estimates',
    //     key: 'totalApiL0Estimates',
    //     inputSelect:true,
    //     disabled:true
    // },
    // {
    //     title: 'Mule API L0 Estimates',
    //     dataIndex: 'ossApiL0Estimates',
    //     key: 'ossApiL0Estimates',
    //     inputSelect:true,
    // },
    // {
    //     title: 'CB System L0 Estimates',
    //     dataIndex: 'cbSystemL0Estimates',
    //     key: 'cbSystemL0Estimates',
    //     inputSelect:true,
    // },
    // {
    //     title: 'BPID',
    //     dataIndex: 'gdpmInterLockBpid',
    //     key: 'gdpmInterLockBpid',
    //     inputSelect:true,
    // },
]
export interface APIReviewDemandListColumnProps {
    title: ReactNode | string
    render?: any
}