import createRequest from '~/assets/svg/CreateRequest-Approve.svg'
import uploadContract from '~/assets/svg/Upload Contract.svg'
import AssignReviewer from '~/assets/svg/Assign Reviewer-Approve.svg'
import DesignReview from '~/assets/svg/DesignReview.svg'
import RDRReview from '~/assets/svg/RDRReview.svg'
import APICatalogue from '~/assets/svg/APICatalogue.svg'
import arrow1 from '~/assets/svg/Arrow1.svg'

interface homePageJumpDatasPro {
    title: String
    iconSrc: any
    histroyGo?: any
    arrow1: any
    power?: any
}

export const homePageJumpDatas: homePageJumpDatasPro[] = [
    {
        title: 'Create Demand',
        iconSrc: createRequest,
        histroyGo: '/pages/demand-request-form',
        arrow1: arrow1,
        power: ['ROLE_01']
    },
    {
        title: 'Upload Contract',
        iconSrc: uploadContract,
        histroyGo: '/pages/api-review-request-list',
        arrow1: arrow1,
        power: ['ROLE_01']
    },
    {
        title: 'Assign Reviewer',
        iconSrc: AssignReviewer,
        histroyGo: '/pages/api-review-task-assignment',
        arrow1: arrow1,
        power: ['ROLE_08']
    },
    {
        title: 'Demand/Design',
        iconSrc: DesignReview,
        histroyGo: '/pages/api-demand-request-list',
        arrow1: arrow1,
        power: ['ROLE_02']
    },
    {
        title: 'RDR/GBDR/GTDR',
        iconSrc: RDRReview,
        histroyGo: '/pages/api-review-request-list',
        arrow1: arrow1,
        power: [
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08'
        ]
    },
    {
        title: 'API Catalogue',
        iconSrc: APICatalogue,
        histroyGo: '/pages/api-catalogue',
        arrow1: null,
        power: [
            'ROLE_01',
            'ROLE_02',
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07',
            'ROLE_08',
            'ROLE_09',
            'ROLE_10'
        ]
    }
]
