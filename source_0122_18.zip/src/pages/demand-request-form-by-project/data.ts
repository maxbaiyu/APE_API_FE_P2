import { ApiService } from '~/services/api.service';
import { DemandService } from '~/services/demand.service';
import { RequestParams } from '~/core/http';
import { rulesdata } from '~/assets/regular/rest'
const apiSevice = new ApiService();
const demandService = new DemandService();
export interface proInfoItemProps {
    name?: String
    label?: String
    type?: String
    disabled?: Boolean
    rules?: any
    optionUtilsKey?: any
    options?: any
    value?: String | React.ReactNode
    className?: String
    dropdownClassName?: String
    isExist?: any
    labelInValue?: Boolean
    resetFields?: any
    onSearchPro?: any
    selectKey?: any
    selectValue?: any
    selectName?: any
    inputProps?: any
    initialValue?: any
    validateTrigger?: any
}

export const proInfoItems: proInfoItemProps[] = [
    {
        name: 'projectName',
        label: 'Project Name',
        type: 'debounceSelect',
        selectKey: 'projectName',
        selectValue: 'projectName',
        selectName: 'projectName',
        disabled: false,
        rules: [{
            message: 'Project Name can contain letters, numbers, spaces, and special character: -&().',
            pattern: rulesdata.patternOneProjectName
        }],
        options: [],
        value: '',
        labelInValue: false,
        className: '',
        onSearchPro: value => {
            return new Promise((resolve, reject) => {
                if (value) {
                    demandService
                        .projectName(new RequestParams({}, { append: [value] }))
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            resolve([]);
                        })
                } else {
                    reject('value is empty');
                }
            })
        },
    },
    {
        name: 'requester',
        label: 'Requester',
        type: 'input',
        disabled: false,
        rules: [{
            message: 'Requester can contain letters, numbers, spaces.',
            pattern: rulesdata.patternOne
        }],
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'region',
        label: 'Region',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [{ required: true }],
        optionUtilsKey: 'region',
        options: [],
        value: '',
        className: '',
        resetFields: ['country']
    },
    {
        name: 'country',
        label: 'Site',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [],
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'backEndSystem',
        label: 'Backend System',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [],
        optionUtilsKey: 'backend_system',
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'channel',
        label: 'Channel',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [{ required: true }],
        optionUtilsKey: 'channel',
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'consumer',
        label: 'Consumer',
        type: 'input',
        disabled: false,
        rules: [{
            message: 'Consumer can contain letters, numbers, spaces.',
            pattern: rulesdata.patternOne
        }],
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'gbOrGF',
        label: 'GB/GF',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [{ required: true }],
        optionUtilsKey: 'gb_gf',
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'cbApiContact',
        label: 'Core Banking API Contact',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [{ required: true }],
        optionUtilsKey: 'cb_api_contact',
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'cbSysContact',
        label: 'Core Banking System Contact',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [{ required: true }],
        optionUtilsKey: 'cb_system_contact',
        options: [],
        value: '',
        className: ''
    },
    {
        name: 'receivedDate',
        label: 'Order Received Date',
        type: 'datePicker',
        disabled: false,
        rules: [{ required: true }],
        options: [],
        value: '',
        className: 'api-data-picker'
    },
    {
        name: 'gdpmInterLockBpid',
        label: 'BPID',
        type: 'multComponentBpid',
        disabled: false,
        rules: [{
            message: 'BPID can only contain numbers.',
            pattern: rulesdata.patternNum
        }],
        options: [],
        value: ''
    },
]

export const demandInfoItems: proInfoItemProps[] = [
    {
        name: 'demandClassification',
        label: 'Demand Classification',
        type: 'select',
        selectKey: 'dirCode',
        selectValue: 'dirCode',
        selectName: 'dirName',
        disabled: false,
        rules: [{ required: true }],
        optionUtilsKey: 'api_classification',
        options: [],
        value: '',
        className: '',
    },
    {
        name: 'apiName',
        label: 'API Name',
        type: 'input',
        disabled: false,
        validateTrigger: ['onChange'],
        rules: [
            {
                required: true,
                message:'API Name can contain letters, numbers, spaces, and special character: -.',
                pattern: rulesdata.patternOne
                // message: 'Please enter API Name',
            },
        ],
        options: [],
        value: '',
        labelInValue: true,
        className: 'api-name',
        isExist: inputType => inputType === '01' || inputType === '02'
    },
    {
        name: 'apiName',
        label: 'API Name',
        type: 'debounceSelect',
        selectKey: 'apiCatalogueId',
        selectValue: 'apiCatalogueId',
        selectName: 'apiName',
        disabled: false,
        rules: [{ required: true }],
        options: [],
        value: '',
        labelInValue: true,
        className: '',
        onSearchPro: value => {
            return new Promise((resolve, reject) => {
                if (value) {
                    apiSevice
                        .getApiListByName(new RequestParams({}, { append: [value] }))
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject(error);
                        })
                } else {
                    reject('value is empty');
                }
            })
        },
        isExist: inputType => inputType !== '01' && inputType !== '02'
    },
    {
        name: 'reuseApiVersion',
        label: 'Reused API Version',
        type: 'select',
        selectKey: 'versionId',
        selectValue: 'versionId',
        selectName: 'version',
        disabled: false,
        rules: [],
        options: [],
        value: '',
        labelInValue: true,
        className: '',
        isExist: inputType => inputType !== '01' && inputType !== '02'
    },
    {
        name: 'targetLiveDate',
        label: 'Target Live Date',
        type: 'datePicker',
        disabled: false,
        rules: [{ required: true }],
        options: [],
        value: '',
        className: 'api-data-picker'
    },
    {
        name: 'ossApiL0Estimates',
        label: 'Mule API L0 Estimates',
        type: 'inputNumber',
        rules: [{
            required: true,
            message: 'Mule API L0 Estimates only contain numbers greater than 0, decimal fraction is allowed.',
            pattern: rulesdata.patternGreater
        }],
        className: 'input-number-row',
        inputProps: {
            min: 0,
            step: 0.01
        }
    },
    {
        label: '+',
        type: 'init',
        className: 'arithmetic-operator'
    },
    {
        name: 'cbSystemL0Estimates',
        label: 'CB Systems L0 Estimates',
        type: 'inputNumber',
        rules: [{
            required: true,
            message: 'CB Systems L0 Estimates only contain numbers greater than 0, decimal fraction is allowed.',
            pattern: rulesdata.patternGreater
        }],
        className: 'input-number-row',
        inputProps: {
            min: 0,
            step: 0.01
        }
    },
    {
        label: '=',
        type: 'init',
        className: 'arithmetic-operator'
    },
    {
        name: 'totalApiL0Estimates',
        label: 'Total API L0 Estimates',
        type: 'inputNumber',
        rules: [{
            required: true
        }],
        className: 'input-number-row',
        initialValue: 0,
        inputProps: {
            readOnly: true
        }
    }
]