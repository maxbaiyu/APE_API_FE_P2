import React, { useState, useRef, useEffect } from 'react'
import { useHistory } from 'react-router-dom'
import { Form, Radio, Input, Select, Card, Avatar, Button, Empty } from 'antd'
import { CheckCircleTwoTone } from '@ant-design/icons'
import debounce from 'lodash/debounce'
import filter from '~/assets/svg/user-center-filter.svg'

import { TD_LIST_FILTER_BTN_WIDTH } from './type'
import AssignReviewer from '~/assets/svg/Assign Reviewer-Approve.svg'
import DemandReview from '~/assets/svg/DesignReview.svg'
import Review from '~/assets/svg/RDRReview.svg'

const { Meta } = Card

interface TodolistProps {
    listData: any
    userStore: any
}

const UserCenterTask: React.FC<TodolistProps> = props => {
    const { listData } = props

    const [toDolistData, setToDoListData] = useState<any[]>(listData)
    const [demandStatus, setDemandStatus] = useState<boolean>(false)
    const [reviewStatus, setReviewStatus] = useState<boolean>(false)
    const [assignStatus, setAssignStatus] = useState<boolean>(false)
    const [visibleFilterBtnLen, setVisFilterBtnLen] = useState<number>(3)
    const [filterBtnAuthority, setFilterBtnAuthority] = useState<any>({
        demandVis: true,
        reviewVis: true,
        assignVis: true
    })

    const cacheListData = useRef<any[]>([])

    const [form] = Form.useForm()

    const history = useHistory()

    const getAvatarSrc = type => {
        if (type === 'Demand') {
            return DemandReview
        }
        if (type === 'Review') {
            return Review
        }
        return AssignReviewer
    }

    const openForm = taskInfo => {
        const { functionType, demandId = '', reviewId = '' } = taskInfo
        let jumpPathName: string
        if (functionType === 'Demand') {
            jumpPathName = '/pages/demand-request-form-exhibition'
        } else if (functionType === 'Review') {
            jumpPathName = '/pages/review-request-form'
        } else {
            jumpPathName = '/pages/api-review-task-assignment'
        }
        history.push({
            pathname: jumpPathName,
            state: {
                demandId,
                // todo
                reviewId,
                pathName: '/pages/user-center'
            }
        })
    }

    const filterFormValuesFun = () => {
        const { filter, apiName = '' } = form.getFieldsValue()
        const filterFormValues = cacheListData.current
            .filter(item => {
                if (filter === 'pending') {
                    return item.taskStatus === 'N'
                }
                return item
            })
            .filter(item =>
                item.apiName
                    .trim()
                    .toUpperCase()
                    .includes(apiName.trim().toUpperCase())
            )
        setToDoListData(
            filterFormValues.filter(item => {
                return (
                    (item.functionType === 'Demand' && demandStatus) ||
                    (item.functionType === 'Review' && reviewStatus) ||
                    (item.functionType === 'Assign' && assignStatus) ||
                    (!demandStatus && !reviewStatus && !assignStatus)
                )
            })
        )
    }

    useEffect(() => {
        const demandVis = ['ROLE_02'].some(role =>
            props?.userStore.state.roleList.map(x => x.authority).includes(role)
        )

        const reviewVis = [
            'ROLE_03',
            'ROLE_04',
            'ROLE_05',
            'ROLE_06',
            'ROLE_07'
        ].some(role =>
            props?.userStore.state.roleList.map(x => x.authority).includes(role)
        )

        const assignVis = ['ROLE_08'].some(role =>
            props?.userStore.state.roleList.map(x => x.authority).includes(role)
        )

        let filterBtnLen = 3
        if (!demandVis) {
            filterBtnLen--
        }
        if (!reviewVis) {
            filterBtnLen--
        }
        if (!assignVis) {
            filterBtnLen--
        }
        setFilterBtnAuthority({
            demandVis,
            reviewVis,
            assignVis
        })
        setVisFilterBtnLen(filterBtnLen)
    }, [props.userStore])

    useEffect(() => {
        cacheListData.current = props.listData
        setToDoListData(props.listData)
    }, [props?.listData])

    useEffect(() => {
        filterFormValuesFun()
    }, [demandStatus, reviewStatus, assignStatus])

    return (
        <>
            <Form
                form={form}
                name="toDoListForm"
                layout="inline"
                onValuesChange={debounce(filterFormValuesFun, 200)}
                initialValues={{
                    filter: 'all'
                }}
            >
                <Form.Item name="filter" className={'demand-filter'} noStyle>
                    <Radio.Group>
                        <Radio.Button value="all">All</Radio.Button>
                        <Radio.Button value="pending">Pending</Radio.Button>
                    </Radio.Group>
                </Form.Item>
                <Form.Item
                    name="apiName"
                    className={'project-name-input'}
                    style={{
                        width: `calc(100% - 10rem - ${
                            visibleFilterBtnLen * TD_LIST_FILTER_BTN_WIDTH
                        }rem)`,
                        marginRight: '0'
                    }}
                >
                    <Input
                        placeholder="API Name"
                        prefix={<img src={filter} />}
                    />
                </Form.Item>
                <Form.Item name="demandReview" noStyle>
                    {filterBtnAuthority.demandVis ? (
                        <div>
                            <Button
                                // type={demandStatus ? 'dashed' : 'default'}
                                onClick={() => {
                                    setDemandStatus(!demandStatus)
                                    setReviewStatus(false)
                                    setAssignStatus(false)
                                }}
                            >
                                Demand Review
                            </Button>
                            {demandStatus ? (
                                <CheckCircleTwoTone twoToneColor="#52c41a" />
                            ) : null}
                        </div>
                    ) : null}
                </Form.Item>
                <Form.Item name="designReview" noStyle>
                    {filterBtnAuthority.reviewVis ? (
                        <div>
                            <Button
                                onClick={() => {
                                    setReviewStatus(!reviewStatus)
                                    setDemandStatus(false)
                                    setAssignStatus(false)
                                }}
                            >
                                Design Review
                            </Button>
                            {reviewStatus ? (
                                <CheckCircleTwoTone twoToneColor="#52c41a" />
                            ) : null}
                        </div>
                    ) : null}
                </Form.Item>
                <Form.Item name="assignTask" noStyle>
                    {filterBtnAuthority.assignVis ? (
                        <div>
                            <Button
                                onClick={() => {
                                    setAssignStatus(!assignStatus)
                                    setReviewStatus(false)
                                    setDemandStatus(false)
                                }}
                            >
                                Assign Task
                            </Button>
                            {assignStatus ? (
                                <CheckCircleTwoTone twoToneColor="#52c41a" />
                            ) : null}
                        </div>
                    ) : null}
                </Form.Item>
            </Form>

            {toDolistData.length ? (
                toDolistData.map((item, index) => (
                    <Card
                        size="small"
                        className={
                            item?.taskStatus === 'N'
                                ? 'to-do-list-card unread-card'
                                : 'to-do-list-card read-card'
                        }
                        key={`todo-${index}`}
                    >
                        <Meta
                            avatar={
                                <Avatar src={getAvatarSrc(item.functionType)} />
                            }
                            title={
                                <>
                                    <span>{`[${item.title}]`}</span>
                                    <span> {item.messagePrefix}</span>
                                    <Button
                                        type="link"
                                        onClick={() => {
                                            openForm(item)
                                        }}
                                    >
                                        {item.apiName}
                                        {' - '}
                                        {item.projectName}
                                    </Button>
                                    <span className={'card-suffix-mes'}>
                                        {item.message}
                                    </span>
                                </>
                            }
                            description={`Operated by ${item.operator} at ${item.operatingTime}`}
                        />
                    </Card>
                ))
            ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
        </>
    )
}

export default UserCenterTask
