import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    Modal,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { DemandService } from '~/services/demand.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import moment from 'moment'
import NotificationContainer from '~/shared/components/notification-container'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { isNullOrUndefined } from 'util'
import { values } from 'ramda'
import { LeftSquareOutlined } from '@ant-design/icons'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface DemandRequestFormDetailTWOState {
    demandId: string
    data: any
    reviewModalVisible: boolean
    successModalVisible: boolean
    discharge: boolean
    discharge2: boolean
    countryData: any[]
    featureData: any[]
    serviceData: any[]
    hover: boolean
    fieldsValues: any
    pathName: string
}

interface DemandRequestFormDetailTWOProps {}

const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})

export default class DemandRequestFormDetailTWO extends Component<
    RouteComponentProps<DemandRequestFormDetailTWOProps>,
    DemandRequestFormDetailTWOState
> {
    private dataFromRef!: React.RefObject<DataForm>
    private dataFrom1Ref!: React.RefObject<DataForm>
    private dataFrom2Ref!: React.RefObject<DataForm>

    private demandService = new DemandService()
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private statusType = ''
    private demandStatus = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.dataFrom1Ref = React.createRef()
        this.dataFrom2Ref = React.createRef()
        this.actionFromRef = React.createRef()

        this.state = {
            demandId: '',
            data: {},
            discharge: true,
            discharge2: true,
            hover:false,
            reviewModalVisible: false,
            successModalVisible: false,
            countryData: [],
            featureData: [],
            serviceData: [],
            fieldsValues: {},
            pathName: '',
        }
    }
    public componentDidMount() {
        const { demandId } = this.props.location.state as DemandRequestFormDetailTWOState
        this.demandService
            .get(new RequestParams({}, { append: [demandId] }))
            .subscribe(data => {
                this.setState({
                    data: data
                })
                this.dataForm.formInstance.setFieldsValue({
                    ...data,
                    targetLiveDate:
                        isNullOrUndefined(data.targetLiveDate) ||
                        data.targetLiveDate === ''
                            ? ''
                            : moment(data.targetLiveDate),
                    receivedDate:
                        isNullOrUndefined(data.receivedDate) ||
                        data.receivedDate === ''
                            ? ''
                            : moment(data.receivedDate)
                })
                this.dataForm1.formInstance.setFieldsValue({
                    ...data,
                    designReviewDate:
                        isNullOrUndefined(data.designReviewDate) ||
                        data.designReviewDate === ''
                            ? ''
                            : moment(data.designReviewDate)
                })
                this.dataForm2.formInstance.setFieldsValue({
                    ...data,
                    targetDateOfNextMilestone:
                        isNullOrUndefined(data.targetDateOfNextMilestone) ||
                        data.targetDateOfNextMilestone === ''
                            ? ''
                            : moment(data.targetDateOfNextMilestone),
                    targetOverallDelivery:
                        isNullOrUndefined(data.targetOverallDelivery) ||
                        data.targetOverallDelivery === ''
                            ? ''
                            : moment(data.targetOverallDelivery)
                })
            })

    }
    private openedit() {
        const { data } = this.state
        const { demandStatus } = data
        const ids  = this.props.location.state as DemandRequestFormDetailTWOState
        this.props.history.push({
            pathname: '/pages/demand-request-form-detail',
            // pathname: '/pages/demand-request-form-exhibition',
            state: {
                demandId: ids.demandId,
                demandStatusid:data.demandStatus
            }
        })
    }
    private openReviewModal() {
        this.setState({
            reviewModalVisible: true
        })
    }
    private toggleHover = () => {
        this.setState({
            hover: !this.state.hover
        })
    }

    public render() {
        const {
            discharge,
            discharge2,
            data,
            countryData,
            featureData,
            serviceData
        } = this.state
        let demandStatusButton
        var linkStyle
        var imgsrc=''
        if (this.state.hover) {
            imgsrc = require('~/assets/images/qm.png')
            linkStyle = {
                display: 'block',
                position: 'absolute',
                left:250,
                top: 2,
                width: 508,
                height: 70,
                backgroundColor: '#fff',
                border: '1px solid #333333',
                padding: 15,
                fontSize:12,
                color:'#333333',
                cursor:'pointer',
                zIndex: 999
            }
        } else {
            imgsrc=require('~/assets/images/Help.png')
            linkStyle = {
                display: 'none'
            }
        }
        var Bpid=data.gdpmInterLockBpid
        var gdpmInterLockBpidYear=data.gdpmInterLockBpidYear
        var href='https://planningdatamodel.it.global.hsbc/gpdm'+gdpmInterLockBpidYear+'/billableProduct.asp?bpID='+Bpid
        return (
            <components.PageContainer title="Demand Request Detail"  noHeader={true} isNotNeedFlex={true} isNeedCenter={true}>
                <div
                    // className="flex-row justify-content-end"
                    className="flex-row justify-content-between"
                    style={{ paddingTop: 10 }}
                >
                     <div   style={{ fontSize: 28,marginLeft: 20}}>{data.apiName}</div>
                     <div>
                     <components.AuthDisableButton
                        auth={[
                            'ROLE_01',
                            ]}
                       type="primary"
                        size="large"
                        style={{
                            marginRight:20
                        }}
                        onClick={() => {
                            this.openedit()
                        }}
                    >
                        Edit
                    </components.AuthDisableButton>
                    <Button
                        size="large"
                        onClick={() => {
                            // this.props.history.goBack()
                            const { fieldsValues, pathName } = this.props.location.state as DemandRequestFormDetailTWOState
                            if (pathName) {
                                this.props.history.push({
                                    pathname: pathName,
                                    state: {
                                        fieldsValues
                                    }
                                })
                            } else {
                                this.props.history.goBack();
                            }
                        }}
                    >
                        Back
                    </Button>
                    </div>
                </div>
                 {/* <Divider /> */}
                <CardContainer title="Demand Governance">
                    <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="API Name">
                            <Button
                                type="link"
                                className="text-left"
                                style={{
                                    ...styles().input(
                                        data.apiCatalogueId != null
                                    ),
                                    padding: 0
                                }}
                                onClick={() =>
                                    this.openForm(data.apiCatalogueId)
                                }
                            >
                                {data.apiName}
                            </Button>
                            <div
                                style={{
                                    ...styles().input(
                                        data.apiCatalogueId === null
                                    ),
                                    padding: 0
                                }}
                            >
                                {data.apiName}
                            </div>
                        </LabelItem>
                        <LabelItem label="Entry Created Date">
                            {data.createDate}
                        </LabelItem>
                        <LabelItem label="Project Name">
                            {data.projectName}
                        </LabelItem>
                        <LabelItem label="Order Received Date">
                            {data.receivedDate}
                        </LabelItem>
                        <LabelItem label="Region">
                            {/* {data.region} */}
                            {this.dictUtil.filter(
                                'region',
                                data.region
                            )}
                            {/* {dict.dirName} */}
                        </LabelItem>
                        <LabelItem label="Requester">
                            {data.requester}
                        </LabelItem>
                        <LabelItem label="Site">
                            {/* {data.country} */}
                            {this.dictUtil.filter(
                                data.region,
                                data.country
                            )}
                        </LabelItem>
                        <LabelItem label="Core Banking API Contact">
                            {/* {data.cbApiContact} */}
                            {this.dictUtil.filter(
                                'cb_api_contact',
                                data.cbApiContact
                            )}
                        </LabelItem>
                        <LabelItem label="Backend System">
                            {/* {data.backEndSystem} */}
                            {this.dictUtil.filter(
                                'backend_system',
                                data.backEndSystem
                            )}
                        </LabelItem>
                        <LabelItem label="Core Banking System Contact">
                            {/* {data.cbSysContact} */}
                            {this.dictUtil.filter(
                                'cb_system_contact',
                                data.cbSysContact
                            )}
                        </LabelItem>
                        <LabelItem label="Channel">
                            {/* {data.channel} */}
                            {this.dictUtil.filter(
                                'channel',
                                data.channel
                            )}
                        </LabelItem>
                        <LabelItem label="Total API L0 Estimates">
                            {'$ ' + data.totalApiL0Estimates + 'K (USD)'}
                            {/* {this.dictUtil.filter(
                                'channel',
                                data.totalApiL0Estimates
                            )} */}
                        </LabelItem>
                        <LabelItem label="GB/GF">
                            {/* {data.gbOrGF} */}
                            {this.dictUtil.filter(
                                'gb_gf',
                                data.gbOrGF
                            )}
                        </LabelItem>
                            <LabelItem label="Mule API L0 Estimates">
                            {'$ ' + data.ossApiL0Estimates + 'K (USD)'}
                        </LabelItem>
                            <LabelItem label="Demand Classification">
                            {/* {data.demandClassification} */}
                            {this.dictUtil.filter(
                                'api_classification',
                                data.demandClassification
                            )}
                        </LabelItem>
                            <LabelItem label="CB System L0 Estimates">
                            {'$ ' + data.cbSystemL0Estimates + 'K (USD)'}
                        </LabelItem>
                            <LabelItem label="API Lifecycle Stage">
                            {/* {data.apiLifecycleStage} */}
                            {this.dictUtil.filter(
                                'api_lifecycle_stage',
                                data.apiLifecycleStage
                            )}
                        </LabelItem>
                            <LabelItem label="BPID">
                            {/* {data.gdpmInterLockBpid} */}
                            <a
                                type="link"
                                className="text-left"
                                href={href}
                                // appConfig.server +'/demand/export','API-Demand-Request-List.xls',
                            >
                                {data.gdpmInterLockBpid}
                            </a>
                        </LabelItem>
                            <LabelItem label="Target Live Date">
                            {data.targetLiveDate}
                        </LabelItem>
                        <LabelItem label="Consumer">
                            {data.consumer}
                        </LabelItem>
                    </LabelContainer>
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                    >
                    </DataForm>
                    {this.renderDemandApprovalViewBox()}
                </CardContainer>
                <CardContainer title=" Design Governance">
                <div
                            style={{
                                position: 'absolute',
                                left: 220,
                                top: 26,
                                cursor:'pointer',
                                zIndex: 1000
                            }}
                            onClick={this.toggleHover}
                        >
                            <img
                                width="20"
                                src={imgsrc}
                            ></img>
                        </div>
                        <div style={linkStyle}     
                           onClick={() => {
                            // window.open(
                            //     'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Terminology'
                            // )
                        }}
                            >
                            <div
                                style={{
                                    position: 'absolute',
                                    width:0,
                                    height:0,
                                    top:'25px',
                                    left:'-20px',
                                    border:'10px solid transparent',
                                    borderRightColor:'#333333'
                                 }
                             }
                            ></div>
                            <div
                                style={{
                                    position: 'absolute',
                                    width:0,
                                    height:0,
                                    top:'25px',
                                    left:'-18px',
                                    border:'10px solid transparent',
                                    borderRightColor:'#fff',
                                    zIndex:99
                                 }
                             }
                            ></div>
                            Refer to Review Request Form. All information in Design Governance is required to be entered form Design Review Request Form.
                        </div>
                   <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="Capability">
                            {/* {data.capability} */}
                            {this.dictUtil.filter(
                                'capability',
                                data.capability
                            )}
                        </LabelItem>
                        <LabelItem label="API ID">
                            {data.trueSapiId}
                        </LabelItem>
                        <LabelItem label="Feature">
                            {/* {data.feature} */}
                            {this.dictUtil.filter(
                                data.capability,
                                data.feature
                            )}
                        </LabelItem>
                        <LabelItem label="Original API ID">
                            {data.originalSapiId}
                        </LabelItem>
                            <LabelItem label="Service">
                            {/* {data.service} */}
                            {this.dictUtil.filter(
                                data.feature,
                                data.service
                            )}
                        </LabelItem>
                            <LabelItem label="Multi-Site">
                            {data.multiCountry}
                        </LabelItem>
                            <LabelItem label="Platform">
                            {/* {data.platform}*/}
                             {this.dictUtil.filter(
                                'platform',
                                data.platform
                            )}
                        </LabelItem>
                            <LabelItem label="Reusability Score">
                            {/* {data.reusabilityScore} */}
                            {this.dictUtil.filter(
                                'reusability_score', data.reusabilityScore
                            )}
                        </LabelItem>
                            <LabelItem label="Channel Agnostic">
                            {/* {data.channelAgnostic} */}
                            {this.dictUtil.filter(
                                'channel_agnostic',
                                data.channelAgnostic
                            )}
                        </LabelItem> 
                            <LabelItem label="Design Review Approval Status">
                            {/* {data.designReviewStatus} */}
                            {this.dictUtil.filter(
                                'design_review_status',
                                data.designReviewStatus
                            )}
                        </LabelItem> 
                        <LabelItem label="API Type">
                            {/* {data.apiType} */}
                            {this.dictUtil.filter(
                                'api_type', data.apiType
                            )}
                        </LabelItem> 
                        <LabelItem label="Design Review Approval Date">
                            {data.designReviewDate}
                        </LabelItem> 
                   </LabelContainer>
                    <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom1Ref}
                    >
                    </DataForm>

                    {this.renderDesignApprovalViewBox()}
                    {this.renderModal()}
                    {this.renderReviewModal()}
                </CardContainer>
                {/* <Divider /> */}
                <CardContainer title="Other Information">
                <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="Target Date of Next Milestone">
                            {data.targetDateOfNextMilestone}
                        </LabelItem>
                        <LabelItem label="Target Overall Delivery">
                            {data.targetOverallDelivery}
                        </LabelItem>
                        <LabelItem label="Next Miletone RAG Status">
                            {data.nextMiletoneRagStatus}
                        </LabelItem>
                        <LabelItem label="Overall Delivery RAG Status">
                            {data.overallDeliveryRagStatus}
                        </LabelItem>
                   </LabelContainer>
                    <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom2Ref}
                    >
                    </DataForm>
                </CardContainer>
            </components.PageContainer>
        )
    }
    private renderDemandApprovalViewBox() {
        const { data } = this.state
        const { demandStatus } = data

        let theme: any
        switch(demandStatus) {
            case '4': theme = 'approved'; break;
            case '5': theme = 'rejected'; break;
            case '1': theme = 'inProgress'; break;
            default : theme = 'verify'; break;
        }
        return (
            <NotificationContainer
                className="padding-y"
                title="Demand Approval"
                theme={theme}
                status={demandStatus}
            >
                <div style={{...styles().input(demandStatus == 4 || demandStatus == 5)}}>
                <LabelContainer column={1} labelSpan={3} >
                    <LabelItem label="Reviewer:">
                        {data.demandCommentApprover}
                    </LabelItem>
                    <LabelItem label="Operation Date:">
                        {data.demandDate}
                    </LabelItem>
                    <LabelItem label="Comments:">
                        {data.demandCommentDesc}
                    </LabelItem>
                </LabelContainer>
                </div>
                <div className="flex-row justify-content-end">
                    <div
                        style={{
                            padding: 20
                        }}
                    >
                        <components.AuthDisableButton
                            type="primary"
                            htmlType="submit"
                            className="submit-button"
                            danger
                            size="large"
                            onClick={() => {
                                this.statusType = 'DEMAND'
                                this.demandStatus = '4'
                                this.openReviewModal()
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(
                                    data.demandStatus == '3'
                                ),
                            }}
                        >
                            Approve
                        </components.AuthDisableButton>
                    </div>
                    <div
                        style={{
                            padding: 20
                        }}
                    >
                        <components.AuthDisableButton
                            className="submit-button"
                            size="large"
                            onClick={() => {
                                this.statusType = 'DEMAND'
                                this.demandStatus = '5'
                                this.openReviewModal()
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(
                                    demandStatus == '3'
                                ),
                                width: 100
                            }}
                        >
                            Reject
                        </components.AuthDisableButton>
                    </div>
                </div>
            </NotificationContainer>
        )
    }

    private renderDesignApprovalViewBox() {
        const { data } = this.state
        const { demandStatus, designStatus } = data
        let theme: any
        switch(designStatus) {
            case '4': theme = 'approved'; break;
            case '5': theme = 'rejected'; break;
            case '1': theme = 'inProgress'; break;
            default : theme = 'verify'; break;
        }

        return (
            <NotificationContainer
                className="padding-y"
                title="Design Approval"
                theme={theme}
                status={designStatus}
            >
                <div style={{...styles().input(designStatus == 4 || designStatus == 5)}}>
                    <LabelContainer column={1} labelSpan={3}>
                        <LabelItem label="Reviewer:">
                            {data.designCommentApprover}
                        </LabelItem>
                        <LabelItem label="Operation Date:">
                            {data.designDate}
                        </LabelItem>
                        <LabelItem label="Comments:">
                            {data.designCommentDesc}
                        </LabelItem>
                    </LabelContainer>
                </div>
                <div className="flex-row justify-content-end">
                    <div
                        style={{
                            padding: 20
                        }}
                    >
                        <components.AuthDisableButton
                            type="primary"
                            htmlType="submit"
                            className="submit-button"
                            danger
                            size="large"
                            onClick={() => {
                                this.statusType = 'DESIGN'
                                this.demandStatus = '4'
                                this.openReviewModal()
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(
                                    demandStatus == 4 && designStatus == 3
                                ),

                            }}
                        >
                            Approve
                        </components.AuthDisableButton>
                    </div>
                    <div
                        style={{
                            padding: 20
                        }}
                    >
                        <components.AuthDisableButton
                            className="submit-button"
                            size="large"
                            onClick={() => {
                                this.statusType = 'DESIGN'
                                this.demandStatus = '5'
                                this.openReviewModal()
                            }}
                            auth={['ROLE_02']}
                            style={{
                                ...styles().input(
                                    demandStatus == 4 && designStatus == 3
                                ),
                                width: 100
                            }}
                        >
                            Reject
                        </components.AuthDisableButton>
                    </div>
                </div>
            </NotificationContainer>
        )
    }
    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    private get dataForm1(): DataForm {
        return this.dataFrom1Ref.current as DataForm
    }
    private get dataForm2(): DataForm {
        return this.dataFrom2Ref.current as DataForm
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand Detail -->"
                cancelText="Close"
                content="Check Status in Demand Detail Page."
                onOk={() => {
                    this.closeSuccessModal()
                    this.componentDidMount()
                    // this.props.history.push('/pages/api-demand-request-list')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }
    private renderReviewModal() {
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {/* {(this.staffId = userStore.state.staffId)} */}
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        Governance Group
                                    </LabelItem>
                                </LabelContainer>

                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{ required: true,
                                        type: 'string', max: 200, message: 'the length of approve comment should less then 200'
                                    },
                                ]}
                                >
                                    <Input/>
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private submitAction(staffId) {
        const { data } = this.state
        this.actionForm.formInstance.validateFields().then((...data1) => {
            this.demandService
                .status(
                    new RequestParams({
                        apiDemandIdList: [data.demandId],
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        status: this.demandStatus,
                        statusType: this.statusType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }
    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }

    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                apiCatalogueId
            }
        })
    }
    private discharge() {
        const { data } = this.state
        if (
            data.demandStatus == '3' ||
            data.demandStatus == '2' ||
            data.demandStatus == '1'
        ) {
            this.setState({
                discharge: false
            })
            if (data.demandClassification == '01') {
                this.setState({
                    discharge2: false
                })
            }
        }
    }
}
