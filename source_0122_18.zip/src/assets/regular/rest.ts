
export const rulesdata={
    messageOen:'Input only support Letter, Number, Space and "-"',
    messageTwo:'Input only support Letter, Number, Space',
    messageThree:'Input only support Letter, Number and Space.',
    messageNumbll:  'Input only support Number.',
    messagezM:  'Input only support Letter, Number and "-".',
    patternNum: /^\d+$/,
    patternOne: /^\w+[\w\s-]*$/,
    patternOneProjectName: /^\w+[\w\s-&()]*$/,
    messageGreater:  'Input only support ">0" and "<=100" Number.',
    // patternGreater: /^\d{1,2}([.]\d{1,2})?$/,
    patternGreater:/^100$|^(\d|[1-9]\d)(\.\d+)*$/,
    patternThree: /^[A-Z]+[-]\d+$/

}
export default rulesdata
