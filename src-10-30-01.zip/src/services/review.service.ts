/**
 * Review Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { ReviewController } from '~/config/services/review.controller'

export class ReviewService {
    /**
     * all
     */
    @Request({
        server: ReviewController.all
    })
    public all(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * commit review comment
     */
    @Request({
        server: ReviewController.comment
    })
    public comment(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * all
     */
    @Request({
        server: ReviewController.comments
    })
    public comments(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * download contract, response file stream
     */
    @Request({
        server: ReviewController.download
    })
    public download(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * approve review
     */
    @Request({
        server: ReviewController.status
    })
    public status(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * upload review and contract info
     */
    @Request({
        server: ReviewController.upload
    })
    public upload(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * get review detail
     */
    @Request({
        server: ReviewController.get
    })
    public get(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    /**
     * delete contract
     */
    @Request({
        server: ReviewController.deleteContract
    })
    public deleteContract(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    @Request({
        server: ReviewController.information
    })
    public information(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
