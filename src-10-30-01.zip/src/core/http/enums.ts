/**
 * request menthod
 */
export enum RequestMethod {
    Get = 'GET',
    Post = 'POST',
    Put = 'PUT',
    Delete = 'DELETE',
    Options = 'OPTIONS',
    Head = 'HEAD',
    Patch = 'PATCH'
}

/**
 * request state
 */
export enum RequestState {
    Ready, // 准备发送请求
    Loading // 请求发送中
}
