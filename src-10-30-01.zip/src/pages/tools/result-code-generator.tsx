import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { ToolsService } from '~/services/tools.service'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Upload,
    Button
} from 'antd'
import { ArrowDownOutlined, UploadOutlined } from '@ant-design/icons'
import DataForm from '~/shared/components/data-form'
import { RequestParams } from '~/core/http'
import { isNullOrUndefined } from 'util'
import { download } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'

const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})

const components = {
    PageContainer: styled(PageContainer)``
}

interface ResultGeneratorState {
    title: string
    functionType: string
    status: boolean
    result: any
}

interface ResultGeneratorProps {}

export default class ResultGenerator extends Component<
    RouteComponentProps<ResultGeneratorProps>,
    ResultGeneratorState
> {
    private toolsService = new ToolsService()
    constructor(props) {
        super(props)
        this.state = {
            title: '',
            functionType: '',
            status: false,
            result: {}
        }
    }

    public componentDidMount() {
        const { status, title, functionType } = this.props.location
            .state as ResultGeneratorState
        this.setState({
            status: status,
            functionType: functionType,
            title: title
        })
    }

    public render() {
        const { result } = this.props.location.state as ResultGeneratorState

        return this.renderForm(result)
    }
    public renderForm(result) {
        const { status, title, functionType } = this.state

        console.log(result)
        console.log(functionType)

        return (
            <components.PageContainer title={title}>
                <div
                    className="flex-row align-items-center"
                    style={{
                        ...styles().input(status != true),
                        paddingLeft: 20,
                        paddingTop: 30
                    }}
                >
                    <div>
                        <img
                            src={require('~/assets/images/modal-error.png')}
                            height="30px"
                        ></img>
                    </div>
                    <div
                        style={{
                            color: '#333333',
                            fontSize: 26,
                            fontWeight: 275,
                            paddingLeft: 20
                        }}
                    >
                        Error!
                    </div>
                </div>
                <div
                    className="flex-row align-items-center"
                    style={{
                        ...styles().input(status),
                        paddingLeft: 20,
                        paddingTop: 30
                    }}
                >
                    <div>
                        <img
                            src={require('~/assets/images/modal-success.png')}
                            height="30px"
                        ></img>
                    </div>
                    <div
                        style={{
                            color: '#333333',
                            fontSize: 26,
                            fontWeight: 275,
                            paddingLeft: 20
                        }}
                    >
                        Success!
                    </div>
                </div>
                <div className="flex-row align-items-center">
                    <div
                        style={{
                            color: '#333333',
                            fontSize: 15,
                            fontWeight: 275,
                            paddingLeft: 20,
                            paddingTop: 30,
                            paddingBottom: 10
                        }}
                    >
                        {result &&
                            result.message &&
                            result.message.map(m => {
                                return <div>{m}</div>
                            })}
                    </div>
                </div>
                <div style={styles().input(status)}>
                    <CardContainer title="Result">
                        <div
                            className="flex-row align-items-center"
                            style={styles().input(
                                !isNullOrUndefined(result.githubPath)
                            )}
                        >
                            <div>
                                <img
                                    src={require('~/assets/images/link.png')}
                                    height="20px"
                                ></img>
                            </div>
                            <Button
                                type="link"
                                className="text-left"
                                style={{ padding: 0 }}
                            >
                                {result.githubPath}
                            </Button>
                        </div>
                        <div
                            className="flex-row align-items-center"
                            style={{
                                ...styles().input(
                                    !isNullOrUndefined(result.outputPath)
                                ),
                                paddingTop: 30
                            }}
                        >
                            <div>
                                <img
                                    src={require('~/assets/images/file.png')}
                                    height="20px"
                                ></img>
                            </div>
                            <Button
                                type="link"
                                className="text-left"
                                style={{ padding: 0 }}
                                onClick={() => {
                                    download(
                                        appConfig.server +
                                            '/file/download?functionType=' +
                                            functionType +
                                            '&fileName=' +
                                            result.outputPath,
                                        result.outputPath
                                    )
                                }}
                            >
                                {result.outputPath}
                            </Button>
                        </div>
                    </CardContainer>
                </div>
                <div
                    className="flex-row justify-content-center"
                    style={{ paddingTop: 30 }}
                >
                    <Button
                        size="large"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.props.history.goBack()
                        }}
                    >
                        Back
                    </Button>
                </div>
            </components.PageContainer>
        )
    }
}
