import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { AccountService } from '~/services/account.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
const components = {
    PageContainer: styled(PageContainer)``
}

interface UserProfileState {
    data: any
}

interface UserProfileProps {}

export default class UserProfile extends Component<
    RouteComponentProps<UserProfileProps>,
    UserProfileState
> {
    private accountService = new AccountService()
    private dictUtil = new DictUtil()

    constructor(props) {
        super(props)
        this.state = {
            data: {}
        }
    }
    public render() {
        return (
            <Consumer of={UserStore}>
                {userStore => this.renderForm(userStore)}
            </Consumer>
        )
    }
    public renderForm(userStore) {
        this.accountService
            .userId(
                new RequestParams({}, { append: [userStore.state.staffId] })
            )
            .subscribe(data => {
                this.setState({
                    data: data
                })
            })
        const { data } = this.state

        return (
            <components.PageContainer title="User Profile">
                <CardContainer title="Basic Information">
                    <LabelContainer column={1} labelSpan={3}>
                        <LabelItem label="Staff ID">{data.staffId}</LabelItem>
                        <LabelItem label="Staff Name">{data.accName}</LabelItem>
                        <LabelItem label="Job Title"> {data.title}</LabelItem>
                        <LabelItem label="Department ">
                            {data.department}
                        </LabelItem>
                        <LabelItem label="E-mail">
                            {data.emailAddress}
                        </LabelItem>
                        <LabelItem label="Role">{this.renderRole()}</LabelItem>
                    </LabelContainer>
                </CardContainer>
            </components.PageContainer>
        )
    }

    private renderRole() {
        const { data } = this.state

        if (data?.accRType) {
            const { data } = this.state
            const l = data.accRType.toString().split(',')

            return (
                <div>
                    {l.map(x => (
                        <p key={x}>{this.dictUtil.filter('user_role', x)}</p>
                    ))}
                </div>
            )
        } else {
            return <></>
        }
    }
}
