require('../../modules/esnext.object.iterate-values');
var path = require('../../internals/path');

module.exports = path.Object.iterateValues;
