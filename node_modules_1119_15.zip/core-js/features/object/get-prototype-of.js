var parent = require('../../es/object/get-prototype-of');

module.exports = parent;
