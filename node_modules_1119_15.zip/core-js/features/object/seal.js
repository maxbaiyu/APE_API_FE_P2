var parent = require('../../es/object/seal');

module.exports = parent;
