var parent = require('../../es/object/is-sealed');

module.exports = parent;
