var parent = require('../../es/object/get-own-property-descriptors');

module.exports = parent;
