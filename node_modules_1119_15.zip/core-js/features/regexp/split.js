var parent = require('../../es/regexp/split');

module.exports = parent;
