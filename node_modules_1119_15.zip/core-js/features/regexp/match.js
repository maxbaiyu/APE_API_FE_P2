var parent = require('../../es/regexp/match');

module.exports = parent;
