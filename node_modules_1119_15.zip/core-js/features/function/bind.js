var parent = require('../../es/function/bind');

module.exports = parent;
