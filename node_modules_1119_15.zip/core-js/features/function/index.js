var parent = require('../../es/function');

module.exports = parent;
