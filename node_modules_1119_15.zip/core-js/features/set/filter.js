require('../../modules/es.set');
require('../../modules/esnext.set.filter');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Set', 'filter');
