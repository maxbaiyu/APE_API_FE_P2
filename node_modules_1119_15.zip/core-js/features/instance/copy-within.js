var parent = require('../../es/instance/copy-within');

module.exports = parent;
