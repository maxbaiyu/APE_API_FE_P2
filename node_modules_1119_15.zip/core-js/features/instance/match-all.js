// TODO: remove from `core-js@4`
require('../../modules/esnext.string.match-all');

var parent = require('../../es/instance/match-all');

module.exports = parent;
