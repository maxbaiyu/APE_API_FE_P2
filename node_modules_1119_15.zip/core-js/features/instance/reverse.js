var parent = require('../../es/instance/reverse');

module.exports = parent;
