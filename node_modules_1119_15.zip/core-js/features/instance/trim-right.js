var parent = require('../../es/instance/trim-right');

module.exports = parent;
