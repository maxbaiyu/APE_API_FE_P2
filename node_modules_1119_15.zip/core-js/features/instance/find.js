var parent = require('../../es/instance/find');

module.exports = parent;
