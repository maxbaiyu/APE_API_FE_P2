var parent = require('../../es/instance/slice');

module.exports = parent;
