var parent = require('../../es/instance/map');

module.exports = parent;
