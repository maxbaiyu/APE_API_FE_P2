require('../../modules/esnext.string.at');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'at');
