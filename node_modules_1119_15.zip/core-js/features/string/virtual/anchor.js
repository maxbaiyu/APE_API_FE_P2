var parent = require('../../../es/string/virtual/anchor');

module.exports = parent;
