var parent = require('../../../es/string/virtual/iterator');

module.exports = parent;
