var parent = require('../../es/string/match');

module.exports = parent;
