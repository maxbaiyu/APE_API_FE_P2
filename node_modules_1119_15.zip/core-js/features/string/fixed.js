var parent = require('../../es/string/fixed');

module.exports = parent;
