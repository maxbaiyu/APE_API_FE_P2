var parent = require('../../es/string/includes');

module.exports = parent;
