var parent = require('../../es/string/bold');

module.exports = parent;
