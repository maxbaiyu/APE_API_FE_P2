var parent = require('../../es/string/iterator');

module.exports = parent;
