var parent = require('../../es/string/code-point-at');

module.exports = parent;
