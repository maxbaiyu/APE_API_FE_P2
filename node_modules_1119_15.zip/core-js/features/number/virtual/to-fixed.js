var parent = require('../../../es/number/virtual/to-fixed');

module.exports = parent;
