var parent = require('../../es/number/parse-int');

module.exports = parent;
