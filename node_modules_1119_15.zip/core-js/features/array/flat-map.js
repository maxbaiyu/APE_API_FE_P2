var parent = require('../../es/array/flat-map');

module.exports = parent;
