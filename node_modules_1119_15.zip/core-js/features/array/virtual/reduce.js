var parent = require('../../../es/array/virtual/reduce');

module.exports = parent;
