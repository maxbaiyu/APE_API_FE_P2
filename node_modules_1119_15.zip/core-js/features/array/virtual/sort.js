var parent = require('../../../es/array/virtual/sort');

module.exports = parent;
