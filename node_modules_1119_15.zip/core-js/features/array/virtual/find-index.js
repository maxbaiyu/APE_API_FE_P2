var parent = require('../../../es/array/virtual/find-index');

module.exports = parent;
