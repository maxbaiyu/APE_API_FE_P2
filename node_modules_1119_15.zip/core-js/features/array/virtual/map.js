var parent = require('../../../es/array/virtual/map');

module.exports = parent;
