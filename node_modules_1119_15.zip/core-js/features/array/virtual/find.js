var parent = require('../../../es/array/virtual/find');

module.exports = parent;
