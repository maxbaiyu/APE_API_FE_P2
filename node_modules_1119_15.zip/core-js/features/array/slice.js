var parent = require('../../es/array/slice');

module.exports = parent;
