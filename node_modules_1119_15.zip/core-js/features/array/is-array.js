var parent = require('../../es/array/is-array');

module.exports = parent;
