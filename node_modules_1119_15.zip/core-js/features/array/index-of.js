var parent = require('../../es/array/index-of');

module.exports = parent;
