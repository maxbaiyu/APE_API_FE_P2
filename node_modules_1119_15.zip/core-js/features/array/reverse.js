var parent = require('../../es/array/reverse');

module.exports = parent;
