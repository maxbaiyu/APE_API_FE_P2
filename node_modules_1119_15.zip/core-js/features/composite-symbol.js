require('../modules/es.symbol');
require('../modules/esnext.composite-symbol');
var path = require('../internals/path');

module.exports = path.compositeSymbol;
