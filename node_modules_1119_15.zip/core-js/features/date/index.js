var parent = require('../../es/date');

module.exports = parent;
