require('../../modules/esnext.math.imulh');
var path = require('../../internals/path');

module.exports = path.Math.imulh;
