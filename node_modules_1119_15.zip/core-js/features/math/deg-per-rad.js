require('../../modules/esnext.math.deg-per-rad');

module.exports = Math.PI / 180;
