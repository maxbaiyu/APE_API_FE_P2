require('../../modules/esnext.math.degrees');
var path = require('../../internals/path');

module.exports = path.Math.degrees;
