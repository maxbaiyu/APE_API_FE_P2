import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { Form, Input, message, Button, Select } from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import StepContainer from '~/shared/components/step-container'
import StepItem from '~/shared/components/step-item'
import { truncate } from 'fs/promises'
import { DictUtil } from '~/shared/utils/dict.util'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'

const components = {
    PageContainer: styled.div`
        background-image: url('/images/home-page.png');
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        overflow: auto;
        background-size: auto 100%;
        background-position: center;
        background-repeat: no-repeat;
        display: flex;
        flex-direction: column;
        background-color: #36454e;
    `,
    AuthButton: styled(AuthWrapper(Button))``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface DashboardState {}

interface DashboardProps {}

export default class Dashboard extends Component<
    RouteComponentProps<DashboardProps>,
    DashboardState
> {
    private dictUtil = new DictUtil()

    constructor(props) {
        super(props)
    }

    public componentDidMount() {}

    public render() {
        return this.props.location.search ? (
            this.renderDashboard()
        ) : (
            <components.PageContainer></components.PageContainer>
        )
    }

    public renderDashboard() {
        return (
            <components.PageContainer>
                <CardContainer title="data-from-demo" theme="dark">
                    <DataForm
                        name="demo-form"
                        labelCol={{ span: 5 }}
                        labelAlign="left"
                        actions={this.renderFormAction()}
                    >
                        <DataForm.Item name="email" label="E-mail1">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail2">
                            <Select>
                                {this.dictUtil.dicts('backend_system', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail3">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail4">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail5">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail6">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail7">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail8">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail9" collapse>
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="email" label="E-mail10" collapse>
                            <Input />
                        </DataForm.Item>
                    </DataForm>
                </CardContainer>
                <CardContainer title="label-container-demo">
                    <LabelContainer column={2} labelSpan={3}>
                        <LabelItem label="字段标题">
                            {this.dictUtil.filter('backend_system', '01')}
                        </LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                        <LabelItem label="字段标题">测试内容</LabelItem>
                    </LabelContainer>
                </CardContainer>
            </components.PageContainer>
        )
    }

    private renderFormAction() {
        return (
            <>
                <Button type="primary" danger>
                    Search
                </Button>
                <components.AuthButton type="primary" danger auth={['ROLE_01']}>
                    Auth Test
                </components.AuthButton>
                <components.AuthDisableButton
                    type="primary"
                    danger
                    auth={['ROLE_02']}
                >
                    Disable Auth Test
                </components.AuthDisableButton>
            </>
        )
    }

    private onSubmit(data) {
        console.log(123)
        message.success('提交成功')
    }
}
