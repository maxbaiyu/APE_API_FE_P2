import { Observable, EMPTY, Subscriber } from 'rxjs'
import { RequestParams } from './request-params'
import { RequestOption } from './request-option'
import { IRequestServerConfig } from './interfaces'
import { RequestState } from './enums'
import { RequestService } from './request-service'
import { plainToClass } from 'class-transformer'
import UUID from 'uuidjs'

/**
 * Request Object
 */
export class RequestObject {
    // Request Object ID
    public readonly id

    // request Observable
    public readonly requestObservable

    // request Server
    public readonly requestServer: IRequestServerConfig

    // request Observer
    private requestObserver!: Subscriber<any>

    private responseModel

    // request state
    private requestState: RequestState = RequestState.Ready
    /**
     * constructor
     */
    constructor(requestServer: IRequestServerConfig) {
        // generate reqeust object id
        this.id = UUID.generate()
        // set request object
        this.requestServer = requestServer
        // set request Observable
        this.requestObservable = new Observable(observer => {
            // set request Observer
            this.requestObserver = observer
        })
    }

    /**
     * set reponse model
     * @param model
     */
    public setResponseModel(model) {
        this.responseModel = model
    }

    /**
     * send requst
     */
    public request(requestParams: RequestParams): Observable<any> {
        // if request object is free, send requst
        if (this.requestState === RequestState.Ready) {
            // hange http request state
            this.requestState = RequestState.Loading
            // new Request Option
            const requestOption = new RequestOption(
                this.requestServer,
                requestParams
            )

            // send http request
            RequestService.getInstance()
                .send(requestOption)
                .then((response: any) => {
                    // format data
                    let data

                    if (this.responseModel) {
                        data = plainToClass(this.responseModel, response)
                    } else {
                        data = response
                    }

                    // Extend
                    for (const service of requestParams.getExtendService()) {
                        const result =
                            service.after && service.after(data, requestParams)

                        if (result && result.override) {
                            data = result.data
                        }
                    }

                    // request complete success
                    this.requestObserver && this.requestObserver.next(data)
                    this.requestObserver && this.requestObserver.complete()
                })
                .finally(() => {
                    // reset request state
                    this.requestState = RequestState.Ready
                })
                .catch(({ response }) => {
                    // request error
                    this.requestObserver &&
                        this.requestObserver.error(response.data)
                })

            // return requestObservable
            return this.requestObservable
        } else {
            // request object running , wait for reqeust
            return EMPTY
        }
    }
}
