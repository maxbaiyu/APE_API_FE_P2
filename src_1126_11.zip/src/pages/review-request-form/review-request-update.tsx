import React, { Component } from 'react'
import styled, { keyframes } from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { DownOutlined } from '@ant-design/icons';
import {
    Form,
    Input,
    Select,
    Table,
    Divider,
    Button,
    Avatar,
    Modal,
    List,
    message
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { InboxOutlined, UserOutlined } from '@ant-design/icons'
import NotificationContainer from '~/shared/components/notification-container'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import { DictUtil } from '~/shared/utils/dict.util'
import Dragger from 'antd/lib/upload/Dragger'
import appConfig from '~/config/app.config'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import ReplyCommont from '~/components/reply-commont'
import { download } from '~/shared/utils/common.util'
import { isNullOrUndefined } from 'util'
import { FormInstance } from 'antd/lib/form'
import 'braft-editor/dist/index.css'
import BraftEditor from 'braft-editor'
import Item from 'antd/lib/list/Item'

const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

const { TextArea } = Input

interface ReviewRequestUpdateState {
    id: string
    data: any
    dataSource: any[]
    reviewModalVisible: boolean
    successModalVisible: boolean
    applicableChannelsSpecficDisplay: boolean
    applicableCountriesSpecficDisplay: boolean
    applicableGbSpecficDisplay: boolean
    contractInformationStatus: boolean
    commontsTree: any
    show:boolean
    uploadStatus:boolean
    fileList: any[]
}

interface ReviewRequestUpdateProps {}

export default class ReviewRequestUpdate extends Component<
    RouteComponentProps<ReviewRequestUpdateProps>,
    ReviewRequestUpdateState
> {
    private dataFromRef!: React.RefObject<DataForm>

    private reviewService = new ReviewService()
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private contractInformationFromRef!: React.RefObject<DataForm>
    private reviewType = ''
    private reviewStatus = ''
    private file: File
    private formRef = React.createRef<FormInstance>()

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.actionFromRef = React.createRef()
        this.contractInformationFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            dataSource: [],
            reviewModalVisible: false,
            successModalVisible: false,
            applicableChannelsSpecficDisplay: false,
            applicableCountriesSpecficDisplay: false,
            applicableGbSpecficDisplay: false,
            contractInformationStatus: false,
            commontsTree: [],
            show:false,
            fileList:[],
            uploadStatus:true

        }
    }

    public componentDidMount() {
        const { id } = this.props.location.state as ReviewRequestUpdateState

        this.getReview()
        this.getComments()
    }

    private getReview() {
        const { id } = this.props.location.state as ReviewRequestUpdateState

        this.reviewService
            .get(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    data: data,
                    dataSource: data.contracts,
                    contractInformationStatus:
                        data.gbdrReviewStatus > 3 ||
                        data.gtdrReviewStatus > 3 ||
                        data.rdrReviewStatus > 3,
                    applicableChannelsSpecficDisplay:
                        data.applicableChannels === '04',
                    applicableCountriesSpecficDisplay:
                    data.applicableCountries === '02' ||
                    data.applicableCountries === '03' ||
                    data.applicableCountries === '04',
                    applicableGbSpecficDisplay:
                    data.applicableGbGf === '04',
                })
                this.contractInformationFrom.formInstance.setFieldsValue(data)
            })
    }

    private getComments() {
        const { id } = this.props.location.state as ReviewRequestUpdateState

        this.reviewService
            .comments(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                const action = node => {
                    const children = data.filter(
                        x => x.parentId === node.commentId
                    )
                    node.children = children
                    children.length && children.forEach(action)
                    return node
                }

                const tree = data.filter(x => !x.parentId).map(action)
                this.setState({
                    commontsTree: tree
                })
            })
    }
    private openEdit() {
        const ids  = this.props.location.state as ReviewRequestUpdateState
        this.props.history.push({
            pathname: '/pages/review-request-edit',
            state: {
                id: ids.id
            }
        })
    }
    public render() {
        const { data } = this.state

        return (
            <components.PageContainer title="Contract Update"  noHeader={true}>
                {/* {this.renderPageHeader()} */}
                <div
                    // className="flex-row justify-content-end"
                    className="flex-row justify-content-between"
                    style={{ paddingTop: 10 }}
                >
                      <div   style={{ fontSize: 28,marginLeft: 20}}>{data.apiName}</div>
                      <div>
                      {/* <Button
                       type="primary"
                        size="large"
                        style={{
                            marginRight:20,
                        }}
                        onClick={() => {
                            this.openEdit()
                        }}
                    >
                        Edit
                    </Button> */}
                      <Button
                        size="large"
                        onClick={() => {
                            this.props.history.goBack()
                        }}
                    >
                        Back
                    </Button> 
                      </div>
                </div>
                {/* <Divider /> */}
                {this.renderContractInformation()}
            </components.PageContainer>
        )
    }
    private sumbmitComment(data, values, userStore) {
        let request = {
            commentatorStaffId: userStore.state.staffId,
            comments: values.comments,
            reviewId: data.reviewId
        }
        this.reviewService
            .comment(new RequestParams(request))
            .subscribe(data => {
                this.getComments()
                message.success('Comment Submitted')
                //this.formRef && this.formRef?.current?.resetFields()
                this.formRef?.current?.resetFields()
            })
    }
    private renderContractInformation() {
        const {
            applicableChannelsSpecficDisplay,
            applicableCountriesSpecficDisplay,
            applicableGbSpecficDisplay,
            contractInformationStatus
        } = this.state

        const testData = {
            reviewId: 1,
            applicableChannels: '1'
        }
        const fileListany=[]

        const uploadProps = {
            name: 'file',
            multiple: false,
            action: appConfig.server + '/review/upload',
            data: testData,
            fileList:this.state.fileList,
            beforeUpload: file => {
                this.file = file
                return false
            },
            onChange:info=> {
                let fileList = info.fileList
                fileList = fileList.slice(-1);
                // this.fileList
                this.setState({ fileList:fileList });
                const { status } = info.file

                if (status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully.`
                    )
                } else if (status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            },
        }
        const columns = [
            {
                title: 'Documents',
                dataIndex: 'contractName',
                render: (text, record) => (
                    <Button
                        type="link"
                        className="text-left"
                        onClick={() => {
                            download(
                                appConfig.server +'review/download?fileName=' +text,
                                text
                            )
                        }}
                    >
                        {text}
                    </Button>
                )
            },
            {
                title: 'Upload Date',
                dataIndex: 'createDate'
            },
            {
                title: 'Upload Person',
                dataIndex: 'accName'
            },
            {
                title: 'Delete ',
                render: (text, record) => (
                    <components.AuthDisableButton
                        onClick={() => this.deleteContract(record)}
                        auth={['ROLE_01']}
                    >
                        Delete
                    </components.AuthDisableButton>
                )
            }
        ]

        const { dataSource,data,uploadStatus} = this.state
        return (
            <CardContainer title="Contract Information">
                <div   className="flex-row justify-content-between">
                </div>
                   
                {/* <LabelContainer column={2} labelSpan={3}>
                      <LabelItem label="API Version">
                          {data.version}
                        </LabelItem>
                        <LabelItem label="Applicable Channels">
                        {data.applicableChannels}
                        </LabelItem>
                        <LabelItem label="Applicable GB/GF">
                        {data.applicableGb}
                        </LabelItem>
                        <LabelItem label="Applicable Countries">
                        {data.applicableCountries}
                        </LabelItem>
                        <LabelItem label="Reusability Score">
                        {data.reusabilityScore}
                        </LabelItem>
                </LabelContainer> */}
                <DataForm
                    name="contractInformationFrom"
                    ref={this.contractInformationFromRef}
                    column={2}
                    labelCol={{ span: 8 }}
                    labelAlign="left"
                >
                   <DataForm.Item name="version" label="API Version">
                        <Input disabled={contractInformationStatus} />
                    </DataForm.Item>
                    <LabelItem></LabelItem>
                    <DataForm.Item
                        name="applicableChannels"
                        label="Applicable Channels"
                    >
                        <Select
                            onChange={value => {
                                if (value === '04') {
                                    this.setState({
                                        applicableChannelsSpecficDisplay: true
                                    })
                                } else {
                                    this.setState({
                                        applicableChannelsSpecficDisplay: false
                                    })
                                    this.contractInformationFrom.formInstance.setFieldsValue({'applicableChannels2':''})
                                }
                            }}
                            disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts(
                                'applicable_channels',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="applicableChannels2"
                        style={styles().input(applicableChannelsSpecficDisplay)}
                    >
                        <Input
                            style={{ width: 280 }}
                            disabled={contractInformationStatus}
                        />
                    </DataForm.Item>
                    <DataForm.Item name="applicableGbGf" label="Applicable GB/GF">
                        <Select
                            onChange={value => {
                                if (value === '04') {
                                    this.setState({
                                        applicableGbSpecficDisplay: true
                                    })
                                } else {
                                    this.setState({
                                        applicableGbSpecficDisplay: false
                                    })
                                    this.contractInformationFrom.formInstance.setFieldsValue({'applicableGbGf2':''})
                                }
                            }}
                            disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts('applicable_gb', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="applicableGbGf2"
                        style={styles().input(applicableGbSpecficDisplay)}
                    >
                        <Input
                            style={{ width: 280 }}
                            disabled={contractInformationStatus}
                        />
                    </DataForm.Item>
                    <DataForm.Item
                        name="applicableCountries"
                        label="Applicable Countries"
                    >
                        <Select
                            onChange={value => {
                                if (
                                    value === '02' ||
                                    value === '03' ||
                                    value === '04'
                                ) {
                                    this.setState({
                                        applicableCountriesSpecficDisplay: true
                                    })
                                } else {
                                    this.setState({
                                        applicableCountriesSpecficDisplay: false
                                    })
                                    this.contractInformationFrom.formInstance.setFieldsValue({'applicableCountries2':''})
                                }
                            }}
                            disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts(
                                'applicable_countries',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="applicableCountries2"
                        style={styles().input(
                            applicableCountriesSpecficDisplay
                        )}
                    >
                        <Input
                            style={{ width: 280 }}
                            disabled={contractInformationStatus}
                        />
                    </DataForm.Item>
                    <DataForm.Item
                        name="reusabilityScore"
                        label="Reusability Score"
                    >
                        <Select 
                        disabled={contractInformationStatus}
                        >
                            {this.dictUtil.dicts('reusability_score', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <LabelItem></LabelItem>
                    <DataForm.Item name="commentDesc" label="Contract Comment">
                        <Input 
                        disabled={contractInformationStatus}
                         />
                    </DataForm.Item>
                    <LabelItem></LabelItem>
                </DataForm>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    size="small"
                    rowKey="contractId"
                    pagination={false}
                    expandable={{
                        expandedRowRender: record => <p style={{ margin: 0 }}>{record.commentDesc}</p>,
                      }}
                />
                <Dragger
                    {...uploadProps}
                    style={styles().input(!contractInformationStatus)}
                >
                    <p className="ant-upload-drag-icon">
                        <InboxOutlined />
                    </p>
                    <p className="ant-upload-text">
                        Click or drag file to this area to upload
                    </p>
                    <p className="ant-upload-hint">
                        Support for a single or bulk upload. Strictly prohibit
                        from uploading company data or other band files
                    </p>
                </Dragger>
                {this.renderModal()}
                <div className="flex-row justify-content-end padding-y">
                    <components.AuthDisableButton
                        type="primary"
                        htmlType="submit"
                        className="submit-button"
                        size="large"
                        style={styles().input(!contractInformationStatus)}
                        onClick={() => {
                            if (isNullOrUndefined(this.file)) {
                                message.error(
                                    'Please upload contract before you submit.'
                                )
                                return
                            }
                            const formData = new FormData()
                            formData.append('file', this.file)
                            formData.append(
                                'reviewId',
                                this.state.data.reviewId === null
                                    ? ''
                                    : this.state.data.reviewId
                            )
                            formData.append(
                                'versionId',
                                this.state.data.versionId === null
                                    ? ''
                                    : this.state.data.versionId
                            )
                            const data = this.contractInformationFrom.formInstance.getFieldsValue()
                            for(let i=0;i<dataSource.length;i++){
                                if(dataSource[i].contractName==this.file.name){
                                    this.setState({},()=>{
                                        message.error('Duplicated documents cannot be submitted,please check again.')
                                    })
                                    return
                                }
                            }
                            if(uploadStatus){
                            Object.entries(
                                data
                            ).forEach(([key, value]: [string, any]) =>
                                formData.append(key, value || '')
                            )
                            const STORAGE_KEY = 'react-storage'
                            const storageData = JSON.parse(
                                localStorage.getItem(STORAGE_KEY) || '{}'
                            )
                            this.reviewService
                                .upload(
                                    new RequestParams(formData, {
                                        header: {
                                            'Content-Type':
                                                'multipart/form-data',
                                            Authorization:
                                                storageData.user.token
                                        }
                                    })
                                )
                                .subscribe(data => {
                                    this.openSuccessModal()
                                })
                            }
                         
                          
                        }}
                        auth={['ROLE_01']}
                    >
                        Submit
                    </components.AuthDisableButton>
                </div>
            </CardContainer>
        )
    }
    private deleteContract(record) {
        this.reviewService
            .deleteContract(
                new RequestParams({}, { append: [record.contractId] })
            )
            .subscribe(data => {
                message.success('contract delete success')

                this.getReview()
            })
    }

 

  

   

    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }

    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Review Request Form -->"
                cancelText="Close"
                content="Check information in Review Request Form."
                onOk={() => {
                    this.props.history.goBack()
                    // this.closeSuccessModal()
                    // this.props.history.push('/pages/review-request-form')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private get contractInformationFrom(): DataForm {
        return this.contractInformationFromRef.current as DataForm
    }

    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    // private openForm(apiCatalogueId) {
    //     this.props.history.push({
    //         pathname: '/pages/api-catalogue/api-detail',
    //         state: {
    //             id: apiCatalogueId
    //         }
    //     })
    // }
}
