import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import DataTable from '~/shared/components/data-table'
import Column from 'antd/lib/table/Column'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { download } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'
import {
    Modal,
    Form,
    Input,
    Select,
    DatePicker,
    Button,
    Divider,
    message
} from 'antd'
import dataSource from '~/assets/mock/api-data.json'
import LabelContainer from '~/shared/components/label-contaoner'
import ColumnGroup from 'antd/lib/table/ColumnGroup'
import CustomizeModal from '~/shared/components/customize-modal'
import { DemandService } from '~/services/demand.service'
import { PageService } from '~/bootstrap/services/page.service'
import { RequestParams } from '~/core/http'
import LabelItem from '~/shared/components/label-item'
import { DictUtil } from '~/shared/utils/dict.util'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { SortService } from '~/bootstrap/services/sort.service'
import { reduce } from 'ramda'
const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface APIDemandRequestListState {
    dataSource: any[]
    selectedRowKeys: any[]
    successModalVisible: boolean
    reviewModalVisible: boolean
}

interface APIDemandRequestListProps {}

export default class APIDemandRequestList extends Component<
    RouteComponentProps<APIDemandRequestListProps>,
    APIDemandRequestListState
> {
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private demandService = new DemandService()
    private pageService = new PageService()
    private sortService = new SortService({
        createDate: 'DESC'
    })
    private statusType = ''
    private demandStatus = ''
    private searchFormRef!: React.RefObject<DataForm>
    // private commontFormRef!: React.RefObject<Form>

    constructor(props) {
        super(props)
        this.actionFromRef = React.createRef()
        this.searchFormRef = React.createRef()
        // this.commontFormRef = React.createRef()

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            successModalVisible: false,
            reviewModalVisible: false
        }
    }
    public componentDidMount() {
        this.getDemandList()
    }
    public render() {
        return (
            <components.PageContainer title="API Demand Request List"  noHeader={true}>
                {this.renderFormContainer()}
                {this.renderTableContainer()}
                {this.renderModal()}
                {this.renderReviewModal()}
            </components.PageContainer>
        )
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand List -->"
                cancelText="Close"
                content="Check Status in Demand List."
                onOk={() => {
                    this.closeSuccessModal()
                    this.getDemandList()
                    this.setState({
                        selectedRowKeys: []
                    })
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    public renderFormContainer() {
        const { RangePicker } = DatePicker
        return (
            <CardContainer title="Search">
                <DataForm
                    name="search-form"
                    column={3}
                    labelCol={{ span: 11 }}
                    labelAlign="left"
                    actions={this.renderFormAction()}
                    ref={this.searchFormRef}
                >
                    <DataForm.Item name="projectName" label="Project Name">
                        <Input />
                    </DataForm.Item>
                    <DataForm.Item
                        name="cbApiContract"
                        label="Core Banking API Contact"
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('cb_api_contact', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="demandApprovalStatus"
                        label="Demand Approval Status"
                        initialValue=""
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'design_review_status',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="targetLiveDate"
                        label="Target Live Date"
                        className="range-picker"
                    >
                        <RangePicker />
                    </DataForm.Item>
                    <DataForm.Item
                        name="cbSystemContract"
                        label="Core Banking System Contact"
                        initialValue=""
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('cb_system_contact', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="designApprovalStatus"
                        label="Design Approval Status"
                        initialValue=""
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'design_review_status',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item name="apiName" label="API Name" collapse>
                        <Input />
                    </DataForm.Item>
                    <DataForm.Item name="requester" label="Requester" collapse>
                        <Input />
                    </DataForm.Item>
                    <DataForm.Item
                        name="designReviewApprovalStatus"
                        label="Design Review Status"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'design_review_status',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="demandClassification"
                        label="Demand Classification"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('api_classification', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="country"
                        label="Site"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('country', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="demandApprovalDate"
                        label="Demand Approval Date"
                        className="range-picker"
                        collapse
                    >
                        <RangePicker renderExtraFooter={() => 'extra footer'} />
                    </DataForm.Item>
                    <DataForm.Item
                        name="channel"
                        label="Channel"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('channel', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="designApprovalDate"
                        label="Design Approval Date"
                        className="range-picker"
                        collapse
                    >
                        <RangePicker />
                    </DataForm.Item>
                    <DataForm.Item
                        name="apiLifecycleStage"
                        label="API Lifecycle Stage"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'api_lifecycle_stage',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="gbOrGF"
                        label="GB/GF"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('gb_gf', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="designReviewApprovalDate"
                        label="Design Review Date"
                        className="range-picker"
                        collapse
                    >
                        <RangePicker />
                    </DataForm.Item>
                    <DataForm.Item name="apiId" label="API ID" collapse>
                        <Input />
                    </DataForm.Item>
                    <DataForm.Item
                        name="platform"
                        label="Platform"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('platform', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="backendSystem"
                        label="Backend System"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('backend_system', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="originalSapiId"
                        label="Original API ID"
                        collapse
                    >
                        <Input />
                    </DataForm.Item>
                </DataForm>
            </CardContainer>
        )
    }

    public renderTableContainer() {
        const { dataSource, selectedRowKeys } = this.state
        return (
            <CardContainer title="API Demand List">
                     <Button
                        size="large"
                        style={{
                            marginTop:-75,
                            float:'right'
                        }}
                        onClick={() => {
                            download(
                                appConfig.server +'/demand/export','API-Demand-Request-List.xls'
                            )
                        }}
                    >
                        Export
                    </Button>
                <DataTable
                    dataSource={dataSource}
                    page={this.pageService}
                    onPageChange={() => this.getDemandList()}
                    rowSelection={{
                        selectedRowKeys,
                        onChange: selectedRowKeys =>
                            this.setState({ selectedRowKeys })
                    }}
                    rowKey="demandId"
                    actions={this.renderTableAction()}
                    onChange={(pagination, filters, sorter) => {
                        if (sorter.order) {
                            this.sortService.update(
                                sorter.columnKey,
                                sorter.order
                            )
                        } else {
                            this.sortService.reset()
                        }
                        this.getDemandList()
                    }}
                >
                    <ColumnGroup title="Demand Governance" className="red">
                        {/*} <Column
                            title="Demand ID"
                            dataIndex="demandId"
                            key="demandId"
                            ellipsis={true}
                            render={(text, row, index) => (
                                <Button
                                    type="link"
                                    onClick={() => this.openForm(row)}
                                >
                                    {text}
                                </Button>
                            )}
                            />*/}
                        <Column
                            title="Entry Creation Date"
                            dataIndex="createDate"
                            key="createDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Order Receive Date"
                            dataIndex="receivedDate"
                            key="receivedDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Project Name"
                            dataIndex="projectName"
                            key="projectName"
                            ellipsis={true}
                            sorter
                        />

                        <Column
                            title="API Name"
                            dataIndex="apiName"
                            key="apiName"
                            ellipsis={true}
                            sorter
                            render={(text, row, index) => (
                                <Button
                                    type="link"
                                    onClick={() => this.openForm(row)}
                                >
                                    {text}
                                </Button>
                            )}
                        />
                        <Column
                            title="Site"
                            dataIndex="country"
                            key="country"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('country', value)
                            }
                        />
                        <Column
                            title="Backend System"
                            dataIndex="backEndSystem"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('backend_system', value)
                            }
                        />
                        <Column
                            title="Channel"
                            dataIndex="channel"
                            key="channel"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('channel', value)
                            }
                        />
                        <Column
                            title="Consumer"
                            dataIndex="consumer"
                            key="consumer"
                            ellipsis={true}
                        />
                        <Column
                            title="Requester"
                            dataIndex="requester"
                            key="requester"
                            ellipsis={true}
                        />
                        <Column
                            title="Core Banking API Contact"
                            dataIndex="cbApiContact"
                            key="cbApiContact"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('cb_api_contact', value)
                            }
                        />

                        <Column
                            title="Core Banking System Contact"
                            dataIndex="cbSysContact"
                            key="cbSysContact"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('cb_system_contact', value)
                            }
                        />
                        <Column
                            title="GB/GF"
                            dataIndex="gbOrGF"
                            key="gbOrGF"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('gb_gf', value)
                            }
                        />
                        <Column
                            title="Multi-Site"
                            dataIndex="multiCountry"
                            key="multiCountry"
                            ellipsis={true}
                        />
                        <Column
                            title="API Lifecycle Stage"
                            dataIndex="apiLifecycleStage"
                            key="apiLifecycleStage"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'api_lifecycle_stage',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Target Live Date"
                            dataIndex="targetLiveDate"
                            key="targetLiveDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Total API L0 Estimates"
                            dataIndex="totalApiL0Estimates"
                            key="totalApiL0Estimates"
                            ellipsis={true}
                        />

                        <Column
                            title="Mule API L0 Estimates"
                            dataIndex="ossApiL0Estimates"
                            key="ossApiL0Estimates"
                            ellipsis={true}
                        />
                        <Column
                            title="CB System L0 Estimates"
                            dataIndex="cbSystemL0Estimates"
                            key="cbSystemL0Estimates"
                            ellipsis={true}
                        />
                        <Column
                            title="BPID"
                            dataIndex="gdpmInterLockBpid"
                            key="gdpmInterLockBpid"
                            ellipsis={true}
                        />

                        <Column
                            title="Demand Approval Status"
                            dataIndex="demandStatus"
                            key="demandStatus"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'design_review_status',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Demand Approval Date"
                            dataIndex="demandDate"
                            key="demandDate"
                            ellipsis={true}
                            sorter
                        />
                    </ColumnGroup>
                    <ColumnGroup title="Design Governance" className="green">
                        <Column
                            title="Capability"
                            dataIndex="capability"
                            key="capability"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('capability', value)
                            }
                        />
                        <Column
                            title="Feature"
                            dataIndex="feature"
                            key="feature"
                            ellipsis={true}
                            render={(text,record:any) =>
                                this.dictUtil.filter(record.capability, text)
                            }
                        />
                        <Column
                            title="Service"
                            dataIndex="service"
                            key="service"
                            ellipsis={true}
                            render={(text,record:any) =>
                                this.dictUtil.filter(record.feature, text)
                            }
                        />
                        <Column
                            title="Platform"
                            dataIndex="platform"
                            key="platform"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('platform', value)
                            }
                        />
                              <Column
                            title="API Type"
                            dataIndex="apiType"
                            key="apiType"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('api_type', value)
                            }
                        />
                        <Column
                            title="Channel Agnostic"
                            dataIndex="channelAgnostic"
                            key="channelAgnostic"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('channel_agnostic', value)
                            }
                        />
                        <Column
                            title="Demand Classification"
                            dataIndex="demandClassification"
                            key="demandClassification"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'api_classification',
                                    value
                                )
                            }
                        />
                                    <Column
                            title="Reusability Score"
                            dataIndex="reusabilityScore"
                            key="reusabilityScore"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('reusability_score', value)
                            }
                        />
                        <Column
                            title="API ID"
                            dataIndex="trueSapiId"
                            key="trueSapiId"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Original API ID"
                            dataIndex="originalSapiId"
                            key="originalSapiId"
                            ellipsis={true}
                        />
                        <Column
                            title="Design Review Status"
                            dataIndex="designReviewStatus"
                            key="designReviewStatus"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'design_review_status',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Design Review Date"
                            dataIndex="designReviewDate"
                            key="designReviewDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Design Approval Status"
                            dataIndex="designStatus"
                            key="designStatus"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'design_review_status',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Design Approval Date"
                            dataIndex="designDate"
                            key="designDate"
                            ellipsis={true}
                            sorter
                        />
                    </ColumnGroup>
                </DataTable>
            </CardContainer>
        )
    }

    private renderTableAction() {
        return (
            <LabelContainer column={3} colon>
                <LabelContainer.Item label="Demand Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DEMAND'
                            this.demandStatus = '4'
                            this.openReviewModal()
                        }}
                        auth={['ROLE_02']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DEMAND'
                            this.demandStatus = '5'
                            this.openReviewModal()
                        }}
                        auth={['ROLE_02']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
                <LabelContainer.Item label="Design Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DESIGN'
                            this.demandStatus = '4'
                            this.openReviewModal()
                        }}
                        auth={['ROLE_02']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DESIGN'
                            this.demandStatus = '5'
                            this.openReviewModal()
                        }}
                        auth={['ROLE_02']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
            </LabelContainer>
        )
    }
    private renderReviewModal() {
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        Governance Group
                                    </LabelItem>
                                </LabelContainer>

                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }

    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }
    private openForm(row) {
        this.props.history.push({
            // pathname: '/pages/demand-request-form-detail',
            pathname: '/pages/demand-request-form-exhibition',
            state: {
                id: row.demandId
            }
        })
    }
    private submitAction(staffId) {
        const { selectedRowKeys } = this.state

        this.actionForm.formInstance.validateFields().then((...data) => {
            this.demandService
                .status(
                    new RequestParams({
                        apiDemandIdList: selectedRowKeys,
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        status: this.demandStatus,
                        statusType: this.statusType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openReviewModal() {
        const { selectedRowKeys, dataSource } = this.state
        let selectedRow = dataSource.filter(e => {
            return (
                selectedRowKeys.indexOf(e.demandId) === 0 ||
                selectedRowKeys.indexOf(e.demandId) > 0
            )
        })
        //这里如果需要判断是Demand  还是 Design  的话 用this.statusType 判断
        if (this.statusType === 'DEMAND') {
            if (selectedRow.some(data => data.demandStatus !== '3')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        } else {
            if (selectedRow.some(data => data.demandStatus !== '4')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }

            if (
                selectedRow.some(data => data.demandStatus === '4') &&
                selectedRow.some(data => data.designStatus !== '3')
            ) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        }

        if (selectedRowKeys.length == 0) {
            message.error('Please select at least one data')
            return
        }
        this.setState({
            reviewModalVisible: true
        })
    }
    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private renderFormAction() {
        return (
            <Button type="primary" danger onClick={() => this.getDemandList()}>
                Search
            </Button>
        )
    }

    private getDemandList() {
        let targetLiveDate = ''
        if (this.searchForm.formInstance.getFieldsValue().targetLiveDate) {
            targetLiveDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .targetLiveDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .targetLiveDate[1].format('MM/DD/YYYY')
        }

        let demandApprovalDate = ''
        if (this.searchForm.formInstance.getFieldsValue().demandApprovalDate) {
            demandApprovalDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .demandApprovalDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .demandApprovalDate[1].format('MM/DD/YYYY')
        }

        let designApprovalDate = ''
        if (this.searchForm.formInstance.getFieldsValue().designApprovalDate) {
            designApprovalDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designApprovalDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designApprovalDate[1].format('MM/DD/YYYY')
        }

        let designReviewApprovalDate = ''
        if (
            this.searchForm.formInstance.getFieldsValue()
                .designReviewApprovalDate
        ) {
            designReviewApprovalDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designReviewApprovalDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designReviewApprovalDate[1].format('MM/DD/YYYY')
        }

        this.demandService
            .all(
                new RequestParams(
                    Object.assign(
                        this.searchForm.formInstance.getFieldsValue(),
                        {
                            targetLiveDate: targetLiveDate,
                            designApprovalDate: designApprovalDate,
                            demandApprovalDate: demandApprovalDate,
                            designReviewApprovalDate: designReviewApprovalDate
                        }
                    ),
                    {
                        page: this.pageService,
                        sort: this.sortService
                    }
                )
            )
            .subscribe(data => {
                this.setState({
                    dataSource: data
                })
            })
    }

    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private get searchForm(): DataForm {
        return this.searchFormRef.current as DataForm
    }
}
