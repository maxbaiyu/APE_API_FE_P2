import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { ToolsService } from '~/services/tools.service'
import {
    Form,
    Input,
    InputNumber,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Upload,
    message,
    Button
} from 'antd'
import { ArrowDownOutlined, UploadOutlined } from '@ant-design/icons'
import DataForm from '~/shared/components/data-form'
import { RequestParams } from '~/core/http'
import appConfig from '~/config/app.config'
import { FileService } from '~/services/file.service'
import { isNullOrUndefined } from 'util'

const components = {
    PageContainer: styled(PageContainer)``
}

interface RamlGeneratorState {
    contractPath: string
}

interface RamlGeneratorProps {}

export default class RamlGenerator extends Component<
    RouteComponentProps<RamlGeneratorProps>,
    RamlGeneratorState
> {
    private dataFromRef!: React.RefObject<DataForm>
    private toolsService = new ToolsService()
    private fileService = new FileService()

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.state = {
            contractPath: ''
        }
    }

    public render() {
        return (
            <Consumer of={UserStore}>
                {userStore => this.renderForm(userStore)}
            </Consumer>
        )
    }
    public renderForm(userStore) {
        const uploadProps = {
            name: 'file',
            action: appConfig.server + '/file/upload',
            beforeUpload: file => {
                this.uploadFile(file)
                return false
            },
            onChange(info) {
                if (info.file.status !== 'uploading') {
                }
                if (info.file.status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully`
                    )
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }

        return (
            <components.PageContainer title="RAML Generator"  noHeader={true}>
                <CardContainer title="Contract Upload">
                    <DataForm
                        name="contractPath"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                    >
                        <Form.Item>
                            <Upload {...uploadProps}>
                                <Button
                                    style={{
                                        width: 300,
                                        textAlign: 'center'
                                    }}
                                >
                                    <UploadOutlined /> Browse
                                </Button>
                            </Upload>
                        </Form.Item>
                    </DataForm>
                </CardContainer>
                <CardContainer title="API Information">
                    <DataForm
                        name="demo-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                        ref={this.dataFromRef}
                    >
                        <Form.Item
                            name="sapiName"
                            label="SAPI Name"
                            rules={[{ required: true }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="contractVersion"
                            label="Version"
                            rules={[{ required: true }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="method"
                            label="API Method"
                            rules={[{ required: true }]}
                        >
                            <Select>
                                <Select.Option value="GET">GET</Select.Option>
                                <Select.Option value="POST">POST</Select.Option>
                                <Select.Option value="PUT">PUT</Select.Option>
                                <Select.Option value="DELETE">
                                    DELETE
                                </Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="description"
                            label="Description"
                            rules={[{ required: true }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="path"
                            label="PATH"
                            rules={[{ required: true }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="successHttpCode"
                            label="Success Code"
                            rules={[{ required: true }]}
                        >
                            <InputNumber />
                        </Form.Item>
                        <Form.Item
                            name="githubUploadFlag"
                            label="Upload to GitHub"
                            rules={[{ required: true }]}
                        >
                            <Select>
                                <Select.Option value="Y">Yes</Select.Option>
                                <Select.Option value="N">No</Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item name="githubBranch" label="Github Branch">
                            <Input />
                        </Form.Item>
                    </DataForm>
                    <Divider />
                    <div
                        style={{ width: '100%' }}
                        className="flex-row justify-content-end"
                    >
                        <Button
                            type="primary"
                            size="large"
                            danger
                            onClick={() => this.submit()}
                        >
                            Submit
                        </Button>
                    </div>
                </CardContainer>
            </components.PageContainer>
        )
    }

    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }

    private uploadFile(file) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('functionType', 'RAML')
        this.fileService
            .upload(
                new RequestParams(formData, {
                    header: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
            )
            .subscribe(data => {
                message.success('upload file success!')
                this.setState({
                    contractPath: data.filePath
                })
            })
    }

    private submit() {
        const { contractPath } = this.state
        if (contractPath === '') {
            message.error('Please upload contract.')
        } else {
            this.dataForm.formInstance.validateFields().then((...data1) => {
                this.toolsService
                    .raml(
                        new RequestParams({
                            ...this.dataForm.formInstance.getFieldsValue(),
                            contractPath: contractPath
                        })
                    )
                    .subscribe(
                        data => {
                            this.props.history.push({
                                pathname: '/pages/tools/result-code-generator',
                                state: {
                                    result: data,
                                    functionType: 'RAML',
                                    title: 'RAML Generator',
                                    status: true
                                }
                            })
                        },
                        error => {
                            message.error(error.message)
                            if (!isNullOrUndefined(error.resultBody)) {
                                this.props.history.push({
                                    pathname:
                                        '/pages/tools/result-code-generator',
                                    state: {
                                        result: error.resultBody,
                                        functionType: 'RAML',
                                        title: 'RAML Generator',
                                        status: false
                                    }
                                })
                            }
                        }
                    )
            })
        }
    }
}
