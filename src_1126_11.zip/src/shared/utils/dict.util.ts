
const DICT_STORE_KEY = 'react-storage'

export class DictUtil {
    constructor() {}
    public dirName = this.getdirNameMap();

    public getDics(){
        const storage = localStorage.getItem(DICT_STORE_KEY) || '{}'
        const stroageObject = JSON.parse(storage)
        const dicts = stroageObject ?.dict ?.dicts || []
        return dicts;
    }
    
    public getdirNameMap() {
        const dicts = this.getDics();
        const map = new Map();
        dicts.map(item => {
            const { dirCode, dirName, dirType } = item;
            if (dirCode && dirName && dirType) {
                map.set(dirType + '_' + dirCode, dirName);
            }
        })
        return map;
    }

    public dicts(type, generate?) {
        const dicts = this.getDics();
        const targets = dicts.filter(x => x.dirType === type)
        return generate ? targets.map(x => generate(x)) : targets
    }

    public filter(type, code) {
        const dirNameRes = this.dirName.get(type + '_' + code);
        return dirNameRes ? dirNameRes : code;
    }
}
