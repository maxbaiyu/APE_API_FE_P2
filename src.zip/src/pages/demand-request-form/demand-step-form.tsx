import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import {
    Input,
    InputNumber,
    message,
    Select,
    DatePicker,
    Button,
    Form
} from 'antd'
import DataForm from '~/shared/components/data-form'
import CardContainer from '~/shared/components/card-container'
import { DictUtil } from '~/shared/utils/dict.util'
import { DemandService } from '~/services/demand.service'
import { RequestParams } from '~/core/http'
import moment from 'moment'
import CustomizeModal from '~/shared/components/customize-modal'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { ApiService } from '~/services/api.service'
const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface DemandStepFormState {
    inputType: string
    discharge: boolean
    searchData: any[]
    currentStep: any
    successModalVisible: boolean
    versionData: any[]
    countryData: any[]
    hover: boolean
    // imgsrc:string
}

interface DemandStepFormProps {}
const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})
export default class DemandStepForm extends Component<
    RouteComponentProps<DemandStepFormProps>,
    DemandStepFormState
> {
    private apiName = ''
    private apiCatalogueId = ''
    private reuseApiVersion = ''
    private stepData = {
        step1: {
            name: 1,
            barPic: require('~/assets/images/navigation-bar-1.png'),
            step1CardTheme: 'light',
            step2CardTheme: 'light',
            step3CardTheme: 'light',
            form1Discharge: false,
            form2Discharge: false,
            form3Discharge: false,
            buttonDischargeStyle: '',
            buttonDischargeFunction: function () {
                console.log()
            },
            buttonNextText: 'Next',
            buttonNextFunction: this.step1Next
        },
        step2: {
            name: 2,
            barPic: require('~/assets/images/navigation-bar-2.png'),
            step1CardTheme: 'dark',
            step2CardTheme: 'light',
            step3CardTheme: 'light',
            form1Discharge: true,
            form2Discharge: false,
            form3Discharge: false,
            buttonDischargeStyle: '',
            buttonDischargeFunction: this.step2Discharge,
            buttonNextText: 'Next',
            buttonNextFunction: this.step2Next
        },
        step3: {
            name: 3,
            barPic: require('~/assets/images/navigation-bar-3.png'),
            step1CardTheme: 'dark',
            step2CardTheme: 'dark',
            step3CardTheme: 'light',
            form1Discharge: true,
            form2Discharge: true,
            form3Discharge: false,
            buttonDischargeStyle: '',
            buttonDischargeFunction: this.step3Discharge,
            buttonNextText: 'Submit',
            buttonNextFunction: this.step3Next
        }
    }
    private dataFrom1Ref!: React.RefObject<DataForm>
    private dataFrom2Ref!: React.RefObject<DataForm>
    private dataFrom3Ref!: React.RefObject<DataForm>

    private dictUtil = new DictUtil()
    private demandService = new DemandService()
    private apiSevice = new ApiService()
    constructor(props) {
        super(props)
        this.dataFrom1Ref = React.createRef()
        this.dataFrom2Ref = React.createRef()
        this.dataFrom3Ref = React.createRef()

        this.state = {
            inputType: '01',
            discharge: true,
            searchData: [],
            currentStep: this.stepData.step1,
            successModalVisible: false,
            versionData: [],
            countryData: [],
            hover: false
        }
    }
    private toggleHover = () => {
        this.setState({
            hover: !this.state.hover
        })
    }
    private toggleseOut = () => {
        this.setState({ 
            hover: !this.state.hover,
        })
    }
    private renderStep1Container() {
        const {
            discharge,
            inputType,
            currentStep,
            versionData,
            searchData,
            countryData
        } = this.state
        var linkStyle
        var imgsrc=''
        var imgstyle
        if (this.state.hover) {
            imgsrc = require('~/assets/images/qm.png')
            linkStyle = {
                display: 'block',
                position: 'absolute',
                right: -220,
                top: -20,
                width: 210,
                height: 70,
                backgroundColor: '#fff',
                border: '1px solid #333333',
                padding: 15,
                fontSize:12,
                color:'#333333',
                cursor:'pointer'
            }
        } else {
            imgsrc=require('~/assets/images/Help.png')
            linkStyle = {
                display: 'none'
            }
        }
        return (
            <CardContainer
                title="Basic Information"
                theme={currentStep.step1CardTheme}
            >
                <DataForm
                    name="demo-form"
                    column={1}
                    labelCol={{ span: 8 }}
                    labelAlign="left"
                    formWidth={900}
                    ref={this.dataFrom1Ref}
                >
                    <div>
                        <Form.Item
                            name="demandClassification"
                            label="Demand Classification"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                onChange={(value: string) => {
                                    this.setState({
                                        inputType: value
                                    })
                                    this.dataForm1.formInstance.resetFields([
                                        'apiName',
                                        'reuseAPIVersion'
                                    ])
                                }}
                                disabled={currentStep.form1Discharge}
                            >
                                {this.dictUtil.dicts(
                                    'api_classification',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <div
                            style={{
                                position: 'absolute',
                                right: 0,
                                top: 4,
                                cursor:'pointer',
                                zIndex: 999
                            }}
                            onClick={this.toggleHover}
                            // onMouseLeave={this.toggleseOut}
                            // onMouseOut={this.toggleseOut}
                        >
                            <img
                                width="20"
                                // src={imgsrc}
                                src={imgsrc}
                            ></img>
                        </div>
                        <div style={linkStyle}     
                           onClick={() => {
                            window.open(
                                'https://alm-confluence.systems.uk.hsbc/confluence/display/CAIL/Core+Banking+TRUE+SAPI+Terminology'
                            )
                        }}
                            >
                            <div
                                style={{
                                    position: 'absolute',
                                    width:0,
                                    height:0,
                                    top:'25px',
                                    left:'-20px',
                                    border:'10px solid transparent',
                                    borderRightColor:'#333333'
                                 }
                             }
                            ></div>
                            <div
                                style={{
                                    position: 'absolute',
                                    width:0,
                                    height:0,
                                    top:'25px',
                                    left:'-18px',
                                    border:'10px solid transparent',
                                    borderRightColor:'#fff',
                                    zIndex:99
                                 }
                             }
                            ></div>
                            Refer to Core Banking TRUE SAPI Terminology
                        </div>
                    </div>

                    <Form.Item
                        name="apiName"
                        label="API Name"
                        rules={[{ required: true }]}
                        style={styles().input(inputType === '01')}
                    >
                        <Input
                            disabled={currentStep.form1Discharge}
                            onChange={e => {
                                this.apiName = e.target.value
                            }}
                            style={{ width: 560 }}
                        />
                    </Form.Item>
                    <Form.Item
                        name="apiName"
                        label="API Name"
                        rules={[{ required: true }]}
                        style={styles().input(inputType !== '01')}
                    >
                        <Select
                            style={{ width: 560 }}
                            showSearch
                            defaultActiveFirstOption={false}
                            showArrow={false}
                            filterOption={false}
                            onSearch={value => this.onSearch(value)}
                            onChange={(value: any) => {
                                console.log(value)
                                this.apiName = value.label
                                this.apiCatalogueId = value.value

                                const selectedRow = searchData.filter(
                                    x => x.apiCatalogueId === value.value
                                )
                                this.setState({
                                    versionData: selectedRow[0].versionList
                                })
                            }}
                            notFoundContent={null}
                            labelInValue
                            disabled={currentStep.form1Discharge}
                        >
                            {searchData.map(x => (
                                <Select.Option
                                    key={x.apiCatalogueId}
                                    value={x.apiCatalogueId}
                                >
                                    {x.apiName}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name="reuseAPIVersion"
                        label="Reuse API Version"
                        // rules={[{ required: true }]}
                        style={styles().input(inputType !== '01')}
                    >
                        <Select
                            labelInValue
                            style={{ width: 560 }}
                            disabled={currentStep.form1Discharge}
                        >
                            {versionData.map(x => (
                                <Select.Option
                                    key={x.versionId}
                                    value={x.versionId}
                                >
                                    {x.version}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                </DataForm>
            </CardContainer>
        )
    }
    private renderStep2Container() {
        const { currentStep, countryData } = this.state

        return (
            <div style={styles().input(currentStep.name > 1)}>
                <CardContainer
                    title="Detail Information"
                    theme={currentStep.step2CardTheme}
                >
                    <DataForm
                        name="demo-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                        ref={this.dataFrom2Ref}
                    >
                        <Form.Item
                            name="requester"
                            label="Requester"
                            rules={[{ required: true }]}
                        >
                            <Input
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            />
                        </Form.Item>
                        <Form.Item
                            name="projectName"
                            label="Project Name"
                            rules={[{ required: true }]}
                        >
                            <Input
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            />
                        </Form.Item>

                        <Form.Item
                            name="region"
                            label="Region"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                                onChange={value => {
                                    const countries = this.dictUtil.dicts(value)
                                    this.setState({
                                        countryData: countries
                                    })
                                    this.dataForm2.formInstance.resetFields([
                                        'country'
                                    ])
                                }}
                            >
                                {this.dictUtil.dicts('region', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item name="country" label="Country">
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            >
                                {countryData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="backEndSystem"
                            label="Backend System"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            >
                                {this.dictUtil.dicts('backend_system', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="channel"
                            label="Channel"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            >
                                {this.dictUtil.dicts('channel', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="consumer"
                            label="Consumer"
                            rules={[{ required: true }]}
                        >
                            <Input
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            />
                        </Form.Item>
                        <Form.Item
                            name="gbOrGF"
                            label="GB/GF"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            >
                                {this.dictUtil.dicts('gb_gf', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="cbApiContact"
                            label="Core Banking API Contact"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            >
                                {this.dictUtil.dicts('cb_api_contact', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="cbSysContact"
                            label="Core Banking System Contact"
                            rules={[{ required: true }]}
                        >
                            <Select
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            >
                                {this.dictUtil.dicts(
                                    'cb_system_contact',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="targetLiveDate"
                            label="Target Live Date"
                            rules={[{ required: true }]}
                        >
                            <DatePicker
                                disabled={currentStep.form2Discharge}
                                style={{ width: 560 }}
                                format="MM/DD/yyyy"
                            />
                        </Form.Item>
                        <Form.Item
                            name="receivedDate"
                            label="Order Receive Date"
                            rules={[{ required: true }]}
                        >
                            <DatePicker
                                disabled={currentStep.form2Discharge}
                                style={{ width: 560 }}
                                format="MM/DD/yyyy"
                            />
                        </Form.Item>
                        <Form.Item
                            name="gdpmInterLockBpid"
                            label="BPID"
                            // rules={[{ required: true }]}
                        >
                            <Input
                                style={{ width: 560 }}
                                disabled={currentStep.form2Discharge}
                            />
                        </Form.Item>
                    </DataForm>
                </CardContainer>
            </div>
        )
    }
    private renderStep3Container() {
        const { currentStep } = this.state

        return (
            <div style={styles().input(currentStep.name > 2)}>
                <CardContainer title="Estimation Information">
                    <DataForm
                        ref={this.dataFrom3Ref}
                        name="estimateForm"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        onValuesChange={this.onFormValueChange.bind(this)}
                        formWidth={900}
                    >
                        <Form.Item
                            name="ossApiL0Estimates"
                            label="Mule API L0 Estimates"
                            rules={[{ required: true }]}
                        >
                            <InputNumber
                                style={{ width: 560 }}
                                min={0}
                                step={0.01}
                                formatter={value => this.limitDecimals(value)}
                                parser={value => this.limitDecimals(value)}
                            />
                        </Form.Item>
                        <Form.Item label="+"></Form.Item>
                        <Form.Item
                            name="cbSystemL0Estimates"
                            label="CB Systems L0 Estimates"
                            rules={[{ required: true }]}
                        >
                            <InputNumber
                                style={{ width: 560 }}
                                min={0}
                                step={0.01}
                                formatter={value => this.limitDecimals(value)}
                                parser={value => this.limitDecimals(value)}
                            />
                        </Form.Item>
                        <Form.Item label="="></Form.Item>
                        <Form.Item
                            name="totalApiL0Estimates"
                            label="Total API L0 Estimates"
                            initialValue={0}
                            rules={[{ required: true }]}
                        >
                            <InputNumber
                                style={{ width: 560 }}
                                formatter={value => this.limitDecimals(value)}
                                parser={value => this.limitDecimals(value)}
                                readOnly={true}
                            />
                        </Form.Item>
                    </DataForm>
                </CardContainer>
            </div>
        )
    }
    private limitDecimals(value: any): string {
        const reg = /^(\-)*(\d+)\.(\d\d).*$/
        console.log(value)
        if (typeof value === 'string') {
            return !isNaN(Number(value)) ? value.replace(reg, '$1$2.$3') : ''
        } else if (typeof value === 'number') {
            return !isNaN(value) ? String(value).replace(reg, '$1$2.$3') : ''
        } else {
            return ''
        }
    }
    public render() {
        const { currentStep } = this.state

        return (
            <components.PageContainer width="70%" title="Demand Request Form" noHeader={true}>
                <div style={{ height: 15 }}></div>

                <img width="100%" src={currentStep.barPic}></img>
                <div style={{ height: 15 }}></div>

                <div
                    style={{
                        textAlign: 'right',
                        color: '#333333',
                        fontSize: '14px'
                    }}
                    className="flex-row justify-content-end"
                >
                    <div
                        style={{
                            color: '#F40000'
                        }}
                    >
                        *
                    </div>
                    Required information
                </div>
                {this.renderStep1Container()}
                {this.renderStep2Container()}
                {this.renderStep3Container()}

                <div className="flex-row justify-content-between">
                    <div>
                        <Button
                            size="large"
                            onClick={currentStep.buttonDischargeFunction.bind(
                                this
                            )}
                            style={styles().input(currentStep.name > 1)}
                        >
                            Modify
                        </Button>
                    </div>
                    <div className="flex-row justify-content-between">
                        <div>
                            <components.AuthDisableButton
                                size="large"
                                onClick={() => this.submit('SAVE')}
                                auth={['ROLE_01']}
                                style={{
                                    ...styles().input(currentStep.name === 3),
                                    width: 100
                                }}
                            >
                                Save
                            </components.AuthDisableButton>
                        </div>
                        <div style={{ paddingLeft: 10 }}>
                            <components.AuthDisableButton
                                type="primary"
                                size="large"
                                danger
                                onClick={currentStep.buttonNextFunction.bind(
                                    this
                                )}
                                auth={['ROLE_01']}
                            >
                                {currentStep.buttonNextText}
                            </components.AuthDisableButton>
                        </div>
                    </div>
                </div>
                {this.renderModal()}
            </components.PageContainer>
        )
    }

    private get dataForm1(): DataForm {
        return this.dataFrom1Ref.current as DataForm
    }
    private get dataForm2(): DataForm {
        return this.dataFrom2Ref.current as DataForm
    }
    private get dataForm3(): DataForm {
        return this.dataFrom3Ref.current as DataForm
    }
    private setForm2Value(apiId) {
        this.demandService
            .get(new RequestParams({}, { append: [apiId] }))
            .subscribe(data => {
                this.dataForm2.formInstance.setFieldsValue({
                    ...data,
                    targetLiveDate: moment(data.targetLiveDate)
                })
            })
    }

    private discharge() {
        this.setState({
            discharge: false
        })
    }

    private onFormValueChange(changeValue, values) {
        this.dataForm3.formInstance.setFieldsValue({
            values,
            totalApiL0Estimates:
                values.ossApiL0Estimates + values.cbSystemL0Estimates
        })
    }
    private onSearch(value) {
        if (value !== '') {
            this.apiSevice
                .getApiListByName(new RequestParams({}, { append: [value] }))
                .subscribe(data => {
                    this.setState({
                        searchData: data
                    })
                })
        }
    }
    private step2Discharge() {
        let { currentStep } = this.state
        currentStep.form1Discharge = false

        this.setState({
            currentStep: currentStep
        })
    }
    private step3Discharge() {
        let { currentStep } = this.state
        currentStep.form1Discharge = false
        currentStep.form2Discharge = false

        this.setState({
            currentStep: currentStep
        })
    }
    private step1Next() {
        const { inputType } = this.state
        if (inputType === '01') {
            this.dataForm1.formInstance.validateFields().then((...data) => {
                this.apiSevice
                    .checking(new RequestParams({}, { append: [this.apiName] }))
                    .subscribe(data => {
                        if (data.status === 1) {
                            this.setState({
                                currentStep: this.stepData.step2
                            })
                        } else {
                            message.error('Api Name error')
                        }
                    })
            })
        } else {
            const d1 = this.dataForm1.formInstance.getFieldsValue()
            console.log(d1)
            console.log(d1.reuseAPIVersion)
            this.setState({
                currentStep: this.stepData.step2
            })
        }
    }
    private step2Next() {
        this.dataForm1.formInstance.validateFields().then((...data1) => {
            this.dataForm2.formInstance.validateFields().then((...data2) => {
                this.setState({
                    currentStep: this.stepData.step3
                })
            })
        })
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand List -->"
                cancelText="Close"
                content="Check Status in Demand List."
                onOk={() => {
                    this.props.history.push('/pages/api-demand-request-list')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private step3Next() {
        //this.dataForm2.
        //this.dataForm3.都可以取 按名字取就好
        this.submit('SUBMIT')
    }
    private submit(submitType) {
        console.log(submitType)
        this.dataForm1.formInstance.validateFields().then((...data1) => {
            this.dataForm2.formInstance.validateFields().then((...data2) => {
                this.dataForm3.formInstance
                    .validateFields()
                    .then((...data3) => {
                        const d1 = this.dataForm1.formInstance.getFieldsValue()
                        const d2 = this.dataForm2.formInstance.getFieldsValue()
                        const d3 = this.dataForm3.formInstance.getFieldsValue()
                        this.demandService
                            .post(
                                new RequestParams({
                                    functionType: submitType,
                                    ossApi: {
                                        feature: '',
                                        capability: '',
                                        service: ''
                                    },
                                    ossApiDemand: {
                                        apiCatalogueId: this.apiCatalogueId,
                                        apiName: this.apiName,
                                        apiType: '',
                                        apiLifecycleStage: '',
                                        backEndSystem: d2.backEndSystem,
                                        cbApiContact: d2.cbApiContact,
                                        cbSysContact: d2.cbSysContact,
                                        cbSystemL0Estimates:
                                            d3.cbSystemL0Estimates,
                                        channel: d2.channel,
                                        channelAgnostic: '',
                                        consumer: d2.consumer,
                                        country: d2.country,
                                        demandClassification:
                                            d1.demandClassification,
                                        gbOrGF: d2.gbOrGF,
                                        gdpmInterLockBpid: d2.gdpmInterLockBpid,
                                        multiCountry: '',
                                        nextMiletoneRagStatus: '',
                                        originalSapiId: '',
                                        ossApiL0Estimates: d3.ossApiL0Estimates,
                                        overallDeliveryRagStatus: '',
                                        platform: '',
                                        projectName: d2.projectName,
                                        receivedDate: d2.receivedDate.format(
                                            'MM/DD/YYYY'
                                        ),
                                        region: d2.region,
                                        requester: d2.requester,
                                        reusabilityScore: '',
                                        targetDateOfNextMilestone: '',
                                        targetDateOverallDelivery: '',
                                        targetLiveDate: d2.targetLiveDate.format(
                                            'MM/DD/YYYY'
                                        ),
                                        totalApiL0Estimates:
                                            d3.totalApiL0Estimates,
                                        trueSapiId: '',
                                        reuseApiVersionId:
                                            d1.reuseAPIVersion?.value,
                                        reuseApiVersion:
                                            d1.reuseAPIVersion?.label
                                    }
                                })
                            )
                            .subscribe(data => {
                                this.openSuccessModal()
                            })
                    })
            })
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
}
