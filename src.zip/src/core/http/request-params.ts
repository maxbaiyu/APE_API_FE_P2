import { IRequestParamsOption } from './interfaces'
import { RequestObject } from './request-object'
import { Model } from '../model'
import { Observable } from 'rxjs'
import { RequestService } from './request-service'
import { ExtendService } from './extend-service'
import { classToPlain } from 'class-transformer'
/**
 * Request Params
 */
export class RequestParams {
    public data: any
    public options: IRequestParamsOption
    private requestObject!: RequestObject
    /**
     * constructor
     * @param data
     * @param options
     */
    constructor(data?, options?: IRequestParamsOption) {
        this.data = data instanceof Model ? classToPlain(data) : data || {}
        this.options = options || {}
    }

    /**
     * Set Request Object
     * @param requestObject
     */
    public setRequestObject(requestObject: RequestObject) {
        this.requestObject = requestObject
    }

    /**
     * Get Extend Service
     */
    public getExtendService(): ExtendService[] {
        const extendServices = this.options
            ? Object.values(this.options).filter(
                  service => service instanceof ExtendService
              )
            : []
        return [...RequestService.extendServices, ...extendServices]
    }

    /**
     * Data conversion
     * @param callback
     */
    public map(callback) {
        this.data = callback(this.data)
    }

    /**
     * send http request
     */
    public request(): Observable<any> {
        return this.requestObject.request(this)
    }
}
