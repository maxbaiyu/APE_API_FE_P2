import React, { ReactNode, ComponentClass } from 'react'
import styled from 'styled-components'
import { Steps, Button } from 'antd'
import { Observable } from 'rxjs'
import StepItem from './step-item'
import { StepComponent } from '~/core/interfaces/setp.interface'

const components = {
    Wrapper: styled.section``,
    StepsContainer: styled.div`
        padding: 10px 20px;

        .ant-steps-item {
            flex: 1 1;
            .ant-steps-item-container {
                position: relative;
                .ant-steps-item-tail {
                    display: none;
                }

                .ant-steps-item-icon,
                .ant-steps-icon {
                    height: 40px;
                    position: absolute !important;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    margin-left: 0;

                    .status-bar {
                        width: 99%;
                        height: 20px;

                        &.up {
                            transform: skew(30deg);
                        }

                        &.down {
                            transform: skew(-30deg);
                        }

                        &.wait {
                            background: #d9eded;
                        }

                        &.process,
                        &.finish {
                            color: #fff;
                            background: #00847f;
                        }
                    }
                }

                .ant-steps-item-content {
                    width: 100%;
                    margin-top: 0;
                    height: 40px;
                    .ant-steps-item-title {
                        line-height: 40px;
                    }
                }
            }

            &.ant-steps-item-wait {
                .ant-steps-item-title {
                    color: rgba(0, 0, 0, 0.87);
                }
            }
            &.ant-steps-item-process,
            &.ant-steps-item-finish {
                .ant-steps-item-title {
                    color: rgba(255, 255, 255);
                }
            }
        }
    `,
    ContentContainer: styled.div``,
    ActionContainer: styled.div`
        display: flex;
        flex-direction: row;
        flex-wrap: nowrap;
        justify-content: flex-end;
        padding: 10px 20px;

        & > * {
            margin: 0 10px;
        }
    `
}

interface ComponentProp {
    title?: string
    onSubmit?: Function
}

interface ComponentState {
    currentStep: number
}
export default class StepContainer extends React.Component<
    ComponentProp,
    ComponentState
> {
    private stepElements: any = []
    private dataSource: any[] = []

    constructor(props) {
        super(props)

        this.state = {
            currentStep: 0
        }
    }
    public render() {
        return (
            <components.Wrapper>
                {this.renderStepContainer()}
                {this.renderContentContainer()}
                {this.renderActionContainer()}
            </components.Wrapper>
        )
    }

    public renderStepContainer() {
        const { currentStep } = this.state
        return (
            <components.StepsContainer>
                <Steps
                    progressDot={(dot, { status, index }) => (
                        <div>
                            <div className={`status-bar up ${status}`}></div>
                            <div className={`status-bar down ${status}`}></div>
                        </div>
                    )}
                    // type="navigation"
                    className="site-navigation-steps"
                    current={currentStep}
                >
                    {this.getStepItems()}
                </Steps>
            </components.StepsContainer>
        )
    }

    public renderContentContainer() {
        // 当前步骤
        const { currentStep } = this.state
        // 内容节点
        const content = this.getCurrentStepContent()

        const element = React.createElement(content, {
            ref: element => (this.stepElements[currentStep] = element)
        })

        return (
            <components.ContentContainer>{element}</components.ContentContainer>
        )
    }

    public renderActionContainer() {
        const { currentStep } = this.state
        const isFirstStep = currentStep === 0
        const isLastStep =
            currentStep === React.Children.count(this.props.children) - 1

        return (
            <components.ActionContainer>
                {!isFirstStep && (
                    <Button type="primary" onClick={() => this.onPreStep()}>
                        Previous
                    </Button>
                )}
                {!isLastStep && (
                    <Button type="primary" onClick={() => this.onNextStep()}>
                        Next
                    </Button>
                )}
                {isLastStep && (
                    <Button
                        type="primary"
                        onClick={() => this.onNextStep(true)}
                    >
                        Submit
                    </Button>
                )}
            </components.ActionContainer>
        )
    }

    private async onPreStep() {
        const { currentStep } = this.state
        this.setState({
            currentStep: currentStep - 1
        })
    }

    private async onNextStep(finish?) {
        const { currentStep } = this.state
        const currentContent = this.stepElements[currentStep] as StepComponent

        const result = await currentContent.onSubmit()

        if (!result) {
            return
        }

        if (result && typeof result !== 'boolean') {
            this.dataSource[currentStep] = result
        }

        if (finish) {
            const { onSubmit } = this.props
            onSubmit && onSubmit(this.dataSource)
        } else {
            this.setState({
                currentStep: currentStep + 1
            })
        }
    }

    private getStepItems() {
        return React.Children.map(this.props.children, (child, index) => {
            if (React.isValidElement(child)) {
                return (
                    <Steps.Step
                        title={child.props.title}
                        key={index}
                    ></Steps.Step>
                )
            }
            return child
        })
    }

    private getCurrentStepContent() {
        // 当前步骤
        const { currentStep } = this.state
        // 内容节点
        let content: any

        React.Children.forEach(this.props.children, (child, index) => {
            if (
                React.isValidElement(child) &&
                index === currentStep &&
                !content
            ) {
                content = child.props.component
            }
        })

        return content
    }
}
