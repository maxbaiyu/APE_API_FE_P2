/**
 * Account controller
 */
import { RequestMethod } from '~/core/http'

// Controller
const controller = 'account'

export const AccountController = {
    // all
    all: {
        controller,
        action: 'all',
        type: RequestMethod.Get
    },
    // update role
    role: {
        controller,
        action: 'role',
        type: RequestMethod.Put
    },
    // account active
    active: {
        controller,
        action: 'active',
        type: RequestMethod.Put
    },
    // getAccountInfoByStaffId
    userId: {
        controller,
        action: 'user-id',
        type: RequestMethod.Get
    }
}
