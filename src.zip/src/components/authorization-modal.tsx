import React from 'react'
import styled from 'styled-components'
import { Modal, Checkbox } from 'antd'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button
} from 'antd'
import LabelItem from '~/shared/components/label-item'
import { DictUtil } from '~/shared/utils/dict.util'

const components = {
    Wrapper: styled.section`
        width: 100%;
    `
}
interface ComponentState {
    checkedList: any
}
interface ComponentProp {
    // className?: string
    visible: boolean
    onOk: (e: any) => void
    onCancel?: () => void
}

export default class AuthorizationModal extends React.Component<
    ComponentProp,
    ComponentState
> {
    private dictUtil = new DictUtil()
    private checkedRoles: any[] = []

    constructor(props) {
        super(props)

        this.state = {
            checkedList: []
        }
    }
    public render() {
        return <components.Wrapper>{this.renderModal()}</components.Wrapper>
    }
    public renderModal() {
        return (
            <Modal
                title={this.renderTitle()}
                visible={this.props.visible}
                okText="Submit"
                onOk={() => {
                    this.props.onOk(this.checkedRoles)
                    this.setState({
                        checkedList: []
                    })
                }}
                onCancel={() => {
                    this.props.onCancel && this.props.onCancel()
                    this.setState({
                        checkedList: []
                    })
                }}
                width="680px"
                okType="primary"
                cancelText="Close"
                destroyOnClose={true}
            >
                <div
                    style={{
                        color: '#333333',
                        fontSize: 14,
                        fontWeight: 300,
                        paddingLeft: 20
                    }}
                >
                    {this.renderContent()}
                </div>
            </Modal>
        )
    }
    public renderContent() {
        const { checkedList } = this.state

        return (
            <div style={{ fontSize: 14 }}>
                <div>Roles</div>
                <div className="padding-y">
                    <Checkbox.Group
                        style={{ width: '100%' }}
                        onChange={checkedValue => this.onChange(checkedValue)}
                        value={checkedList}
                    >
                        {this.dictUtil.dicts('user_role', dict => (
                            <div className="padding-y" key={dict.dirCode}>
                                <Checkbox
                                    value={dict.dirCode}
                                    key={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Checkbox>
                            </div>
                        ))}
                    </Checkbox.Group>
                </div>
            </div>
        )
    }
    public renderTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Authorization
                </div>
            </div>
        )
    }
    public onChange(checkedValue) {
        this.checkedRoles = checkedValue
        this.setState({
            checkedList: checkedValue
        })
    }
}
