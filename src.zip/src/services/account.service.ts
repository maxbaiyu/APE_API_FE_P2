/**
 * Account Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { AccountController } from '~/config/services/account.controller'

export class AccountService {
    /**
     * all
     */
    @Request({
        server: AccountController.all
    })
    public all(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * update role
     */
    @Request({
        server: AccountController.role
    })
    public role(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * account active
     */
    @Request({
        server: AccountController.active
    })
    public active(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
    /**
     * getAccountInfoByStaffId
     */
    @Request({
        server: AccountController.userId
    })
    public userId(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
