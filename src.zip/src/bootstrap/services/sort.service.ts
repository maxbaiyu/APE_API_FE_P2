import { ExtendService } from '~/core/http'

export class SortService extends ExtendService {
    private sort = {}

    constructor(data?: any) {
        super()

        if (data) this.sort = data
    }

    /**
     * update sort
     * @param key sort column key
     * @param value sort type
     */
    public update(key, value) {
        this.sort = {}
        if (key && value) {
            this.sort[key] = SortType[value] || value
        }
    }

    /**
     * remove sort
     * @param key sort column key
     */
    public remove(key) {
        // filter
        const items: any[] = Object.entries(this.sort).filter(
            ([k]) => k !== key
        ) as any[]

        this.sort = {}

        // sort exist?
        if (items) {
            items.forEach(([k, v]) => {
                this.sort[k] = v
            })
        }
    }

    public before = params => {
        params.data = {
            ...params.data,
            sort: Object.entries(this.sort).map(([k]) => `${k}`),
            order: Object.entries(this.sort).map(([, v]) => `${v}`)
        }
    }

    public after = () => {
        //
    }

    /**
     * reset sort
     */
    public reset() {
        this.sort = {}
    }
}

/**
 * sort type
 */
export const SortType = {
    ascend: 'ASC',
    descend: 'DESC'
}
