import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    Modal,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { DemandService } from '~/services/demand.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import moment from 'moment'
import NotificationContainer from '~/shared/components/notification-container'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { isNullOrUndefined } from 'util'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface DemandRequestFormDetailState {
    id: string
    demandStatusid:string
    data: any
    disabledForm:boolean
    reviewModalVisible: boolean
    successModalVisible: boolean
    discharge: boolean
    discharge2: boolean
    countryData: any[]
    featureData: any[]
    serviceData: any[]
}

interface DemandRequestFormDetailProps {}

const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})

export default class DemandRequestFormDetail extends Component<
    RouteComponentProps<DemandRequestFormDetailProps>,
    DemandRequestFormDetailState
> {
    private dataFromRef!: React.RefObject<DataForm>
    private dataFrom1Ref!: React.RefObject<DataForm>
    private dataFrom2Ref!: React.RefObject<DataForm>

    private demandService = new DemandService()
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private statusType = ''
    private demandStatus = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.dataFrom1Ref = React.createRef()
        this.dataFrom2Ref = React.createRef()
        this.actionFromRef = React.createRef()

        this.state = {
            id: '',
            demandStatusid:'',
            data: {},
            disabledForm:true,
            discharge: true,
            discharge2: true,
            reviewModalVisible: false,
            successModalVisible: false,
            countryData: [],
            featureData: [],
            serviceData: []
        }
    }
    public componentDidMount() {
        const {demandStatusid} = this.props.location.state as DemandRequestFormDetailState;
        console.log(demandStatusid)
        if(demandStatusid=='4'||demandStatusid=='4'){
            this.setState({
                disabledForm: true
            })
        }else{
            this.setState({
                disabledForm: false
            })
        }
        const { id } = this.props.location.state as DemandRequestFormDetailState
        this.demandService
            .get(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    data: data
                })
                const country=this.dictUtil.dicts(data.region)
                this.setState({countryData:country})
                console.log('data.targetLiveDate' + data.targetLiveDate)
                this.dataForm.formInstance.setFieldsValue({
                    ...data,
                    targetLiveDate:
                        isNullOrUndefined(data.targetLiveDate) ||
                        data.targetLiveDate === ''
                            ? ''
                            : moment(data.targetLiveDate),
                    receivedDate:
                        isNullOrUndefined(data.receivedDate) ||
                        data.receivedDate === ''
                            ? ''
                            : moment(data.receivedDate)
                })
                this.dataForm1.formInstance.setFieldsValue({
                    ...data,
                    designReviewDate:
                        isNullOrUndefined(data.designReviewDate) ||
                        data.designReviewDate === ''
                            ? ''
                            : moment(data.designReviewDate)
                })
                this.dataForm2.formInstance.setFieldsValue({
                    ...data,
                    targetDateOfNextMilestone:
                        isNullOrUndefined(data.targetDateOfNextMilestone) ||
                        data.targetDateOfNextMilestone === ''
                            ? ''
                            : moment(data.targetDateOfNextMilestone),
                    targetOverallDelivery:
                        isNullOrUndefined(data.targetOverallDelivery) ||
                        data.targetOverallDelivery === ''
                            ? ''
                            : moment(data.targetOverallDelivery)
                })
            })
    }

    private openReviewModal() {
        this.setState({
            reviewModalVisible: true
        })
    }

    public render() {
        const {
            discharge,
            discharge2,
            data,
            countryData,
            featureData,
            serviceData,
            disabledForm
        } = this.state
        let demandStatusButton

        return (
            <components.PageContainer title="Demand Request Detail"  noHeader={true}>
                <div
                    // className="flex-row justify-content-end"
                    style={{ paddingTop: 10 }}
                    className="flex-row justify-content-between"
                >
                     <div   style={{ fontSize: 28,marginLeft: 20}}>{data.apiName}</div>
                    <Button
                        size="large"
                        onClick={() => {
                            this.props.history.goBack()
                        }}
                    >
                        Back
                    </Button>
                </div>
                {/* <Divider /> */}
                <CardContainer title="Demand Governance">
                    <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="API Name">
                            <Button
                                type="link"
                                className="text-left"
                                style={{
                                    ...styles().input(
                                        data.apiCatalogueId != null
                                    ),
                                    padding: 0
                                }}
                                onClick={() =>
                                    this.openForm(data.apiCatalogueId)
                                }
                            >
                                {data.apiName}
                            </Button>
                            <div
                                style={{
                                    ...styles().input(
                                        data.apiCatalogueId === null
                                    ),
                                    padding: 0
                                }}
                            >
                                {data.apiName}
                            </div>
                        </LabelItem>
                        <LabelItem label="Entry Creation Date">
                            {data.createDate}
                        </LabelItem>
                    </LabelContainer>
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                    >
                        <Form.Item name="projectName" label="Project Name">
                            <Input    disabled={disabledForm}/>
                        </Form.Item>
                        <Form.Item
                            name="receivedDate"
                            label="Order Receive Date"
                        >
                            <DatePicker
                                disabled={disabledForm}
                                format="MM/DD/yyyy"
                            />
                        </Form.Item>
                        <Form.Item name="region" label="Region">
                            <Select
                                disabled={disabledForm}
                                onChange={value => {
                                    const countries = this.dictUtil.dicts(value)
                                    this.setState({
                                        countryData: countries
                                    })
                                    this.dataForm.formInstance.resetFields([
                                        'country'
                                    ])
                                }}
                            >
                                {this.dictUtil.dicts('region', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item name="requester" label="Requester">
                            <Input  disabled={disabledForm} />
                        </Form.Item>
                        <Form.Item name="country" label="Site">
                            <Select  disabled={disabledForm}>
                                {countryData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>

                        <Form.Item
                            name="cbApiContact"
                            label="Core Banking API Contact"
                        >
                            <Select  disabled={disabledForm}>
                                {this.dictUtil.dicts('cb_api_contact', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>

                        <Form.Item
                            name="backEndSystem"
                            label="Backend System"
                            initialValue=""
                        >
                            <Select  disabled={disabledForm}>
                                {this.dictUtil.dicts('backend_system', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="cbSysContact"
                            label="Core Banking System Contact"
                            initialValue=""
                        >
                            <Select  disabled={disabledForm}>
                                {this.dictUtil.dicts(
                                    'cb_system_contact',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="channel"
                            label="Channel"
                            initialValue=""
                        >
                            <Select  disabled={disabledForm}>
                                {this.dictUtil.dicts('channel', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="totalApiL0Estimates"
                            label="Total API L0 Estimates"
                            initialValue=""
                        >
                            <Input  disabled={disabledForm} />
                        </Form.Item>
                        <Form.Item name="gbOrGF" label="GB/GF" initialValue="">
                            <Select disabled={disabledForm}>
                                {this.dictUtil.dicts('gb_gf', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="ossApiL0Estimates"
                            label="Mule API L0 Estimates"
                            initialValue=""
                        >
                            <Input  disabled={disabledForm}/>
                        </Form.Item>

                        <Form.Item
                            name="demandClassification"
                            label="Demand Classification"
                            initialValue=""
                        >
                            <Select disabled={disabledForm}>
                                {this.dictUtil.dicts(
                                    'api_classification',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="cbSystemL0Estimates"
                            label="CB System L0 Estimates"
                            initialValue=""
                        >
                            <Input disabled={disabledForm}/>
                        </Form.Item>
                        <Form.Item
                            name="apiLifecycleStage"
                            label="API lifecycle Stage"
                            initialValue=""
                        >
                            <Select>
                                {this.dictUtil.dicts(
                                    'api_lifecycle_stage',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="gdpmInterLockBpid"
                            label="BPID"
                            initialValue=""
                        >
                            <Input  disabled={disabledForm}/>
                        </Form.Item>
                        <Form.Item
                            name="targetLiveDate"
                            label="Target Live Date"
                        >
                            <DatePicker format="MM/DD/yyyy" />
                        </Form.Item>
                        {/*  <Form.Item
                            name="Consumer"
                            label="Consumer"
                            initialValue="Consumer"
                        >
                            <Input disabled />
                        </Form.Item>*/}
                    </DataForm>
                    {this.renderDemandApprovalViewBox()}
                </CardContainer>
                <CardContainer title=" Design Governance">
                    {/* <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom1Ref}
                    > */}
                          <LabelContainer column={2} labelSpan={4}>
                        <LabelItem label="Capability">
                            {/* {data.capability} */}
                            {this.dictUtil.filter(
                                'capability',
                                data.capability
                            )}
                        </LabelItem>
                        <LabelItem label="API ID">
                            {data.trueSapiId}
                        </LabelItem>
                        <LabelItem label="Feature">
                            {this.dictUtil.filter(
                                data.capability,
                                data.feature
                            )}
                        </LabelItem>
                        <LabelItem label="Original API ID">
                            {data.originalSapiId}
                        </LabelItem>
                            <LabelItem label="Service">
                            {this.dictUtil.filter(
                                data.feature,
                                data.service
                            )}
                        </LabelItem>
                            <LabelItem label="Multi-Country">
                            {data.multiCountry}
                        </LabelItem>
                            <LabelItem label="Platform">
                            {/* {data.platform}
                             */}
                             {this.dictUtil.filter(
                                'platform',
                                data.platform
                            )}
                        </LabelItem>
                            <LabelItem label="Reusability Score">
                            {/* {data.reusabilityScore} */}
                            {this.dictUtil.filter(
                                'reusability_score', data.reusabilityScore
                            )}
                        </LabelItem>
                            <LabelItem label="Channel Agnostic">
                            {/* {data.channelAgnostic} */}
                            {this.dictUtil.filter(
                                'channel_agnostic',
                                data.channelAgnostic
                            )}
                        </LabelItem> 
                            <LabelItem label="Design Review Approval Status">
                            {/* {data.designReviewStatus} */}
                            {this.dictUtil.filter(
                                'design_review_status',
                                data.designReviewStatus
                            )}
                        </LabelItem> 
                        <LabelItem label="API Type">
                            {this.dictUtil.filter(
                                'api_type', data.apiType
                            )}
                        </LabelItem> 
                        <LabelItem label="Design Review Approval Date">
                            {data.designReviewDate}
                        </LabelItem> 
                   </LabelContainer>
                        {/* <Form.Item
                            name="capability"
                            label="Capability"
                            initialValue=""
                        >
                            <Select
                                onChange={value => {
                                    const features = this.dictUtil.dicts(value)
                                    this.setState({
                                        featureData: features
                                    })
                                    this.dataForm1.formInstance.resetFields([
                                        'service',
                                        'feature'
                                    ])
                                }}
                            >
                                {this.dictUtil.dicts('capability', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="trueSapiId"
                            label="API ID"
                            initialValue=""
                        >
                            <Input />
                        </Form.Item> */}
                        {/* <Form.Item
                            name="feature"
                            label="Feature"
                            initialValue=""
                        >
                            <Select
                                onChange={value => {
                                    const services = this.dictUtil.dicts(value)
                                    this.setState({
                                        serviceData: services
                                    })
                                    this.dataForm1.formInstance.resetFields([
                                        'service'
                                    ])
                                }}
                            >
                                {featureData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="originalSapiId"
                            label="Original API ID"
                            initialValue=""
                        >
                            <Input  />
                        </Form.Item> */}
                        {/* <Form.Item
                            name="service"
                            label="Service"
                            initialValue=""
                        >
                            <Select>
                                {serviceData.map(x => (
                                    <Select.Option
                                        key={x.dirCode}
                                        value={x.dirCode}
                                    >
                                        {x.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="multiCountry"
                            label="Multi-Country"
                            initialValue=""
                        >
                            <Select>
                                <Select.Option value="N">N</Select.Option>
                                <Select.Option value="Y">Y</Select.Option>
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="platform"
                            label="Platform"
                            initialValue=""
                        >
                            <Select>
                                {this.dictUtil.dicts('platform', dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="reusabilityScore"
                            label="Reusability Score"
                            initialValue=""
                        >
                            <Input  />
                        </Form.Item> */}
                        {/* <Form.Item
                            name="channelAgnostic"
                            label="Channel Agnostic"
                            initialValue=""
                        >
                            <Select>
                                {this.dictUtil.dicts(
                                    'channel_agnostic',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="designReviewStatus"
                            label="Design Review Approval Status"
                            initialValue=""
                        >
                            <Select>
                                {this.dictUtil.dicts(
                                    'design_review_status',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="apiType"
                            label="API Type"
                            initialValue=""
                        >
                            <Select>
                                <Select.Option value="TRUE SAPI">
                                    TRUE SAPI
                                </Select.Option>
                            </Select>
                        </Form.Item> */}
                        {/* <Form.Item
                            name="designReviewDate"
                            label="Design Review Approval Date"
                            initialValue=""
                        >
                            <DatePicker format="MM/DD/yyyy" />
                        </Form.Item> */}
                         <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom1Ref}
                    >
                    </DataForm>

                    {/* {this.renderDesignApprovalViewBox()} */}
                    {this.renderModal()}
                    {this.renderReviewModal()}
                </CardContainer>
                <Divider />
                <CardContainer title="Other Information">
                    <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        ref={this.dataFrom2Ref}
                    >
                        <Form.Item
                            name="targetDateOfNextMilestone"
                            label="Target Date of Next Milestone"
                        >
                            <DatePicker format="MM/DD/yyyy" />
                        </Form.Item>
                        <Form.Item
                            name="targetOverallDelivery"
                            label="Target Overall Delivery"
                        >
                            <DatePicker format="MM/DD/yyyy" />
                        </Form.Item>
                        <Form.Item
                            name="nextMiletoneRagStatus"
                            label="Next Miletone RAG Status"
                        >
                            <Select>
                                {this.dictUtil.dicts(
                                    'rag_status_type',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item
                            name="overallDeliveryRagStatus"
                            label="Overall Delivery RAG Status"
                        >
                            <Select>
                                {this.dictUtil.dicts(
                                    'rag_status_type',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                    </DataForm>
                    <div className="flex-row justify-content-between">
                        <div
                            style={{
                                padding: 20
                            }}
                        >
                            {/* <Button
                                className="submit-button"
                                size="large"
                                onClick={() => this.discharge()}
                            >
                                Modify
                            </Button> */}
                        </div>
                        <div className="flex-row justify-content-between">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    style={{
                                        ...styles().input(
                                            data.demandStatus === '1'
                                        ),
                                        width: 100
                                    }}
                                    size="large"
                                    onClick={() => this.submit('SAVE')}
                                    auth={['ROLE_01']}
                                >
                                    Save
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    style={{ width: 100 }}
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => this.submit('SUBMIT')}
                                    auth={['ROLE_01']}
                                >
                                    Submit
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </div>
                </CardContainer>
            </components.PageContainer>
        )
    }
    private renderDemandApprovalViewBox() {
        // const { data } = this.state
        // const { demandStatus } = data
        // switch (demandStatus) {
        //     case '4':
        //         return (
        //             <NotificationContainer
        //                 className="padding-y"
        //                 title="Demand Approval"
        //                 theme="approved"
        //                 status={demandStatus}
        //             >
        //                 <LabelContainer column={1} labelSpan={3}>
        //                     <LabelItem label="Reviewer:">
        //                         {data.demandCommentApprover}
        //                     </LabelItem>
        //                     <LabelItem label="Date in Operation:">
        //                         {data.demandDate}
        //                     </LabelItem>
        //                     <LabelItem label="Comments:">
        //                         {data.demandCommentDesc}
        //                     </LabelItem>
        //                 </LabelContainer>
        //                 <div className="flex-row justify-content-end">
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <Button
        //                             className="submit-button"
        //                             disabled
        //                             size="large"
        //                         >
        //                             Approve
        //                         </Button>
        //                     </div>
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <Button
        //                             className="submit-button"
        //                             size="large"
        //                             disabled
        //                         >
        //                             Reject
        //                         </Button>
        //                     </div>
        //                 </div>
        //             </NotificationContainer>
        //         )
        //     case '5':
        //         return (
        //             <NotificationContainer
        //                 className="padding-y"
        //                 title="Demand Approval"
        //                 theme="rejected"
        //                 status={demandStatus}
        //             >
        //                 <LabelContainer column={1} labelSpan={3}>
        //                     <LabelItem label="Reviewer:">
        //                         {data.demandCommentApprover}
        //                     </LabelItem>
        //                     <LabelItem label="Date in Operation:">
        //                         {data.demandDate}
        //                     </LabelItem>
        //                     <LabelItem label="Comments:">
        //                         {data.demandCommentDesc}
        //                     </LabelItem>
        //                 </LabelContainer>
        //                 <div className="flex-row justify-content-end">
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <Button
        //                             className="submit-button"
        //                             disabled
        //                             size="large"
        //                         >
        //                             Approve
        //                         </Button>
        //                     </div>
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <Button
        //                             className="submit-button"
        //                             size="large"
        //                             disabled
        //                         >
        //                             Reject
        //                         </Button>
        //                     </div>
        //                 </div>
        //             </NotificationContainer>
        //         )
        //     case '1':
        //         return (
        //             <NotificationContainer
        //                 className="padding-y"
        //                 title="Demand Approval"
        //                 theme="inProgress"
        //                 status={demandStatus}
        //             >
        //                 <div className="flex-row justify-content-end">
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <Button
        //                             type="primary"
        //                             htmlType="submit"
        //                             className="submit-button"
        //                             danger
        //                             size="large"
        //                             disabled
        //                         >
        //                             Approve
        //                         </Button>
        //                     </div>
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <Button
        //                             className="submit-button"
        //                             size="large"
        //                             style={{ width: 100 }}
        //                             disabled
        //                         >
        //                             Reject
        //                         </Button>
        //                     </div>
        //                 </div>
        //             </NotificationContainer>
        //         )
        //     default:
        //         return (
        //             <NotificationContainer
        //                 className="padding-y"
        //                 title="Demand Approval"
        //                 theme="verify"
        //                 status={demandStatus}
        //             >
        //                 <div className="flex-row justify-content-end">
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <components.AuthDisableButton
        //                             type="primary"
        //                             htmlType="submit"
        //                             className="submit-button"
        //                             danger
        //                             size="large"
        //                             onClick={() => {
        //                                 this.statusType = 'DEMAND'
        //                                 this.demandStatus = '4'
        //                                 this.openReviewModal()
        //                             }}
        //                             auth={['ROLE_02']}
        //                         >
        //                             Approve
        //                         </components.AuthDisableButton>
        //                     </div>
        //                     <div
        //                         style={{
        //                             padding: 20
        //                         }}
        //                     >
        //                         <components.AuthDisableButton
        //                             className="submit-button"
        //                             size="large"
        //                             style={{ width: 100 }}
        //                             onClick={() => {
        //                                 this.statusType = 'DEMAND'
        //                                 this.demandStatus = '4'
        //                                 this.openReviewModal()
        //                             }}
        //                             auth={['ROLE_02']}
        //                         >
        //                             Reject
        //                         </components.AuthDisableButton>
        //                     </div>
        //                 </div>
        //             </NotificationContainer>
        //         )
        // }
    }

    private renderDesignApprovalViewBox() {
        const { data } = this.state
        const { designStatus } = data
        switch (designStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Design Approval"
                        theme="approved"
                        status={designStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.designCommentApprover}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.designDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.designCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Design Approval"
                        theme="rejected"
                        status={designStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.designCommentApprover}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.designDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.designCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '1':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Design Approval"
                        theme="inProgress"
                        status={designStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    disabled
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Design Approval"
                        theme="inProgress"
                        status={designStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.statusType = 'DESIGN'
                                        this.demandStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_02']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.statusType = 'DESIGN'
                                        this.demandStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_02']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }
    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    private get dataForm1(): DataForm {
        return this.dataFrom1Ref.current as DataForm
    }
    private get dataForm2(): DataForm {
        return this.dataFrom2Ref.current as DataForm
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand Request Detail -->"
                cancelText="Close"
                content="Check Information in Demand Request Detail."
                onOk={() => {
                    this.closeSuccessModal()
                    this.props.history.goBack()
                    // this.props.history.push('/pages/demand-request-form-exhibition')
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }
    private renderReviewModal() {
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {/* {(this.staffId = userStore.state.staffId)} */}
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        Governance Group
                                    </LabelItem>
                                </LabelContainer>

                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private submitAction(staffId) {
        const { data } = this.state
        this.actionForm.formInstance.validateFields().then((...data1) => {
            this.demandService
                .status(
                    new RequestParams({
                        apiDemandIdList: [data.demandId],
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        status: this.demandStatus,
                        statusType: this.statusType
                    })
                )
                .subscribe(data => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }
    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }

    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private submit(submitType) {
        const d1 = this.dataForm.formInstance.getFieldsValue()
        // const d2 = this.dataForm1.formInstance.getFieldsValue()
        const d3 = this.dataForm2.formInstance.getFieldsValue()
        const { data } = this.state

        this.demandService
            .put(
                new RequestParams({
                    functionType: submitType,
                    // ossApi: {
                    //     feature: d2.feature,
                    //     capability: d2.capability,
                    //     service: d2.service
                    // },
                    ossApiDemand: {
                        apiCatalogueId: data.apiCatalogueId,
                        apiLifecycleStage: d1.apiLifecycleStage,
                        // apiName: 'string',
                        // apiType: d2.apiType,
                        backEndSystem: d1.backEndSystem,
                        cbApiContact: d1.cbApiContact,
                        cbSysContact: d1.cbSysContact,
                        cbSystemL0Estimates: d1.cbSystemL0Estimates,
                        channel: d1.channel,
                        // channelAgnostic: d2.channelAgnostic,
                        consumer: data.consumer,
                        country: d1.country,
                        demandClassification: d1.demandClassification,
                        demandId: data.demandId,
                        gbOrGF: d1.gbOrGF,
                        gdpmInterLockBpid: d1.gdpmInterLockBpid,
                        // multiCountry: d2.multiCountry,
                        nextMiletoneRagStatus: d3.nextMiletoneRagStatus,
                        // originalSapiId: d2.originalSapiId,
                        ossApiL0Estimates: d1.ossApiL0Estimates,
                        overallDeliveryRagStatus: d3.overallDeliveryRagStatus,
                        // platform: d2.platform,
                        projectName: d1.projectName,
                        receivedDate:
                            d1.receivedDate === ''
                                ? ''
                                : d1.receivedDate.format('MM/DD/YYYY'),
                        region: d1.region,
                        requester: d1.requester,
                        reusabilityScore: d1.reusabilityScore,
                        reuseApiVersion: data.reuseApiVersion,
                        reuseApiVersionId: data.reuseApiVersionId,
                        targetDateOfNextMilestone:
                            d3.targetDateOfNextMilestone === ''
                                ? ''
                                : d3.targetDateOfNextMilestone.format(
                                      'MM/DD/YYYY'
                                  ),
                        targetOverallDelivery:
                            d3.targetOverallDelivery === ''
                                ? ''
                                : d3.targetOverallDelivery.format(
                                      'MM/DD/YYYY'
                                  ),
                        targetLiveDate:
                            d1.targetLiveDate === ''
                                ? ''
                                : d1.targetLiveDate.format('MM/DD/YYYY'),
                        totalApiL0Estimates: d1.totalApiL0Estimates,
                        // trueSapiId: d2.trueSapiId
                    }
                })
            )
            .subscribe(data => {
                this.openSuccessModal()
            })
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                id: apiCatalogueId
            }
        })
    }

    private discharge() {
        const { data } = this.state
        if (
            data.demandStatus == '3' ||
            data.demandStatus == '2' ||
            data.demandStatus == '1'
        ) {
            this.setState({
                discharge: false
            })
            if (data.demandClassification == '01') {
                this.setState({
                    discharge2: false
                })
            }
        }
    }
}
