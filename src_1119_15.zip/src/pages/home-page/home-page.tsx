import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import { Chart, Tooltip, Facet, Legend, Axis, Bar } from 'viser-react'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import {
    Form,
    Input,
    message,
    Button,
    Select,
    Card,
    Col,
    Row,
    Space,
    Table,
    Modal,
    Typography,
    AutoComplete,
    Layout,
    Steps,
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import StepItem from '~/shared/components/step-item'
import { truncate } from 'fs/promises'
import { DictUtil } from '~/shared/utils/dict.util'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import ReactEchartsCore from 'echarts-for-react/lib/core';
import {
    PlusCircleOutlined,
    DeleteOutlined
} from '@ant-design/icons'
import echarts from 'echarts/lib/echarts';
import 'echarts/lib/chart/bar';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/title';
import BraftEditor from 'braft-editor'
import MaxLength from 'braft-extensions/dist/max-length'
import { any, divide, keys, values } from 'ramda'
import { spawn } from 'child_process'
import { homePageJumpDatas } from './data';
const options = {
    defaultValue: 150, // 指定默认限制数，如不指定则为Infinity(无限)
  }

  BraftEditor.use(MaxLength(options))
  const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})
const components = {
    PageContainer: styled(PageContainer)`
        .ant-card-head {
            border-bottom: 1px solid transparent !important;
        }
    `,
    Card: styled(Card)`
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        .ant-card-head {
            border-bottom: 1px solid transparent !important;
        }
    `
}

interface HomePageState {
    getOption: any
    dataSource: any
    editorState: any
    Delete: any
    Active: any
    controls: any
    DeleteTwo: any
    reviewModalVisiblform: boolean
    reviewModalVisibPublicl: boolean
    center: any
    cbSysName: any
    standardMessage:any[]
    publicMessage:any[]
    dateList:any[]
    date:any
    ImgShow:any
    currentHomeStep:any
}
interface HomePageProps { }

export default class HomePage extends Component<
    RouteComponentProps<HomePageProps>,
    HomePageState
    > {
    private actionFromForm!: React.RefObject<DataForm>
    private actionFromPublic!: React.RefObject<DataForm>
    private reviewService = new ReviewService()
    private dictUtil = new DictUtil()

    constructor(props) {
        super(props)
        this.actionFromForm = React.createRef()
        this.actionFromPublic = React.createRef()
        this.state = {
            currentHomeStep:null,
            dataSource: [],
            reviewModalVisiblform: false,
            reviewModalVisibPublicl: false,
            ImgShow:false,
            cbSysName: [],
            standardMessage:[],
            publicMessage:[],
            dateList:[
            ],
            date:'',
            center: 'center',
            Active: require('~/assets/svg/Active.svg'),
            Delete: require('~/assets/svg/Delete.svg'),
            DeleteTwo: require('~/assets/svg/Delent-two.svg'),
            controls: ['bold', 'italic', 'underline', 'text-color', 'separator', 'font-size',
                'link', 'separator', 'headings', 'text-indent'],
            editorState: BraftEditor.createEditorState(null),
            getOption: {
                color: ['#008580', '#34880F', '#BF610F', '#A8166D','#6637D5','#1564B5'],
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                        type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                legend: {
                    data: ['Forest', 'Steppe', 'Desert', 'Wetland']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    top:'5%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: []
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'Discovery',
                        type: 'bar',
                        data: []
                    },
                    {
                        name: 'Development',
                        type: 'bar',
                        data: []
                    },
                    {
                        name: 'SIT',
                        type: 'bar',
                        data: []
                    },
                    {
                        name: 'UAT',
                        type: 'bar',
                        data: []
                    },
                    {
                        name: 'Deployment Readiness',
                        type: 'bar',
                        data: []
                    },
                    {
                        name: 'Production',
                        type: 'bar',
                        data: []
                    },
                ]
            }
        }
    }

    public componentDidMount() {
        this.getDetails()
        this.getDateList()
        this.getmessage()
        this.getlocalStorage()
    }
    public componentDidUpdate(Props, State) {
    }
  
    onSecondCityChange = (value) => {
        this.setState({
            date:value
        },()=>{
            this.getDetails()
        })
    }
    private getlocalStorage(){
         const storage =localStorage.getItem('react-storage')|| '{}'
         const storagemesg=JSON.parse(storage)
         
        storagemesg.user.roleList.forEach((item, index)=>{
            if(item.authority=='ROLE_08'||item.authority=='ROLE_09'){
                this.setState({
                    ImgShow:true
                })
                return
            }
        })
    } 
    private getDateList(){
        this.reviewService
        .date(
            new RequestParams({
            })
        )
        .subscribe(data => {
            this.setState({
                dateList:data
            })
        })
    }
    private getmessage() {
        this.reviewService
            .messageGet(
                new RequestParams({
                })
            )
            .subscribe(data => {
                this.setState({
                    standardMessage:data.standardMessage,
                    publicMessage:data.publicMessage
                })
            })
    }
    private getDetails() {
        this.reviewService
            .details(
                new RequestParams({
                    date:this.state.date,
                })
            )
            .subscribe(data => {
                let datas: any[] = [];
                let discovery: any[] = []
                let development: any[] = []
                let sit: any[] = []
                let uat: any[] = []
                let deploymentReadiness: any[] = []
                let production: any[] = []
                this.setState({
                    dataSource: data,
                })
                data.pop()
                data.forEach((item, index) => {
                    this.state.cbSysName.push()
                    // item.cbSysName.delete('grandTotal');
                    datas.push(item.cbSysName);
                    discovery.push(item.discovery);
                    development.push(item.development);
                    sit.push(item.sit)
                    uat.push(item.uat)
                    deploymentReadiness.push(item.deploymentReadiness)
                    production.push(item.production)
                })
                const datalist = Object.assign({}, this.state.getOption,{xAxis: [ { type: 'category',data: datas} ],  series: [
                    {
                        name: 'Discovery',
                        type: 'bar',
                        data: discovery
                    },
                    {
                        name: 'Development',
                        type: 'bar',
                        data: development
                    },
                    {
                        name: 'SIT',
                        type: 'bar',
                        data: sit
                    },
                    {
                        name: 'UAT',
                        type: 'bar',
                        data: uat
                    },
                    {
                        name: 'Deployment Readiness',
                        type: 'bar',
                        data: deploymentReadiness
                    },
                    {
                        name: 'Production',
                        type: 'bar',
                        data: production
                    },
                ]});
                this.setState({
                    getOption: datalist,
                }, () => {
                
                })

            })
    }
    public render() {
        return (
            <components.PageContainer
                width="100%"
                title="Homepage"
                noHeader={true}
            >
                {this.renderPageContent()}
            </components.PageContainer>
        )
    }
    private renderPageContent() {
        const { Header, Footer, Sider, Content } = Layout;
        return (
            <div  style={{padding:10, background:"#F3F3F3"}}>

                <Row gutter={[10, 10]} style={{height:'590px'}}>
                    <Col span={12}>
                            {this.renderApiSummaryChart()}
                    </Col>
                    <Col span={12}>
                            {this.renderGuidelines()}
                            {this.renderGuidebottom()}
                    </Col>
                </Row>
            </div>
        )
    }
    private openForm() {
        this.setState({
            reviewModalVisiblform: true
        })
    }
    private openPublic() {
        this.setState({
            reviewModalVisibPublicl: true
        })
    }
    private submitActionform() {
        this.reviewService
            .messagePost(
                new RequestParams({
                    titleName:this.actionFormpen.formInstance.getFieldValue('titleName'),
                    titleLink:this.actionFormpen.formInstance.getFieldValue('titleLink'),
                    contents:this.state.editorState.toHTML(),
                    messageType: "1"
                })
            )
            .subscribe(data => {
                this.closeReviewModalform()
                this.getmessage()
            })
    }
    private closeReviewModalform() {
        this.setState({
            reviewModalVisiblform: false
        })
        this.actionFormpen.formInstance.resetFields()
    }
    private get actionFormpen(): DataForm {
        return this.actionFromForm.current as DataForm
    }
    private get actionFormPublic(): DataForm {
        return this.actionFromPublic.current as DataForm
    }
    handleEditorChange = (editorState) => {
        this.setState({
            editorState: editorState
        })
    }
    handleMaxLength = () => {
        message.info('最多只能输入200个字符')
    };
    private Detailsmesg(item){
        this.reviewService
            .messageDelete(
                new RequestParams({}, { append: [item.messageId] })
            )
            .subscribe(data => {
                this.getmessage()
            })
    }
    private renderGuidelines() {
        const { editorState, Active, Delete, controls,standardMessage,ImgShow} = this.state
        const { Title } = Typography;
        console.log(standardMessage)
        return (
            <div className='rightTOP'>
                <Card title="Core Banking API Guidelines and Standards"
                style={{height:'280px',overflow:'auto',}}
                    extra={
                        <div style={{ width: '18px', height: '18px',cursor:'pointer', marginRight: '20px' }}>
                            <img src={Active}
                                 style={styles().input(
                                    ImgShow
                                )}
                            onClick={() => {
                                this.openForm()
                            }} />
                        </div>

                    }
                >
                     {this.renderJumpDatas()}
                    <Row gutter={[10, 10]}>
                    {standardMessage.map((item,index)=>{
                        return(
                            <Col span={12} className='contentCard' key={index}>
                            <Card style={{ width: '100%',height:90}}>
                             <a style={{textDecoration:'underline',color:'#333'}} target="_blank" href={item.titleLink} className='text-hidden'>{item.titleName}</a>
                              <div style={{width: '18px',cursor:'pointer', height: '18px', marginRight: '20px', float: 'right', }}>
                                           <img src={Delete}      style={styles().input(
                                            ImgShow
                                        )} onClick={() => {
                                            this.Detailsmesg(item)
                                        }}  />
                              </div>
                       
                                <p dangerouslySetInnerHTML={{__html:item.contents}} className='content-card-p'/>
                            </Card>
                          </Col>
                        )
                    })}
                  </Row>

                </Card>
                <Modal
                    title='Add Guidelines and Standards'
                    visible={this.state.reviewModalVisiblform}
                    okText="Submit"
                    onOk={() => this.submitActionform()}
                    onCancel={() => this.closeReviewModalform()}
                    width="680px"
                    okType="primary"
                    cancelText="Close"
                >
                    <div
                        style={{
                            color: '#333333',
                            fontSize: 14,
                            fontWeight: 300,
                            paddingLeft: 20
                        }}
                    >
                        <DataForm
                            name="actionFrom"
                            ref={this.actionFromForm}
                            column={1}
                            //   labelCol={{ span: 4 }}
                            labelAlign="left"
                        >
                            <DataForm.Item name="titleName" label="Title" rules={[{ required: true }]}>
                                <Input />
                            </DataForm.Item>
                            <DataForm.Item name="titleLink" label="Link" rules={[{ required: true }]}>
                                <Input />
                            </DataForm.Item>
                            <DataForm.Item name="contents" label="Content" rules={[{ required: true }]}>
                                <BraftEditor
                                    language='en'
                                    className="my-editor"
                                    value={editorState}
                                    controls={controls}
                                    onChange={this.handleEditorChange}
                                    placeholder="lnput text(Max/150)"
                                />
                            </DataForm.Item>
                        </DataForm>
                    </div>
                </Modal>
            </div>
        )
    }
    private renderGuidebottom() {
        const { Active, DeleteTwo, editorState, controls,publicMessage,ImgShow } = this.state
        return (
            <div className='rightBottom'>
                <Card title="Public Message"
                style={{height:'294px',overflow:'auto',marginTop: '6px',}}
                    extra={
                        <div  style={{ width: '18px',cursor:'pointer', height: '18px', marginRight: '20px' }}>
                            <img src={Active}
                                style={styles().input(
                                    ImgShow
                                )}
                             onClick={() => {
                                this.openPublic()
                            }} />
                        </div>

                    }
                >
                    <Row gutter={[10, 10]} style={{padding: "0px 5px",}}>
                    {publicMessage.map((item,index)=>{
                        return(
                        <Col span={24} className='contentCard'  key={index}>
                            <Card style={{ width: '100%',height:120}}>
                                <div style={{ width: '18px',cursor:'pointer', height: '18px', marginRight: '20px', float: 'right' }}>
                                          <img src={DeleteTwo}
                                           style={styles().input(
                                            ImgShow
                                        )}
                                          onClick={() => {
                                            this.Detailsmesg(item)
                                        }}  />
                                </div>
                          
                                <div style={{fontSize:'20px'}}>{item.titleName}</div>
                              <span style={{fontSize:'12px',color:'#DDDDDD'}}>{item.createTime}</span>
                                <p style={{marginTop:'10PX'}}  dangerouslySetInnerHTML={{__html:item.contents}}></p>
                            </Card>
                        </Col>
                        )
                    })}
                        
                    </Row>

                </Card>
                <Modal
                    title='Add Public Message'
                    visible={this.state.reviewModalVisibPublicl}
                    okText="Submit"
                    onOk={() => this.submitActionPublic()}
                    onCancel={() => this.closeReviewModalPublic()}
                    width="680px"
                    okType="primary"
                    cancelText="Close"
                >
                    <div
                        style={{
                            color: '#333333',
                            fontSize: 14,
                            fontWeight: 300,
                            paddingLeft: 20
                        }}
                    >
                        <DataForm
                            name="actionFrom"
                            ref={this.actionFromPublic}
                            column={1}
                            //   labelCol={{ span: 4 }}
                            labelAlign="left"
                        >
                            <DataForm.Item name="titleName" label="Title" rules={[{ required: true }]}>
                                <Input />
                            </DataForm.Item>
                            <DataForm.Item name="contents" label="Content" rules={[{ required: true }]}>
                                <BraftEditor

                                    language='en'
                                    className="my-editor"
                                    value={editorState}
                                    controls={controls}
                                    onChange={this.handleEditorChange}
                                    placeholder="lnput text(Max/150)"
                                />
                            </DataForm.Item>
                        </DataForm>
                    </div>
                </Modal>
            </div>
        )
    }
    private submitActionPublic() {
        this.reviewService
        .messagePost(
            new RequestParams({
                titleName:this.actionFormPublic.formInstance.getFieldValue('titleName'),
                contents:this.state.editorState.toHTML(),
                messageType: "2"
            })
        )
        .subscribe(data => {
            this.closeReviewModalPublic()
            this.getmessage()
        })
    }
    private closeReviewModalPublic() {
        this.setState({
            reviewModalVisibPublicl: false
        })
        this.actionFormPublic.formInstance.resetFields()
    }
    private renderApiSummaryChart() {
        const { center } = this.state
        const columns = [
            {
                title: 'CB System',
                dataIndex: 'cbSysName',
                align: center,
            },
            {
                title: 'Discovery',
                dataIndex: 'discovery',
                align: center,
            },
            {
                title: 'Development',
                dataIndex: 'development',
                align: center,
            },
            {
                title: 'SIT ',
                dataIndex: 'sit',
                align: center,
                width:'auto'
            },
            {
                title: 'UAT ',
                dataIndex: 'uat',
                align: center,
                width:'auto'
            },
            {
                title: 'Deployment Readiness ',
                dataIndex: 'deploymentReadiness',
                align: center,
            },
            {
                title: 'Production ',
                dataIndex: 'production',
                align: center,
            },
            {
                title: 'Grand Total ',
                dataIndex: 'total',
                align: center,
            },
        ]
        const { dataSource, getOption,dateList } = this.state;
        return (
            <div className="leftCard">
                <Card title="OSS Core Banking API Demand"
                style={{height:'580px'}}
                extra={
                        <Select
                        style={{ width: 120 }}
                        value={this.state.date}
                        onChange={this.onSecondCityChange}
                      >
                      <Select.Option value=''>Overall</Select.Option>
                       {dateList.map(item => (
                             <Select.Option value={item.createDate} key={item.createDate}>{item.createDate}</Select.Option>
                        ))}
                      </Select>
                }>
                    <ReactEchartsCore
                        style={{ background: '#fff', width: '100%', height: '260px', }}
                        echarts={echarts}
                        option={getOption}
                    />
                    <Table
                        //  style={{height: '290px', }}  
                        columns={columns}
                        dataSource={dataSource}
                        size="small"
                        pagination={false}
                        rowKey="cbSysName"
                        rowClassName={(record,index) => (record.cbSysName === 'grandTotal' ?'csbsTypes':'')}
                    />
               
                </Card>
             </div>
        )
    }

    private stepClick(current) {
        console.log(current)
        const { histroyGo } = homePageJumpDatas[current];
        if (histroyGo) {
            this.props.history.push(histroyGo)
        }
    }

    private renderJumpDatas() {
        const { Step } = Steps;
        return (
            <Steps className='home-page-step' onChange={(current)=>{this.stepClick(current)}} current={this.state.currentHomeStep}>
                {homePageJumpDatas.map(item => {
                    const { title, iconSrc } = item;
                    return <Step title={title} icon={<img style={{ width: 45, height: 45 }} src={iconSrc} />} />
                })}
            </Steps>
        )
    }


}
