import createRequest from '~/assets/svg/CreateRequest-Approve.svg';
import uploadContract from '~/assets/svg/Upload Contract.svg';
import AssignReviewer from  '~/assets/svg/Assign Reviewer-Approve.svg';
import DesignReview from '~/assets/svg/DesignReview.svg';
import RDRReview from '~/assets/svg/RDRReview.svg';
import APICatalogue from '~/assets/svg/APICatalogue.svg';

interface homePageJumpDatasPro {
    title: String;
    iconSrc: any;
    histroyGo?:any;
};

export const homePageJumpDatas: homePageJumpDatasPro[] = [
    {
        title: 'Create Request',
        iconSrc: createRequest,
        histroyGo:'/pages/demand-request-form'
    },
    {
        title: 'Upload Contract',
        iconSrc: uploadContract,
        histroyGo:'/pages/api-review-request-list'
    },
    {
        title: 'Assign Reviewer',
        iconSrc: AssignReviewer,
        histroyGo:null
    },
    {
        title: 'Demand/Design',
        iconSrc: DesignReview,
        histroyGo:'/pages/api-demand-request-list'
    },
    {
        title: 'PDR/GBDR/GTDR',
        iconSrc: RDRReview,
        histroyGo:'/pages/api-review-request-list'
    },
    {
        title: 'API Catalogue',
        iconSrc: APICatalogue,
        histroyGo:'/pages/api-catalogue'
    }
]