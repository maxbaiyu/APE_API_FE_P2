import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import DataTable from '~/shared/components/data-table'
import Column from 'antd/lib/table/Column'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { Form, Input, Select, DatePicker, Button, message } from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import { AccountService } from '~/services/account.service'
import { PageService } from '~/bootstrap/services/page.service'
import { RequestParams } from '~/core/http'
import AuthorizationModal from '~/components/authorization-modal'
import CustomizeModal from '~/shared/components/customize-modal'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { SortService } from '~/bootstrap/services/sort.service'
import { DictUtil } from '~/shared/utils/dict.util'
const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface AccountAuthorityState {
    dataSource: any[]
    selectedRowKeys: any[]
    authorizationModalVisible: boolean
    successModalVisible: boolean
}

interface AccountAuthorityProps {}

export default class AccountAuthority extends Component<
    RouteComponentProps<AccountAuthorityProps>,
    AccountAuthorityState
> {
    private accountService = new AccountService()
    private pageService = new PageService()
    private sortService = new SortService({
        staffId: 'ASC'
    })
    private searchFormRef!: React.RefObject<DataForm>
    private dictUtil = new DictUtil()

    constructor(props) {
        super(props)
        this.searchFormRef = React.createRef()
        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            authorizationModalVisible: false,
            successModalVisible: false
        }
    }

    public componentDidMount() {
        this.getAccountList()
    }

    private renderFormAction() {
        return (
            <Button type="primary" danger onClick={() => this.getAccountList()}>
                Search
            </Button>
        )
    }

    public render() {
        const {
            dataSource,
            selectedRowKeys,
            authorizationModalVisible
        } = this.state
        const { Option } = Select

        return (
            <components.PageContainer title="Account Authotiry">
                <CardContainer title="Search">
                    <DataForm
                        name="demo-form"
                        column={2}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        actions={this.renderFormAction()}
                        ref={this.searchFormRef}
                    >
                        <DataForm.Item name="staffId" label="Staff ID">
                            <Input />
                        </DataForm.Item>
                        <DataForm.Item name="staffName" label="Staff Name">
                            <Input />
                        </DataForm.Item>
                    </DataForm>
                </CardContainer>
                <CardContainer title="Account List">
                    <div
                        className="flex-row justify-content-end padding-y"
                        style={{ height: 50 }}
                    >
                        <DataForm name="contractPath" column={2}>
                            <Form.Item>
                                <components.AuthDisableButton
                                    type="primary"
                                    onClick={() =>
                                        this.openAuthorizationModal()
                                    }
                                    auth={['ROLE_09']}
                                >
                                    Authorize
                                </components.AuthDisableButton>
                            </Form.Item>
                            <Form.Item>
                                <components.AuthDisableButton
                                    type="primary"
                                    onClick={() => this.openDisable()}
                                    auth={['ROLE_09']}
                                >
                                    Disable
                                </components.AuthDisableButton>
                            </Form.Item>
                        </DataForm>
                    </div>
                    <DataTable
                        rowKey="staffId"
                        dataSource={dataSource}
                        page={this.pageService}
                        onPageChange={() => this.getAccountList()}
                        rowSelection={{
                            selectedRowKeys,
                            onChange: selectedRowKeys =>
                                this.setState({ selectedRowKeys })
                        }}
                        onChange={(pagination, filters, sorter) => {
                            console.log(sorter)
                            if (sorter.order) {
                                this.sortService.update(
                                    sorter.columnKey,
                                    sorter.order
                                )
                            } else {
                                this.sortService.reset()
                            }
                            this.getAccountList()
                        }}
                    >
                        <Column
                            ellipsis={true}
                            title="Staff ID"
                            dataIndex="staffId"
                            key="staffId"
                            sorter={true}
                        />
                        <Column
                            ellipsis={true}
                            title="Staff Name"
                            dataIndex="accName"
                            key="accName"
                        />
                        <Column
                            ellipsis={true}
                            title="Job Title"
                            dataIndex="title"
                            key="title"
                        />
                        <Column
                            ellipsis={true}
                            title="Department"
                            dataIndex="department"
                            key="department"
                        />
                        <Column
                            ellipsis={true}
                            title="Email"
                            dataIndex="emailAddress"
                            key="emailAddress"
                        />
                        <Column
                            ellipsis={true}
                            title="Role"
                            dataIndex="accRType"
                            key="accRType"
                            render={value => this.renderRole(value)}
                        />
                    </DataTable>
                </CardContainer>
                <AuthorizationModal
                    visible={authorizationModalVisible}
                    onCancel={() => this.closeAuthorizationModal()}
                    onOk={checkedRoles => this.authorization(checkedRoles)}
                ></AuthorizationModal>
                {this.renderModal()}
            </components.PageContainer>
        )
    }
    private renderRole(roles) {
        // renderRole
        const l = roles.split(',')

        return (
            <div>
                {l.map(x => (
                    <p key={x}>{this.dictUtil.filter('user_role', x)}</p>
                ))}
            </div>
        )
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Account List -->"
                cancelText="Close"
                content="Check Status in Account List."
                onOk={() => {
                    this.getAccountList()
                    this.closeSuccessModal()
                    this.setState({
                        selectedRowKeys: []
                    })
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private getAccountList() {
        this.accountService
            .all(
                new RequestParams(
                    Object.assign(
                        this.searchForm.formInstance.getFieldsValue(),
                        {}
                    ),
                    {
                        page: this.pageService,
                        sort: this.sortService
                    }
                )
            )
            .subscribe(data => {
                this.setState({
                    dataSource: data
                })
            })
    }

    private openDisable() {
        const { selectedRowKeys } = this.state
        if (selectedRowKeys.length == 0) {
            message.error('Please select at least one Staff')
            return
        }

        this.accountService
            .active(
                new RequestParams({
                    active: '1',
                    staffIds: selectedRowKeys
                })
            )
            .subscribe(data => {
                this.closeAuthorizationModal()
                this.openSuccessModal()
            })
    }
    private openAuthorizationModal() {
        const { selectedRowKeys } = this.state
        if (selectedRowKeys.length == 0) {
            message.error('Please select at least one Staff')
            return
        }
        this.setState({
            authorizationModalVisible: true
        })
    }
    private closeAuthorizationModal() {
        this.setState({
            authorizationModalVisible: false
        })
    }
    private authorization(checkedRoles) {
        const { selectedRowKeys } = this.state
        if (checkedRoles.length == 0) {
            message.error('Please select at least one Role')
            return
        }
        console.log(checkedRoles.toString())
        console.log(selectedRowKeys)

        this.accountService
            .role(
                new RequestParams({
                    accRType: checkedRoles.toString(),
                    staffIds: selectedRowKeys
                })
            )
            .subscribe(data => {
                this.closeAuthorizationModal()
                this.openSuccessModal()
            })
    }

    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private get searchForm(): DataForm {
        return this.searchFormRef.current as DataForm
    }
}
