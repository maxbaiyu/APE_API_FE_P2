/**
 * Review Service
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'homepage'

export const homepageController = {
    messageGet: {
        controller,
        action: 'message',
        type: RequestMethod.Get
    },
    messagePost: {
        controller,
        action: 'message',
        type: RequestMethod.Post
    },
    messageDelete: {
        controller,
        action: 'message',
        type: RequestMethod.Delete
    },
    details: {
        controller,
        action: 'demand/details',
        type: RequestMethod.Get
    },
    date: {
        controller,
        action: 'demand/date',
        type: RequestMethod.Get
    },
}
