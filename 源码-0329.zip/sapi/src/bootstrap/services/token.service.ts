import { ExtendService, RequestParams } from '~/core/http'
const STORAGE_KEY = 'react-storage'

// token service
export class TokenService extends ExtendService {
    public before = params => {
        const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')

        if (data && data.user && data.user.token) {
            params.options.header = params.options.header || {}
            params.options.header['Authorization'] = data.user.token
        }
    }
}
