/**
 * Review Service
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'user-center'

export const userCenterController = {
    taskGet: {
        controller,
        action: 'task',
        type: RequestMethod.Get
    },
    centerMes: {
        controller,
        action: '',
        type: RequestMethod.Get
    }
}
