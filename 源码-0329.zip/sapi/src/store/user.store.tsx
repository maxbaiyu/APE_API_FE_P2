import React, { useEffect, useRef } from 'react'
import { useState } from 'react'
import { Provider as StoreProvider } from 'reto'
import { RequestParams } from '~/core/http'
import { PersistState } from './plugins/persist'
import launchBoot from '~/bootstrap/boots/launch.boot'
import { values } from 'ramda'

export interface User {}

export function UserStore() {
    const [state, setState] = useState(
        PersistState('user', {
            token: '',
            resultBody: 0
        } as any)
    )

    function login(value) {
        setState(value)
    }

    function logout(value) {
        setState({})
        setTimeout(()=>{
            localStorage.removeItem('preUserOperateInfo')
        })
        localStorage.removeItem('href')
    }
    function task(value) {
        setState(
            PersistState('user', {
                msgCount: value
            })
        )
    }
    function taskout(value) {
        setState({ ...state, msgCount: value })
    }

    return Object.assign(
        {
            key: 'user',
            state,
            setState
        },
        { login, logout, task, taskout }
    )
}
export const UserStoreProvider = props => (
    <StoreProvider of={UserStore}>{props.children}</StoreProvider>
)
