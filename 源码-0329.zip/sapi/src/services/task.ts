/**
 * Login Service
 */
import { Request, RequestParams } from '~/core/http'
import { Observable } from 'rxjs'
import { userCenterController } from '~/config/services/task'

export class taskService {
    /**
     * login
     */
    @Request({
        server: userCenterController.taskGet
    })
    public taskGet(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }

    @Request({
        server: userCenterController.centerMes
    })
    public centerMes(requestParams: RequestParams): Observable<any> {
        return requestParams.request()
    }
}
