import React from 'react'
import styled from 'styled-components'
import { Card } from 'antd'
import { DictUtil } from '~/shared/utils/dict.util'

const components = {
    Wrapper: styled.section`
        width: 100%;
    `
}

interface ComponentProp {
    className?: string
    title?: string
    theme?: string
    status?: string
}

export default class NotificationContainer extends React.Component<
    ComponentProp
> {
    private dictUtil = new DictUtil()
    private defaultTheme = 'approved'
    private themes = {
        approved: {
            background: '#E5F2F2',
            border: '1px solid #00847F',
            boxSizing: 'border-box',
            titleColor: '#00847F',
            icon: require('~/assets/images/approved.png'),
            iconText: 'Approved'
        },
        approvedWithDispensation:{
            background: '#E5F2F2',
            border: '1px solid #00847F',
            boxSizing: 'border-box',
            titleColor: '#00847F',
            icon: require('~/assets/images/approved.png'),
            iconText: 'Approved with Dispensation'
        },
        rejected: {
            background: '#F9F2F3',
            border: '1px solid #A8000B',
            titleColor: '#A8000B',
            icon: require('~/assets/images/rej.png'),
            iconText: 'Rejected'
        },
        inProgress: {
            background: '#EBEFF4',
            border: '1px solid #3E505D',
            titleColor: '#305A85',
            icon: require('~/assets/images/inProgress.png'),
            iconText: 'In Progress'
        },
        verify: {
            background: '#fff',
            border: '1px solid #00847F',
            boxSizing: 'border-box',
            titleColor: '#333333',
            /*  icon: require(''), */
            iconText: 'In Progress'
        }
    }

    public render() {
        let { theme, className, title, status } = this.props
        let currentTheme = this.themes[theme ?? this.defaultTheme]

        return (
            <components.Wrapper className={className}>
                <div
                    style={{
                        background: currentTheme.background,
                        border: currentTheme.border,
                        boxSizing: currentTheme.boxSizing
                    }}
                >
                    <div
                        className="flex-row justify-content-between"
                        style={{
                            fontSize: '1.2em',
                            paddingLeft: '2.14em',
                            paddingTop: '1.43em',
                            fontWeight: 500
                        }}
                    >
                        <div>{title}</div>

                        <div
                            style={{
                                color: currentTheme.titleColor,
                                paddingRight: 20,
                                fontSize: '1.2em'
                            }}
                        >
                            <img src={currentTheme.icon}></img>
                            {this.dictUtil.filter(
                                'design_review_status',
                                status
                            )}
                        </div>
                    </div>
                    <div
                        style={{
                            fontSize: '1em',
                            paddingLeft: '2.14em',
                            paddingTop: '1.43em'
                        }}
                    >
                        {this.props.children}
                    </div>
                </div>
            </components.Wrapper>
        )
    }
}
