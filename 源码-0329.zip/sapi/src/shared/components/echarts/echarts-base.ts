import echarts from 'echarts/lib/echarts';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/toolbox';
import 'echarts/lib/component/title';
import 'echarts/lib/component/legend';
import 'echarts/lib/component/grid';
import 'echarts/lib/component/markPoint'
import EchartsComponent from './echarts-component';

const loadingOption = {
  // text: 'loading...',
  color: '#1890ff',
  textColor: '#1890ff'
};

// todo ts.json
export {
  echarts,
  loadingOption,
  EchartsComponent
};

