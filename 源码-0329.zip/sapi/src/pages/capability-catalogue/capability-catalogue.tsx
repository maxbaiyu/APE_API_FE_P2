import React, { useState, useRef, useEffect } from 'react';

import { Menu } from 'antd';
import PageContainer from '~/shared/components/page-container';
import CapabilityCatalogueManagement from './capability-catalogue-right';
import { RequestParams } from '~/core/http';
import { DictUtil } from '~/shared/utils/dict.util';
import { ReviewService } from '~/services/review.service';
import { ApiService } from '~/services/api.service'
import { CapabilityService } from '~/services/capability.service';

import styled from 'styled-components';

import { TableListItem } from './data';

const { SubMenu } = Menu;
const components = {
    PageContainer: styled(PageContainer)``
};

const dictUtil = new DictUtil();
const reviewService = new ReviewService();
const capabilityService = new CapabilityService();

const allKeys = {};

const CapabilityCatalogue = () => {

    const [openKeys, setOpenKeys] = useState<string[]>([]);
    const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
    const [subMenu, setSubMenu] = useState([]);
    const [dataSource, setDataSource] = useState<TableListItem[]>([]);
    const [totalServiceCont, setTotalServiceCont] = useState(0);
    const [featureCont, setFeature] = useState(0);
    const [serviceCont, setService] = useState(0);
    const [refreshContainer, setRefreshContainer] = useState(false);
    const [loading, setLoading] = useState<boolean>(false)

    const rootSubmenuKeys = useRef<string[]>([]);
    const childRef: any = useRef<HTMLDivElement>(null);;

    const onOpenChange = openChangeKeys => {
        // todo
        childRef.current.resetFields();
        const latestOpenKey: string = openChangeKeys.find(key => openKeys.indexOf(key) == -1);
        let feature: string = '';
        if (!rootSubmenuKeys.current.includes(latestOpenKey)) {
            setOpenKeys(openChangeKeys);
            if (openChangeKeys && openChangeKeys.length) {
                feature = allKeys[openChangeKeys[0]][0];
                setSelectedKeys([feature]);
                if (openChangeKeys.length) {
                    getServiceData({
                        capability: openChangeKeys[0],
                        feature
                    });
                }
            } else if (!openChangeKeys.length) {
                setSelectedKeys([]);
                setDataSource([]);
                setFeature(0);
                setService(0);
            }
        } else {
            feature = latestOpenKey ? allKeys[latestOpenKey][0] : null;
            setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
            setSelectedKeys(feature ? [feature] : []);
            if (latestOpenKey) {
                getServiceData({
                    capability: latestOpenKey,
                    feature
                });
            }
        }
    };

    const onMenuClick = ({ key }) => {
        setSelectedKeys([key]);
        childRef.current.resetFields();
        if (openKeys.length) {
            getServiceData({
                capability: openKeys[0],
                feature: key
            });
        };
    };

    const getServiceData = ({ page = 1, size = 10, capability = openKeys[0], feature = selectedKeys[0] }) => {
        const STORAGE_KEY = 'react-storage';
        const storageData = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || '{}'
        );
        setLoading(true);
        capabilityService
            .service(new RequestParams({
                page,
                size,
                capability,
                feature,
                ...childRef.current.getDataFormVal()
            }))
            .subscribe(data => {
                setLoading(false);
                if (data && data.serviceDetails && data.serviceDetails.content) {
                    const { serviceDetails, serviceCnt, featureCnt } = data;
                    const { content, totalElements } = serviceDetails;
                    let tableListDataSource: TableListItem[] = [];
                    for (let i = 0; i < content.length; i++) {
                        tableListDataSource.push({
                            key: i + (page - 1) * size,
                            batch: `/`,
                            ...content[i]
                        });
                    }
                    setTotalServiceCont(totalElements);
                    setDataSource(tableListDataSource);
                    setFeature(featureCnt);
                    setService(serviceCnt);
                }
            });
    };

    const getContainerStyle = () => {
        let container = document.getElementsByClassName('capability-catalogue');
        while (!container || (container && !container.length)) {
            container = document.getElementsByClassName('capability-catalogue');
        }
        const { left } = container[0].getBoundingClientRect();
        if (left > 0) {
            setRefreshContainer(!refreshContainer);
        }
    };

    useEffect(() => {
        let isFirstIn = true;
        let isFirstFeature = true;
        let firstCapDirCode = '';
        let firstFeatureDircode = '';
        const capabilityArr = dictUtil.dicts('capability').map(item => {
            rootSubmenuKeys.current.push(item.dirCode);
            if (isFirstIn) {
                isFirstIn = false;
                firstCapDirCode = item.dirCode;
                setOpenKeys([item.dirCode]);
            }
            let allSubKey: string[] = [];
            const featureArr = dictUtil.dicts(item.dirCode).map(element => {
                if (isFirstFeature) {
                    isFirstFeature = false;
                    firstFeatureDircode = element.dirCode;
                    setSelectedKeys([`${element.dirCode}`])
                }
                if (element.attribute2 == "feature") {
                    allSubKey.push(element.dirCode);
                    return <Menu.Item key={element.dirCode}>{element.dirName}</Menu.Item>
                };
            });
            allKeys[item.dirCode] = allSubKey;
            return <SubMenu key={item.dirCode} title={item.dirName}>{featureArr}</SubMenu>
        });
        setSubMenu(capabilityArr);
        getServiceData({
            capability: firstCapDirCode,
            feature: firstFeatureDircode
        });
        getContainerStyle();
    }, []);

    return (
        <components.PageContainer title="CB Service Catalogue" noHeader={true} width={'100%'} isNotNeedFlex={true}>
            <div className="flex-row capability-catalogue">
                <Menu
                    mode="inline"
                    openKeys={openKeys}
                    selectedKeys={selectedKeys}
                    onOpenChange={onOpenChange}
                    onClick={onMenuClick}
                    style={{ width: '20%' }}
                    forceSubMenuRender={true}
                >
                    {subMenu}
                </Menu>
                <CapabilityCatalogueManagement
                    loading={loading}
                    cRef={childRef}
                    dataSource={dataSource}
                    feature={featureCont}
                    service={serviceCont}
                    openKey={openKeys}
                    selectedKey={selectedKeys}
                    totalServiceCont={totalServiceCont}
                    getServiceData={getServiceData}
                />
            </div>
        </components.PageContainer>
    )
};

export default CapabilityCatalogue;