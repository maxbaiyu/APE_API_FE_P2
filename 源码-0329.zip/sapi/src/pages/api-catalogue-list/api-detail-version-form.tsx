import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { ApiService } from '~/services/api.service'
import { RequestParams } from '~/core/http'
import { DictUtil } from '~/shared/utils/dict.util'
import {
    Form,
    Input,
    Select,
    DatePicker,
    Table,
    Divider,
    Alert,
    Button,
    Upload,
    message
} from 'antd'
import { UploadOutlined } from '@ant-design/icons'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import CustomizeModal from '~/shared/components/customize-modal'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { FileService } from '~/services/file.service'
import appConfig from '~/config/app.config'
import { download } from '~/shared/utils/common.util'
import { any } from 'ramda'
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface ApiVersionDetailFormState {
    id: string
    data: any
    iwsPostmanJson:any
    sampleApiCall:any
    ptPostmanJson:any
    successModalVisible: boolean
    fileList:any
    fileListtwo:any
    fileListsn:any
}

interface ApiVersionDetailFormProps {}

export default class ApiDetailForm extends Component<
    RouteComponentProps<ApiVersionDetailFormProps>,
    ApiVersionDetailFormState
> {
    private dataFromRef!: React.RefObject<DataForm>

    private apiService = new ApiService()
    private fileService = new FileService()

    private dictUtil = new DictUtil()
    private versionApplicableChannels = ''
    private versionApplicableGbGf = ''
    private versionApplicableCountries = ''

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            ptPostmanJson:'',
            successModalVisible: false,
            iwsPostmanJson:'',
            sampleApiCall:'',
            fileList:[
                 {
                     uid:'-1',
                    name:'ces',
                }
            ],
            fileListtwo:[    {
                name:'',
                uid:'-2',
            }],
            fileListsn:[    {
                name:'',
                uid:'-3',
            }],
        }
    }

    public componentDidMount() {
        let idTrue;
        try {
            const { id } = this.props.location.state as ApiVersionDetailFormState
            idTrue = id
        } catch (error) {
            const searchArr = this.props.location.search.split('=')
            if (searchArr && searchArr.length >= 1) {
                idTrue = searchArr[1]
            }
        }
        this.apiService
            .getVersionById(new RequestParams({}, { append: [idTrue] }))

            .subscribe(data => {
                const datalist = Object.assign([], this.state.fileList,[{uid:'-1',name:data.iwsPostmanJson}])
                const datalistApiCall = Object.assign([], this.state.fileListtwo,[{uid:'-2',name:data.sampleApiCall}])
                const datalistpt = Object.assign([], this.state.fileListsn,[{uid:'-3',name:data.ptPostmanJson}])
                this.setState({
                    fileList:datalist,
                    fileListtwo:datalistApiCall,
                    fileListsn:datalistpt,
                    data: data,
                    iwsPostmanJson:data.iwsPostmanJson,
                    sampleApiCall:data.sampleApiCall,
                    ptPostmanJson:data.ptPostmanJson
                    
                })
                this.dataForm.formInstance.setFieldsValue(data)
            })
    }

    public render() {
        const { data,fileList,fileListtwo,fileListsn} = this.state
        if (data?.applicableChannels2 != null) {
            this.versionApplicableChannels =
                this.dictUtil.filter(
                    'applicable_channels',
                    data?.applicableChannels
                ) +
                ' - ' +
                data?.applicableChannels2
        } else {
            this.versionApplicableChannels = this.dictUtil.filter(
                'applicable_channels',
                data?.applicableChannels
            )
        }
        if (data?.applicableGbGf2 != null) {
            this.versionApplicableGbGf =
                this.dictUtil.filter('applicable_gb', data?.applicableGbGf) +
                '  -  ' +
                data?.applicableGbGf2
        } else {
            this.versionApplicableGbGf = this.dictUtil.filter(
                'applicable_gb',
                data?.applicableGbGf
            )
        }
        if (data?.applicableCountries2 != null) {
            this.versionApplicableCountries =
                this.dictUtil.filter(
                    'applicable_countries',
                    data?.applicableCountries
                ) +
                ' - ' +
                data?.applicableCountries2
        } else {
            this.versionApplicableCountries = this.dictUtil.filter(
                'applicable_countries',
                data?.applicableCountries
            )
        }
        // if(this.state.fileList.length!==0){
        //     this.state.fileList[0].name=data?.iwsPostmanJson
        // }
        const uploadProps = {
            key: "iws.postman",
            name: 'file',
            action: appConfig.server + '/file/upload',
            // showUploadList:{
            //     showRemoveIcon:false
            // },
            fileList:fileList,
            beforeUpload: file => {

                this.uploadFileiws(file)
                return false
            },
            onPreview:info=>{
                download(
                    appConfig.server +'/file/download',info.name, {  fileName:info.name,functionType:'reviewContract'}
                )
            },
            onRemove:info=>{
                this.setState({
                    iwsPostmanJson:null,
                    
                })
            },
            onChange:info=> {
                let fileList = info.fileList
                fileList = fileList.slice(-1);
                // this.state.fileList[0]=fileList[0]
                this.setState({ fileList:fileList,});
                if (info.file.status !== 'uploading') {
                }
                if (info.file.status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully`
                    )
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            },
        }
        const uploadPropsPostman = {
            key: "pt.postman",
            name: 'file',
            action: appConfig.server + '/file/upload',
            fileList:fileListtwo,
            beforeUpload: file => {
                this.uploadFilePostman(file)
                return false
            },
            onPreview:info=>{
                download(
                    appConfig.server +'/file/download',info.name,{  fileName:info.name,functionType:'reviewContract'}
                )
            },
            onRemove:info=>{
                this.setState({
                    sampleApiCall:null,
                    
                })
            },
            onChange:info=> {
                let fileList = info.fileList
                fileList = fileList.slice(-1);
                // this.fileList
                this.setState({ fileListtwo:fileList });
                if (info.file.status !== 'uploading') {
                }
                if (info.file.status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully`
                    )
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }
        const uploadPropsptPostman = {
            key: "sample.api",
            name: 'file',
            action: appConfig.server + '/file/upload',
            fileList:fileListsn,
            beforeUpload: file => {
                this.uploadFileptptPostman(file)
                return false
            },
            onPreview:info=>{
                download(
                    appConfig.server +'/file/download',info.name,{  fileName:info.name,functionType:'reviewContract'}
                )
            },
            onRemove:info=>{
                this.setState({
                    ptPostmanJson:null,
                    
                })
            },
            onChange:info=> {
                let fileList = info.fileList
                fileList = fileList.slice(-1);
                this.setState({ fileListsn:fileList });
                if (info.file.status !== 'uploading') {
                }
                if (info.file.status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully`
                    )
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }
        return (
            <components.PageContainer
                title="API Version Detail"
                noHeader={true}
            >
                <div
                    style={{ fontSize: 28 }}
                    className="flex-row justify-content-between"
                >
                    <div>Customer Credit Card Creation</div>
                    <div>
                        <Button
                            size="large"
                            onClick={() => {
                                this.props.history.goBack()
                            }}
                        >
                            Back
                        </Button>
                    </div>
                </div>
                <Divider />

                <CardContainer title="Version v1.0.0">
                    <DataForm
                        ref={this.dataFromRef}
                        name="demo-form"
                        column={1}
                        labelCol={{ span: 8 }}
                        labelAlign="left"
                        formWidth={900}
                    >
                        <LabelContainer column={1} labelSpan={4}>
                            <LabelItem label="API Name">
                                {data?.apiName}
                            </LabelItem>
                            <LabelItem label="API Version">
                                {data?.version}
                            </LabelItem>
                            <LabelItem label="Project Name">
                                {data?.projectName}
                            </LabelItem>
                            <LabelItem label="Consumer">
                                {data?.consumer}
                            </LabelItem>
                            <LabelItem label="Core Banking API ID">
                                {data?.hubApiId}
                            </LabelItem>
                            <LabelItem label="Applicable Channels">
                                {this.versionApplicableChannels}
                            </LabelItem>
                            <LabelItem label="Applicable GB/GF">
                                {this.versionApplicableGbGf}
                            </LabelItem>
                            <LabelItem label="Applicable Countries">
                                {this.versionApplicableCountries}
                            </LabelItem>
                        </LabelContainer>
                        <Form.Item
                            name="trueSapiId"
                            label="API ID"
                            rules={[
                                {
                                    message:
                                        'API ID only contains letters, numbers and special character: -.',
                                    pattern: /^\w+[\w-]*$/
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="applicableHubVersion"
                            label="Applicable HUB Version"
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="apiLifecycleStage"
                            label="API Lifecycle Stage"
                        >
                            <Select disabled>
                                {this.dictUtil.dicts(
                                    'api_lifecycle_stage',
                                    dict => (
                                        <Select.Option
                                            key={dict.dirCode}
                                            value={dict.dirCode}
                                        >
                                            {dict.dirName}
                                        </Select.Option>
                                    )
                                )}
                            </Select>
                        </Form.Item>
                        <Form.Item name="hubPgmFlow" label="HUB PGM Flow">
                            <Input />
                        </Form.Item>
                        <Form.Item name="enhancement" label="Enhancement">
                            <Input />
                        </Form.Item>
                        <LabelContainer column={1}>
                            <LabelItem label="HUB API Documents">
                                <div className="full-width">
                                    <Form.Item
                                        name="hubApiContract"
                                        label="API Contract"
                                    >
                                        <Input disabled />
                                    </Form.Item>
                                    <Form.Item
                                        name="hubErrorScenario"
                                        label="Error Scenario"
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="hubFunctionalDesign"
                                        label="Functional Design"
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="iwsPostmanJson"
                                        label="IWS Postman JSON Data"
                                    >
                                        <Upload {...uploadProps}>
                                            <Button
                                                style={{
                                                    width: 450,
                                                    textAlign: 'center'
                                                }}
                                                icon={<UploadOutlined />}
                                            >
                                                Upload
                                            </Button>
                                        </Upload>
                                        {/* <Input /> */}
                                    </Form.Item>
                                </div>
                            </LabelItem>
                            <LabelItem label="Mul API Documents">
                                <div className="full-width">
                                    <Form.Item
                                        name="apiCertPcfUrl"
                                        label="CERT PCF URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiInteralGatewayUrl"
                                        label="Internal Gateway URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiGitRepo"
                                        label="Git Repository URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiJenkinsUrl"
                                        label="Jenkins URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiRaml"
                                        label="RAML URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="apiPostmanJsonData"
                                        label="Mule Postman JSON URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                </div>
                            </LabelItem>
                            <LabelItem label="Certification Result">
                                <div className="full-width">
                                    <Form.Item
                                        name="certificatePageUrl"
                                        label="URL"
                                        rules={[
                                            {
                                                message: 'please input url',
                                                pattern: /^(https?|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/
                                            }
                                        ]}
                                    >
                                        <Input />
                                    </Form.Item>
                                    <Form.Item
                                        name="ptPostmanJson"
                                        label="PT Postman JSON Data"
                                    >
                                        <Upload {...uploadPropsptPostman}>
                                            <Button
                                                style={{
                                                    width: 450,
                                                    textAlign: 'center'
                                                }}
                                            >
                                                <UploadOutlined /> Upload
                                            </Button>
                                        </Upload>
                                        {/* <Input /> */}
                                    </Form.Item>
                                </div>
                            </LabelItem>
                            <LabelItem label="Sample API Call">
                                <div className="full-width">
                                    <Form.Item
                                        name="sampleApiCall"
                                        label="            "
                                    >
                                        {/* <Input /> */}
                                        <Upload {...uploadPropsPostman}>
                                            <Button
                                                style={{
                                                    width: 450,
                                                    textAlign: 'center'
                                                }}
                                            >
                                                <UploadOutlined /> Upload
                                            </Button>
                                        </Upload>
                                    </Form.Item>
                                </div>
                            </LabelItem>
                        </LabelContainer>
                        <Form.Item
                            name="versionRemarks"
                            label="Remarks"
                            rules={[
                                {
                                    type: 'string',
                                    max: 500,
                                    message: 'Maximum 500 characters'
                                }
                            ]}
                        >
                            <Input.TextArea
                                style={{
                                    width: '100%',
                                    textAlign: 'left'
                                }}
                                rows={4}
                                maxLength={500}
                            />
                        </Form.Item>
                    </DataForm>
                    <div
                        style={{ width: '100%' }}
                        className="flex-row justify-content-end"
                    >
                        <components.AuthDisableButton
                            type="primary"
                            size="large"
                            danger
                            onClick={() => this.submit()}
                            auth={['ROLE_01', 'ROLE_011']}
                        >
                            Submit
                        </components.AuthDisableButton>
                    </div>
                </CardContainer>
                {this.renderModal()}
            </components.PageContainer>
        )
    }
    private uploadFileiws(file) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('functionType', 'reviewContract')
        formData.append(' iwsPostmanJson', file.name)
        this.fileService
            .upload(
                new RequestParams(formData, {
                    header: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
            )
            .subscribe(data => {
                message.success('upload file success!')
                this.state.fileList[0].name=data.fileName
                this.setState({
                     iwsPostmanJson: data.fileName
                })
            })
    }
    private uploadFilePostman(file) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('functionType', 'reviewContract')
        formData.append('sampleApiCall', file.name)
        this.fileService
            .upload(
                new RequestParams(formData, {
                    header: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
            )
            .subscribe(data => {
                message.success('upload file success!')
                this.state.fileListtwo[0].name=data.fileName
                this.setState({
                    // contractPath: data.filePath
                    sampleApiCall: data.fileName
                })
            })
    }
    private uploadFileptptPostman(file) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('functionType', 'reviewContract')
        formData.append('ptPostmanJson', file.name)
        this.fileService
            .upload(
                new RequestParams(formData, {
                    header: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
            )
            .subscribe(data => {
                message.success('upload file success!')
                this.state.fileListsn[0].name=data.fileName
                this.setState({
                    // contractPath: data.filePath
                    ptPostmanJson: data.fileName
                })
            })
    }
    public renderModal() {
        const { data } = this.state
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}

                okText="API Detail -->"
                cancelText="Close"
                content="Check Information in API Detail page."
                onOk={() => {
                    this.props.history.push({
                        pathname: '/pages/api-catalogue/api-detail',
                        state: {
                            apiCatalogueId: data.apiCatalogueId
                        },
                        search: `apiCatalogueId=${data.apiCatalogueId}`
                    })
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private submit() {
        const { data, iwsPostmanJson,sampleApiCall,ptPostmanJson } = this.state
        this.dataForm.formInstance.validateFields().then(() => {
        this.apiService
            .updateVersion(
                new RequestParams({
                    ...this.dataForm.formInstance.getFieldsValue(),
                    versionId: data.versionId,
                    iwsPostmanJson:iwsPostmanJson,
                    sampleApiCall:sampleApiCall,
                    ptPostmanJson:ptPostmanJson
                })
            )
            .subscribe(data => {
                this.openSuccessModal()
            })
    }
        )}

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Demand Request Detail
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }

    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
}
