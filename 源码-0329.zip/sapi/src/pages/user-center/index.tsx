import React, { Component } from 'react'
import { RouteComponentProps } from 'react-router-dom'
import { Consumer } from 'reto'
import { Divider, Button } from 'antd'
import { UserStore } from '~/store/user.store'
import { taskService } from '~/services/task.ts'
import { RequestParams } from '~/core/http'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import CardContainer from '~/shared/components/card-container'
import UserCenterTodo from './user-center-todo'
import UserCenterNotification from './user-center-notification'
import { USER_CENTER_PREFIX } from './type'
import { TodolistDatas, NotificationDatas } from './data'

const components = {
    PageContainer: styled(PageContainer)``
}

interface UserProfileState {
    data: any
    todolistDatas: TodolistDatas[]
    notificationDatas: NotificationDatas[]
}

interface UserProfileProps {}

export default class UserCenter extends Component<
    RouteComponentProps<UserProfileProps>,
    UserProfileState
> {
    private taskService = new taskService()

    constructor(props) {
        super(props)
        this.state = {
            data: {},
            todolistDatas: [],
            notificationDatas: []
        }
    }

    public componentDidMount() {
        this.getUserCenterInfo('')
    }

    public getUserCenterInfo(apiName) {
        this.taskService
            .centerMes(new RequestParams({ apiName }))
            .subscribe(res => {
                const { task, notification } = res
                this.setState({
                    todolistDatas: task,
                    notificationDatas: notification
                })
            })
    }

    public render() {
        return (
            <Consumer of={UserStore}>
                {userStore => this.renderForm(userStore)}
            </Consumer>
        )
    }
    public renderForm(userStore) {
       
        const {
            notificationDatas,
            todolistDatas
        } = this.state

        return (
            <components.PageContainer
                title="User Center"
                noHeader={true}
                isNotNeedFlex={true}
                isNeedCenter={true}
                className={USER_CENTER_PREFIX}
            >
                <div className={`${USER_CENTER_PREFIX}-top`}>
                    <Button
                        size="large"
                        onClick={() => {
                            this.props.history.push({ pathname: '/home-page' })
                        }}
                    >
                        Back
                    </Button>
                </div>
                <Divider style={{ margin: '1rem 0 0' }} />
                <div className={`${USER_CENTER_PREFIX}-bottom`}>
                    <CardContainer title="To-Do List">
                        <UserCenterTodo
                            listData={todolistDatas}
                            userStore={userStore}
                        />
                    </CardContainer>
                    <CardContainer title="Notification">
                        <UserCenterNotification notiData={notificationDatas} />
                    </CardContainer>
                </div>
            </components.PageContainer>
        )
    }
}
