export const USER_CENTER_PREFIX = 'user-center';

export const TD_LIST_FILTER_BTN_WIDTH = 10;