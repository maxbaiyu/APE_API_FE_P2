import React, { useState, useEffect } from 'react'
import { List, Avatar } from 'antd'
import { PushpinOutlined } from '@ant-design/icons'

interface ListDataProps {
    notiData: any[]
}

const UserCenterNotification: React.FC<ListDataProps> = props => {
    const { notiData } = props

    return (
        <List
            itemLayout="horizontal"
            dataSource={notiData}
            renderItem={item => (
                <List.Item>
                    <List.Item.Meta
                        avatar={
                            <Avatar
                                icon={
                                    <PushpinOutlined
                                        style={{
                                            fontSize: '14px',
                                            color: '#333333'
                                        }}
                                    />
                                }
                            />
                        }
                        title={
                            <>
                                <span>{`[${item.title}]`}</span>
                                <span> {item.messagePrefix}</span>
                                <span className={'card-suffix-mes'}>
                                    {' '}
                                    {item.apiName}
                                    {' - '}
                                    {item.projectName}
                                </span>
                                <span className={'card-message'}>
                                    {' '}
                                    {item.message}
                                </span>
                            </>
                        }
                        description={`Operated by ${item.operator} at ${item.operatingTime}`}
                    />
                </List.Item>
            )}
        />
    )
}

export default UserCenterNotification
