import { ReactNode } from 'react'
export interface apiReviewDemandList {
    title:string
    dataIndex: string
    key:string
    Selectvalue?:string
    detaSelect?:Boolean
    inputSelect?:Boolean
    isSelect?:Boolean
    disabled?:Boolean
}
export const apiReviewDemandListHeaderGove:apiReviewDemandList[] = [
    {
        title: 'Capability',
        dataIndex: 'capability',
        key: 'capability',
        isSelect: true,
        Selectvalue:'capability'
    },
    {
        title: 'Feature',
        dataIndex: 'feature',
        key: 'feature',
        isSelect: true,
        Selectvalue:''
    },
    {
        title: 'Service',
        dataIndex: 'service',
        key: 'service',
        isSelect: true,
        Selectvalue:''
    },
]
export interface APIReviewDemandListColumnPropsGove {
    title: ReactNode | string
    render?: any
}