import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import DataTable from '~/shared/components/data-table'
import Column from 'antd/lib/table/Column'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { download } from '~/shared/utils/common.util'
import { dataConvert } from '~/shared/utils/form.data.convert';
import { layOutSize } from '~/shared/utils/common.util'
import appConfig from '~/config/app.config'
import {
    Modal,
    Form,
    Input,
    Select,
    DatePicker,
    Button,
    Divider,
    message
} from 'antd'
import dataSource from '~/assets/mock/api-data.json'

import LabelContainer from '~/shared/components/label-contaoner'
import ColumnGroup from 'antd/lib/table/ColumnGroup'
import CustomizeModal from '~/shared/components/customize-modal'
import { DemandService } from '~/services/demand.service'
import { FileService } from '~/services/file.service'
import { PageService } from '~/bootstrap/services/page.service'
import { RequestParams } from '~/core/http'
import LabelItem from '~/shared/components/label-item'
import { DictUtil } from '~/shared/utils/dict.util'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import { SortService } from '~/bootstrap/services/sort.service'
import { reduce, values } from 'ramda'
import imgsrcHelp from '~/assets/images/Help.png'
import imgsrcQm from '~/assets/images/qm.png'
import { spawn } from 'child_process'

const components = {
    PageContainer: styled(PageContainer)``,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

interface APIDemandRequestListState {
    dataSource: any[]
    selectedRowKeys: any[]
    selectedRows: any
    successModalVisible: boolean
    reviewModalVisible: boolean
    Loading: boolean
    fieldsValues: any
    hover: boolean
    seachDD:any[]
    apiLifecycleStage:String
    ApproveBoolean:boolean
}

interface APIDemandRequestListProps {}

export default class APIDemandRequestList extends Component<
    RouteComponentProps<APIDemandRequestListProps>,
    APIDemandRequestListState
> {
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private demandService = new DemandService()
    private fileService = new FileService()
    private pageService = new PageService()
    private sortService = new SortService({
        createDate: 'DESC'
    })
    private statusType = ''
    private demandStatus = ''
    private searchFormRef!: React.RefObject<DataForm>
    // private commontFormRef!: React.RefObject<Form>
    private isNotIE11 = !navigator.userAgent.includes('Trident')
    private homePageJumpSearch = ''

    constructor(props) {
        super(props)
        this.actionFromRef = React.createRef()
        this.searchFormRef = React.createRef()
        // this.commontFormRef = React.createRef()

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            selectedRows: [],
            Loading: true,
            successModalVisible: false,
            reviewModalVisible: false,
            fieldsValues: {},
            hover: false,
            seachDD:[],
            apiLifecycleStage:'',
            ApproveBoolean:true
        }
    }
    public componentDidMount() {
        const state = this.props.location.state as APIDemandRequestListState;
        if (state && state.fieldsValues) {
            const fieldsValues = dataConvert(true, state.fieldsValues);
            this.searchForm.formInstance.setFieldsValue(fieldsValues);
        }
        if (this.props?.location?.search) {
            this.homePageJumpSearch = this.props.location.search.replace(
                '?',
                ''
            )
        }
        this.getDemandList()
    }
     
    public render() {
        return (
            <components.PageContainer title="API Demand  List"  noHeader={true}>
                {this.renderFormContainer()}
                {this.renderTableContainer()}
                {this.renderModal()}
                {this.renderReviewModal()}
            </components.PageContainer>
        )
    }
    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Demand List -->"
                cancelText="Close"
                content="Check Status in Demand List."
                onOk={() => {
                    this.closeSuccessModal()
                    this.getDemandList()
                    this.setState({
                        selectedRowKeys: []
                    })
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }
    private editLink() {
        const fieldsValues = dataConvert(false, this.searchForm.formInstance.getFieldsValue());
        if(this.state.selectedRows.length!==0){
              this.props.history.push({
                pathname: '/pages/api-demand-edit',
                state: {
                    selectedRows:JSON.stringify(this.state.selectedRows),
                    fieldsValues,
                    pathName: '/pages/api-demand-request-list'
                }
            })
        }else{
            message.error('Please select data first') 
        }
      
    }
    onSecondCityChange = () => {
        alert('111')
    }
    public renderFormContainer() {
        const {seachDD}=this.state
        const { RangePicker } = DatePicker
        return (
            <CardContainer title="Search">
                <DataForm
                    name="search-form"
                    column={3}
                    labelCol={{ span: 11 }}
                    labelAlign="left"
                    actions={this.renderFormAction()}
                    ref={this.searchFormRef}
                >
                    <DataForm.Item name="projectName" label="Project Name">
                        <Input onPressEnter={this.replacement}/>
                    </DataForm.Item>
                    <DataForm.Item name="apiName" label="API Name">
                        <Input  onPressEnter={this.replacement}/>
                    </DataForm.Item>
                    <DataForm.Item
                        name="demandApprovalStatus"
                        label="Demand Approval Status"
                        initialValue=""
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'demand_status',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="targetLiveDate"
                        label="Target Live Date"
                        className="range-picker"
                    >
                        <RangePicker />
                    </DataForm.Item>
                    <DataForm.Item
                        name="demandClassification"
                        label="Demand Classification"
                        initialValue=""
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('api_classification', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="designApprovalStatus"
                        label="Design Approval Status"
                        initialValue=""
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'demand_status',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="cbApiContract"
                        label="Core Banking API Contact"
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('cb_api_contact', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="backendSystem"
                        label="Backend System"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('backend_system', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="designReviewApprovalStatus"
                        label="Design Review Status"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts(
                                'design_review_status',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="cbSystemContract"
                        label="Core Banking System Contact"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('cb_system_contact', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="apiType"
                        label="API Type"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('api_type', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="demandApprovalDate"
                        label="Demand Approval Date"
                        className="range-picker"
                        collapse
                    >
                        <RangePicker renderExtraFooter={() => 'extra footer'} />
                    </DataForm.Item>
                    <DataForm.Item name="requester" label="Requester" collapse>
                        <Input  onPressEnter={this.replacement}/>
                    </DataForm.Item>
                    <DataForm.Item
                        name="apiLifecycleStage"
                        label="API Lifecycle Stage"
                        collapse
                        className={'multiple-select-adaptIE'}
                    >
                        <Select 
                         mode="multiple"
                        allowClear>
                            {this.dictUtil.dicts(
                                'api_lifecycle_stage',
                                dict => (
                                    <Select.Option
                                        key={dict.dirCode}
                                        value={dict.dirCode}
                                    >
                                        {dict.dirName}
                                    </Select.Option>
                                )
                            )}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="designApprovalDate"
                        label="Design Approval Date"
                        className="range-picker"
                        collapse
                    >
                        <RangePicker />
                    </DataForm.Item>
                    <DataForm.Item
                        name="country"
                        label="Site"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('country', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item name="apiId" label="API ID" collapse>
                        <Input  onPressEnter={this.replacement} />
                    </DataForm.Item>
                    <DataForm.Item
                        name="designReviewApprovalDate"
                        label="Design Review Date"
                        className="range-picker"
                        collapse
                    >
                        <RangePicker />
                    </DataForm.Item>
                    <DataForm.Item
                        name="channel"
                        label="Channel"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('channel', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="originalSapiId"
                        label="Original API ID"
                        collapse
                    >
                        <Input  onPressEnter={this.replacement}/>
                    </DataForm.Item>
                    <DataForm.Item
                        name="platform"
                        label="Platform"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('platform', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                    <DataForm.Item
                        name="gbOrGF"
                        label="GB/GF"
                        initialValue=""
                        collapse
                    >
                        <Select allowClear>
                            {this.dictUtil.dicts('gb_gf', dict => (
                                <Select.Option
                                    key={dict.dirCode}
                                    value={dict.dirCode}
                                >
                                    {dict.dirName}
                                </Select.Option>
                            ))}
                        </Select>
                    </DataForm.Item>
                </DataForm>
            </CardContainer>
        )
    }
    private openBPidLink(row) {

        if(row.gdpmInterLockBpidYear!==null){
              let  linkYear=row.gdpmInterLockBpidYear.substring(row.gdpmInterLockBpidYear.length-2)
              window.location.href='https://planningdatamodel.it.global.hsbc/gpdm'+linkYear+'/billableProduct.asp?bpID='+row.gdpmInterLockBpid
        }
    
    }
    public renderTableContainer() {
        const { dataSource, selectedRowKeys,Loading } = this.state
        return (
            <CardContainer title="API Demand List">
                {this.renderApiDemandTips()}
                <components.AuthDisableButton
                    auth={['ROLE_01']}
                    size="large"
                    type="primary"
                    style={{
                        marginTop: -75,
                        float: 'right',
                        marginRight: 100
                    }}
                    onClick={() => {
                        this.editLink()
                    }}
                >
                    Edit
                </components.AuthDisableButton>
                <components.AuthDisableButton
                    auth={[
                        'ROLE_02',
                        'ROLE_03',
                        'ROLE_04',
                        'ROLE_05',
                        'ROLE_06',
                        'ROLE_07',
                        'ROLE_08',
                        'ROLE_09'
                    ]}
                    size="large"
                    style={{
                        marginTop: -75,
                        float: 'right'
                    }}
                    onClick={() => {
                        // this.downloadexport()
                        let targetLiveDate = ''
                        if (
                            this.searchForm.formInstance.getFieldsValue()
                                .targetLiveDate
                        ) {
                            targetLiveDate =
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .targetLiveDate[0].format('MM/DD/YYYY') +
                                ' - ' +
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .targetLiveDate[1].format('MM/DD/YYYY')
                        }

                        let demandApprovalDate = ''
                        if (
                            this.searchForm.formInstance.getFieldsValue()
                                .demandApprovalDate
                        ) {
                            demandApprovalDate =
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .demandApprovalDate[0].format(
                                        'MM/DD/YYYY'
                                    ) +
                                ' - ' +
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .demandApprovalDate[1].format('MM/DD/YYYY')
                        }

                        let designApprovalDate = ''
                        if (
                            this.searchForm.formInstance.getFieldsValue()
                                .designApprovalDate
                        ) {
                            designApprovalDate =
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .designApprovalDate[0].format(
                                        'MM/DD/YYYY'
                                    ) +
                                ' - ' +
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .designApprovalDate[1].format('MM/DD/YYYY')
                        }

                        let designReviewApprovalDate = ''
                        if (
                            this.searchForm.formInstance.getFieldsValue()
                                .designReviewApprovalDate
                        ) {
                            designReviewApprovalDate =
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .designReviewApprovalDate[0].format(
                                        'MM/DD/YYYY'
                                    ) +
                                ' - ' +
                                this.searchForm.formInstance
                                    .getFieldsValue()
                                    .designReviewApprovalDate[1].format(
                                        'MM/DD/YYYY'
                                    )
                        }
                        const apiLifecycleStage = this.searchForm.formInstance.getFieldValue(
                            'apiLifecycleStage'
                        )
                        download(
                            appConfig.server + '/demand/export',
                            'API-Demand-Request-List.xls',
                            Object.assign(
                                this.searchForm.formInstance.getFieldsValue(),
                                {
                                    targetLiveDate: targetLiveDate,
                                    designApprovalDate: designApprovalDate,
                                    demandApprovalDate: demandApprovalDate,
                                    designReviewApprovalDate: designReviewApprovalDate,
                                    apiLifecycleStage: apiLifecycleStage
                                        ? apiLifecycleStage.toString()
                                        : ''
                                }
                            )
                        )
                    }}
                >
                    Export
                </components.AuthDisableButton>
                <DataTable
                    dataSource={dataSource}
                    page={this.pageService}
                    loading={Loading}
                    onPageChange={() => this.getDemandList()}
                    rowSelection={{
                        selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRows,
                                selectedRowKeys
                            })
                        }
                    }}
                    rowKey="demandId"
                    actions={this.renderTableAction()}
                    onChange={(pagination, filters, sorter) => {
                        if (sorter.order) {
                            this.sortService.update(
                                sorter.columnKey,
                                sorter.order
                            )
                        } else {
                            this.sortService.reset()
                        }
                        this.getDemandList()
                    }}
                >
                    <ColumnGroup className="bluetwo">
                        <Column
                            dataIndex="demandStatus"
                            key="dSdemantatus"
                            ellipsis={true}
                            title=""
                            width={50}
                            sorter
                            fixed={this.isNotIE11}
                            render={(text, row: any, value) => (
                                <div
                                    style={
                                        row.demandStatus == 3
                                            ? {
                                                  background: '#0F3964',
                                                  width: 6,
                                                  height: 30,
                                                  margin: '0 auto'
                                              }
                                            : row.demandStatus == 4 &&
                                              row.designStatus == 3
                                            ? {
                                                  background: '#61BEBB',
                                                  width: 6,
                                                  height: 30,
                                                  margin: '0 auto'
                                              }
                                            : {}
                                    }
                                ></div>
                            )}
                        />
                        <Column
                            width={130}
                            title="Project Name"
                            dataIndex="projectName"
                            key="projectName"
                            ellipsis={true}
                            fixed={this.isNotIE11}
                            sorter
                            render={val => (
                                <div
                                    style={{
                                        overflow: 'hidden',
                                        whiteSpace: 'nowrap',
                                        textOverflow: 'ellipsis',
                                        width: '120px'
                                    }}
                                >
                                    {val || ''}
                                </div>
                            )}
                        />
                        <Column
                            title="API Name"
                            dataIndex="apiName"
                            key="apiName"
                            width={280}
                            ellipsis={true}
                            fixed={this.isNotIE11}
                            sorter
                            render={(text, row, index) => (
                                // <Button
                                //     type="link"
                                //     onClick={() => this.openForm(row)}
                                //     style={{width:'310px'}}
                                // >
                                //     {text}
                                // </Button>
                                <a
                                    onClick={() => this.openForm(row)}
                                    title={text}
                                    style={{ width: '270px' }}
                                >
                                    {text}
                                </a>
                            )}
                        />
                    </ColumnGroup>
                    <ColumnGroup title="Demand Governance" className="blue">
                        {/* <Column
                            dataIndex="demandStatus"
                            key="dSdemantatus"
                            ellipsis={true}
                            title=""
                            width={50}
                            sorter
                            //  fixed={true}
                            render={(text, row: any, value) => (
                                <div style={row.demandStatus==3?{background:'#0F3964',width:6,height:30,margin:'0 auto'}:
                                row.demandStatus==4 && row.designStatus==3?{background:'#61BEBB',width:6,height:30,margin:'0 auto'}:{}}></div>
                            )}
                        />
                             <Column
                              width={150}
                            title="Project Name"
                            dataIndex="projectName"
                            key="projectName"
                            ellipsis={true}
                            // fixed={true}
                            sorter
                        />

                        <Column
                            title="API Name"
                            dataIndex="apiName"
                            key="apiName"
                            width={100}
                            ellipsis={true}
                            // fixed={true}
                            sorter
                            render={(text, row, index) => (
                                <Button
                                    type="link"
                                    onClick={() => this.openForm(row)}
                                >
                                    {text}
                                </Button>
                            )}
                        /> */}
                        <Column
                            title="Entry Created Date"
                            dataIndex="createDate"
                            key="createDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Order Received Date"
                            dataIndex="receivedDate"
                            key="receivedDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Demand Classification"
                            dataIndex="demandClassification"
                            key="demandClassification"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'api_classification',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Region"
                            dataIndex="region"
                            key="region"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('region', value)
                            }
                        />
                        <Column
                            title="Site"
                            dataIndex="country"
                            key="country"
                            ellipsis={true}
                            render={(text, row: any, index) =>
                                this.dictUtil.filter(row.region, row.country)
                            }
                        />
                        <Column
                            title="Backend System"
                            dataIndex="backEndSystem"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('backend_system', value)
                            }
                        />
                        <Column
                            title="Channel"
                            dataIndex="channel"
                            key="channel"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('channel', value)
                            }
                        />
                        <Column
                            title="Consumer"
                            dataIndex="consumer"
                            key="consumer"
                            ellipsis={true}
                        />
                        <Column
                            title="Requester"
                            dataIndex="requester"
                            key="requester"
                            ellipsis={true}
                        />
                        <Column
                            title="Core Banking API Contact"
                            dataIndex="cbApiContact"
                            key="cbApiContact"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('cb_api_contact', value)
                            }
                        />

                        <Column
                            title="Core Banking System Contact"
                            dataIndex="cbSysContact"
                            key="cbSysContact"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('cb_system_contact', value)
                            }
                        />
                        <Column
                            title="GB/GF"
                            dataIndex="gbOrGF"
                            key="gbOrGF"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('gb_gf', value)
                            }
                        />
                        <Column
                            title="API Lifecycle Stage"
                            dataIndex="apiLifecycleStage"
                            key="apiLifecycleStage"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'api_lifecycle_stage',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Target Live Date"
                            dataIndex="targetLiveDate"
                            key="targetLiveDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Total API L0 Estimates"
                            dataIndex="totalApiL0Estimates"
                            key="totalApiL0Estimates"
                            ellipsis={true}
                            render={text => <>{`$ ${text}K (USD) `}</>}
                        />

                        <Column
                            title="Mule API L0 Estimates"
                            dataIndex="ossApiL0Estimates"
                            key="ossApiL0Estimates"
                            ellipsis={true}
                            render={text => <>{`$ ${text}K (USD) `}</>}
                        />
                        <Column
                            title="CB System L0 Estimates"
                            dataIndex="cbSystemL0Estimates"
                            key="cbSystemL0Estimates"
                            ellipsis={true}
                            render={text => <>{`$ ${text}K (USD) `}</>}
                        />
                        <Column
                            title="BPID"
                            dataIndex="gdpmInterLockBpid"
                            key="gdpmInterLockBpid"
                            ellipsis={true}
                            render={(text, row, index) => (
                                <a
                                    type="link"
                                    onClick={() => this.openBPidLink(row)}
                                >
                                    {text}
                                </a>
                            )}
                        />

                        <Column
                            title="Demand Approval Status"
                            dataIndex="demandStatus"
                            key="dSdemantatus"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('demand_status', value)
                            }
                        />
                        <Column
                            title="Demand Approval Date"
                            dataIndex="demandDate"
                            key="demandDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Demand Creator"
                            dataIndex="createByAccName"
                            key="createByAccName"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Clarity ID"
                            dataIndex="clarityId"
                            key="clarityId"
                            ellipsis={true}
                            sorter
                        />
                    </ColumnGroup>
                    <ColumnGroup title="Design Governance" className="green">
                        <Column
                            title="Capability"
                            dataIndex="capability"
                            key="capability"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('capability', value)
                            }
                        />
                        <Column
                            title="Feature"
                            dataIndex="feature"
                            key="feature"
                            ellipsis={true}
                            render={(text, record: any) =>
                                this.dictUtil.filter(record.capability, text)
                            }
                        />
                        <Column
                            title="Service"
                            dataIndex="service"
                            key="service"
                            ellipsis={true}
                            render={(text, record: any) =>
                                this.dictUtil.filter(record.feature, text)
                            }
                        />
                        <Column
                            title="Platform"
                            dataIndex="platform"
                            key="platform"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('platform', value)
                            }
                        />
                        <Column
                            title="API Type"
                            dataIndex="apiType"
                            key="apiType"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('api_type', value)
                            }
                        />
                        <Column
                            title="Channel Agnostic"
                            dataIndex="channelAgnostic"
                            key="channelAgnostic"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('channel_agnostic', value)
                            }
                        />
                        {/* <Column
                            title="Demand Classification"
                            dataIndex="demandClassification"
                            key="demandClassification"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'api_classification',
                                    value
                                )
                            }
                        /> */}
                        <Column
                            title="Reusability Score"
                            dataIndex="reusabilityScore"
                            key="reusabilityScore"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('reusability_score', value)
                            }
                        />
                        <Column
                            title="API ID"
                            dataIndex="trueSapiId"
                            key="trueSapiId"
                            ellipsis={true}
                            sorter
                        />
                        {/* <Column
                            title="Multiple Country"
                            dataIndex="multiCountry"
                            key="multiCountry"
                            ellipsis={true}
                        /> */}
                        <Column
                            title="Original API ID"
                            dataIndex="originalSapiId"
                            key="originalSapiId"
                            ellipsis={true}
                        />
                        <Column
                            title="Design Review Status"
                            dataIndex="designReviewStatus"
                            key="designReviewStatus"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter(
                                    'design_review_status',
                                    value
                                )
                            }
                        />
                        <Column
                            title="Design Review Date"
                            dataIndex="designReviewDate"
                            key="designReviewDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Design Approval Status"
                            dataIndex="designStatus"
                            key="designStatus"
                            ellipsis={true}
                            render={value =>
                                this.dictUtil.filter('demand_status', value)
                            }
                        />
                        <Column
                            title="Design Approval Date"
                            dataIndex="designDate"
                            key="designDate"
                            ellipsis={true}
                            sorter
                        />
                        <Column
                            title="Applicable Channels"
                            dataIndex="applicableChannels"
                            key="applicableChannels"
                            ellipsis={true}
                            sorter
                            render={(text, row: any, index) => {
                                let context = ''
                                if (
                                    row.applicableCountries2 != null &&
                                    row.applicableCountries2 != ''
                                ) {
                                    context =
                                        this.dictUtil.filter(
                                            'applicable_countries',
                                            row.applicableCountries
                                        ) +
                                        ' - ' +
                                        row.applicableCountries2
                                } else {
                                    context = this.dictUtil.filter(
                                        'applicable_countries',
                                        row.applicableCountries
                                    )
                                }
                                return context
                            }}
                        />
                        <Column
                            title="Applicable GB/GF"
                            dataIndex="applicableGbGf"
                            key="applicableGbGf"
                            ellipsis={true}
                            sorter
                            render={(text, row: any, index) => {
                                let context = ''
                                if (
                                    row.applicableGbGf2 != null &&
                                    row.applicableGbGf2 != ''
                                ) {
                                    context =
                                        this.dictUtil.filter(
                                            'applicable_gb',
                                            row.applicableGbGf
                                        ) +
                                        ' - ' +
                                        row.applicableGbGf2
                                } else {
                                    context = this.dictUtil.filter(
                                        'applicable_channels',
                                        row.applicableGbGf
                                    )
                                }
                                return context
                            }}
                        />
                        <Column
                            title="Applicable Countries"
                            dataIndex="applicableCountries"
                            key="applicableCountries"
                            ellipsis={true}
                            sorter
                            render={(text, row: any, index) => {
                                let context = ''
                                if (
                                    row.applicableCountries2 != null &&
                                    row.applicableCountries2 != ''
                                ) {
                                    context =
                                        this.dictUtil.filter(
                                            'applicable_countries',
                                            row.applicableCountries
                                        ) +
                                        ' - ' +
                                        row.applicableCountries2
                                } else {
                                    context = this.dictUtil.filter(
                                        'applicable_countries',
                                        row.applicableCountries
                                    )
                                }
                                return context
                            }}
                        />
                    </ColumnGroup>
                </DataTable>
            </CardContainer>
        )
    }

    public renderApiDemandTips(){
        return (
            <>
                <div
                    style={{
                        position: 'absolute',
                        top: '1.9em',
                        display: 'inline-block',
                        left: '15.7em',
                        cursor: 'pointer'
                    }}
                    onClick={() => {
                        this.setState({
                            hover: !this.state.hover
                        })
                    }}
                >
                    <img
                        width="20"
                        src={this.state.hover ? imgsrcQm : imgsrcHelp}
                    ></img>
                </div>
                <div
                    style={{
                        display: this.state.hover ? 'inline-block' : 'none',
                        position: 'absolute'
                    }}
                >
                    <div
                        style={{
                            position: 'absolute',
                            width: 0,
                            height: 0,
                            top: '-4.7em',
                            left: '15.45em',
                            border: '10px solid transparent',
                            borderRightColor: '#333333'
                        }}
                    ></div>
                    <div
                        style={{
                            position: 'absolute',
                            width: 0,
                            height: 0,
                            top: '-4.7em',
                            left: '15.6em',
                            border: '10px solid transparent',
                            borderRightColor: '#fff',
                            zIndex: 99
                        }}
                    ></div>
                    <div
                        style={{
                            position: 'absolute',
                            width: '19em',
                            top: '-7em',
                            left: '19.75em',
                            border: '1px solid #333333',
                            padding: '10px',
                            fontSize: '0.85em'
                        }}
                    >
                        Blue - Demand is ready for review <br />
                        Green - Design is ready for review
                    </div>
                </div>
            </>
        )
    }

    private renderTableAction() {
        return (
            <LabelContainer column={3} colon>
                <LabelContainer.Item label="Demand Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DEMAND'
                            this.demandStatus = '4'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean:false
                            })
                        }}
                        auth={['ROLE_02']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DEMAND'
                            this.demandStatus = '5'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean:true
                            })
                        }}
                        auth={['ROLE_02']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
                <LabelContainer.Item label="Design Action" labelWidth={120}>
                    <components.AuthDisableButton
                        type="primary"
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DESIGN'
                            this.demandStatus = '4'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean:false
                            })
                        }}
                        auth={['ROLE_02']}
                    >
                        Approve
                    </components.AuthDisableButton>
                    <components.AuthDisableButton
                        style={{ width: 100 }}
                        onClick={() => {
                            this.statusType = 'DESIGN'
                            this.demandStatus = '5'
                            this.openReviewModal()
                            this.setState({
                                ApproveBoolean:true
                            })
                        }}
                        auth={['ROLE_02']}
                    >
                        Reject
                    </components.AuthDisableButton>
                </LabelContainer.Item>
            </LabelContainer>
        )
    }
    private renderReviewModal() {
        const {ApproveBoolean}=this.state
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        Governance Group
                                    </LabelItem>
                                </LabelContainer>

                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{
                                        type: 'string', max: 200, message: 'the length of approve comment should less then 200'
                                    }]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }
    private openForm(row) {
        const fieldsValues = dataConvert(false, this.searchForm.formInstance.getFieldsValue());
        this.props.history.push({
            // pathname: '/pages/demand-request-form-detail',
            pathname: '/pages/demand-request-form-exhibition',
            state: {
                demandId: row.demandId,
                fieldsValues,
                pathName: '/pages/api-demand-request-list',
                searchParams: this.homePageJumpSearch
            },
            search: `demandId=${row.demandId}`
        })
    }
    private submitAction(staffId) {
        const { selectedRowKeys } = this.state
        this.actionForm.formInstance.validateFields().then((...data) => {
            this.demandService
                .status(
                    new RequestParams({
                        apiDemandIdList: selectedRowKeys,
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        status: this.demandStatus,
                        statusType: this.statusType
                    })
                )
                .subscribe(() => {
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openReviewModal() {
        const { selectedRowKeys, dataSource } = this.state
        let selectedRow = dataSource.filter(e => {
            return (
                selectedRowKeys.includes(e.demandId)
            )
        })

        if (this.statusType === 'DEMAND') {
            if (selectedRow.some(data => data.demandStatus !== '3')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        } else {
            if (selectedRow.some(data => data.demandStatus !== '4')) {
                message.error('The status is incorrect and cannot be approved')
                return
            }

            if (
                selectedRow.some(data => data.demandStatus === '4') &&
                selectedRow.some(data => data.designStatus !== '3')
            ) {
                message.error('The status is incorrect and cannot be approved')
                return
            }
        }

        if (selectedRowKeys.length == 0) {
            message.error('Please select at least one data')
            return
        }
        this.setState({
            reviewModalVisible: true
        })
    }
    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private renderFormAction() {
        return (
            <Button type="primary" danger size={layOutSize()} onClick={() => 
                this.replacement()
                // this.getDemandList()
                }>
                Search
            </Button>
        )
    }
    private replacement  = () =>{
       this.setState({
         Loading:true
       })
    this.pageService.reset()
      this.sortService.reset()
      this.getDemandList()
   }
    // private getDemandList()
    getDemandList = () => {
        // const{apiLifecycleStage}=this.state
        let targetLiveDate = ''
        if (this.searchForm.formInstance.getFieldsValue().targetLiveDate) {
            targetLiveDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .targetLiveDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .targetLiveDate[1].format('MM/DD/YYYY')
        }

        let demandApprovalDate = ''
        if (this.searchForm.formInstance.getFieldsValue().demandApprovalDate) {
            demandApprovalDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .demandApprovalDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .demandApprovalDate[1].format('MM/DD/YYYY')
        }

        let designApprovalDate = ''
        if (this.searchForm.formInstance.getFieldsValue().designApprovalDate) {
            designApprovalDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designApprovalDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designApprovalDate[1].format('MM/DD/YYYY')
        }

        let designReviewApprovalDate = ''
        if (
            this.searchForm.formInstance.getFieldsValue()
                .designReviewApprovalDate
        ) {
            designReviewApprovalDate =
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designReviewApprovalDate[0].format('MM/DD/YYYY') +
                ' - ' +
                this.searchForm.formInstance
                    .getFieldsValue()
                    .designReviewApprovalDate[1].format('MM/DD/YYYY')
        }
      
        this.demandService
            .all(
                new RequestParams(
                    Object.assign(
                        this.searchForm.formInstance.getFieldsValue(),
                        {
                            apiLifecycleStage:this.searchForm.formInstance.getFieldValue('apiLifecycleStage')==undefined?'':
                            this.searchForm.formInstance.getFieldValue('apiLifecycleStage').toString(),
                            targetLiveDate: targetLiveDate,
                            designApprovalDate: designApprovalDate,
                            demandApprovalDate: demandApprovalDate,
                            designReviewApprovalDate: designReviewApprovalDate,
                            outStandingApprovalName: this.homePageJumpSearch
                        }
                    ),
                    {
                        page: this.pageService,
                        sort: this.sortService
                    }
                )
            )
            .subscribe(data => {
                setTimeout(this.send,500)
                this.setState({
                    dataSource: data,
                })
            })
    }
    private send  = () =>{
        this.setState({
            Loading:false
        })
    }


    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private get searchForm(): DataForm {
        return this.searchFormRef.current as DataForm
    }
}
