import { ReactNode } from 'react'
export interface apiReviewDemandList {
    title:string
    dataIndex: string
    key:string
    Selectvalue?:string
    detaSelect?:Boolean
    inputSelect?:Boolean
    isSelect?:Boolean
    disabled?:Boolean
}
export const apiReviewDemandListHeader:apiReviewDemandList[] = [
    {
        title: 'Region',
        dataIndex: 'region',
        key: 'region',
        isSelect: true,
        Selectvalue:'region'
    },
    {
        title: 'Site',
        dataIndex: 'country',
        key: 'country',
        isSelect: true,
        Selectvalue:'country'
    }
]
export interface APIReviewDemandListColumnProps {
    title: ReactNode | string
    render?: any
}