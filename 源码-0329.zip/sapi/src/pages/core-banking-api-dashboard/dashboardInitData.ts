import { colorArr } from './type'

// Reusability Pie Chart
export const reusePieChartOption: any = {
    title: {
        left: 'center'
    },
    tooltip: {
        trigger: 'item'
    },
    series: [
        {
            //name: '访问来源',
            type: 'pie',
            radius: '65%',
            data: [],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            color: colorArr
        }
    ]
}

// API Demand Order Delivery Duration
export const deliveryDurationChartOption: any = {
    xAxis: {
        type: 'category',
        axisLabel: {
            interval: 0
        },
        data: [
            '1 mon',
            '2 mons',
            '3 mons',
            '4 mons',
            '5 mons',
            '6 mons',
            '6 mons+'
        ]
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            data: [],
            type: 'bar',
            barWidth: 35,
            color: ['#14A5AB']
        }
    ]
}

const labelOption = {
    show: true,
    position: 'insideBottom',
    distance: 15,
    align: 'left',
    verticalAlign: 'middle',
    rotate: 90,
    //formatter: '{c} {a}',
    formatter: params => {
        const { seriesName, value } = params
        if (value) {
            return `${value} ${seriesName}`
        }
        return ''
    },
    fontSize: 9
}

// API Demand Order Tracking
export const trackingChartOption: any = {
    color: ['#14A5AB', '#6D8EA6', '#4FA62F'],
    legend: {
        data: [
            'Order Received',
            'Delivered for Testing',
            'Delivered for Production'
        ]
        // orient: 'vertical',
        // right: 0,
        // top: 0,
        //bottom: 100,
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    toolbox: {
        show: false,
        orient: 'vertical',
        left: 'right',
        top: 'center',
        feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            magicType: { show: true, type: ['line', 'bar', 'stack', 'tiled'] },
            restore: { show: true },
            saveAsImage: { show: true }
        }
    },
    xAxis: [
        {
            type: 'category',
            axisTick: { show: false },
            name: 'Month',
            data: [
                'Jan',
                'Feb',
                'Mar.',
                'Apr.',
                'May.',
                'Jun.',
                'Jul.',
                'Aug.',
                'Sept.',
                'Oct.',
                'Nov.',
                'Dec.'
            ]
        }
    ],
    yAxis: [
        {
            type: 'value'
        }
    ],
    series: [
        {
            name: 'Order Received',
            type: 'bar',
            barGap: 0,
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'Delivered for Testing',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'Delivered for Production',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        }
    ]
}

// TOP 10 of API Reused
export const topApiReusedOption: any = {
    color: ['#E67310'],
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis: {
        type: 'value',
        boundaryGap: [0, 0.01]
    },
    yAxis: {
        type: 'category',
        data: []
    },
    series: [
        {
            type: 'bar',
            data: []
        }
    ]
}

export const statusChartOption: any = {
    color: ['#2580DC', '#834EFF', '#D71E8D', '#E67310', '#4FA62F', '#14A5AB'],
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    legend: {
        data: [
            'Discovery',
            'Development',
            'SIT',
            'UAT',
            'Deployment Readiness',
            'Production'
        ]
    },
    toolbox: {
        show: false,
        orient: 'vertical',
        left: 'right',
        top: 'center',
        feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            magicType: { show: true, type: ['line', 'bar', 'stack', 'tiled'] },
            restore: { show: true },
            saveAsImage: { show: true }
        }
    },
    xAxis: [
        {
            type: 'category',
            axisTick: { show: false },
            data: []
        }
    ],
    yAxis: [
        {
            type: 'value',
            name: 'Number'
        }
    ],
    series: [
        {
            name: 'Discovery',
            type: 'bar',
            barGap: 0,
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'Development',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'SIT',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'UAT',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'Deployment Readiness',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        },
        {
            name: 'Production',
            type: 'bar',
            label: labelOption,
            emphasis: {
                focus: 'series'
            },
            data: []
        }
    ]
}
