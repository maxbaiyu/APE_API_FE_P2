interface averageCostProps {
    label: string
    color?: string
    contentProKey?: string,
    span?:number
}

export interface trackingProps {
    product : any
    gbOrGF:any
}

export const colorArr = [
    '#14A5AB',
    '#4FA62F',
    '#E67310',
    '#D71E8D',
    '#834EFF',
    '#2580DC',
    '#6D8EA6'
]

export const outApprovalItems: averageCostProps[] = [
    {
        label: 'Demand Approval',
        color: '#2580DC',
        contentProKey: '12'
    },
    {
        label: 'Design Review',
        color: '#14A5AB',
        contentProKey: '18',
        span:3
    },
    {
        label: 'Design Approval',
        color: '#6D8EA6',
        contentProKey: '22'
    }
]

export const averageCostItems: averageCostProps[] = [
    {
        label: 'New API',
        color: '#D71E8D',
        contentProKey: '28'
    },
    {
        label: 'New to Replace',
        color: '#E67310',
        contentProKey: '28'
    },
    {
        label: 'Reuse Direct',
        color: '#2580DC',
        contentProKey: '2'
    },
    {
        label: 'Reuse with Version Change',
        color: '#834EFF',
        contentProKey: '5.5'
    },
    {
        label: 'Reuse with Minor Change',
        color: '#4FA62F',
        contentProKey: '3.6'
    }
]
