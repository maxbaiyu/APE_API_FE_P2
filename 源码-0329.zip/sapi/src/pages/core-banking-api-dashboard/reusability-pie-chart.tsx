import React, { useState, useEffect, useRef } from 'react'
import { Select } from 'antd'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import 'echarts/lib/chart/pie' //饼状图
import DashboardCardComponent from './dashboard-card-component'
import { reusePieChartOption } from './dashboardInitData'
import { reuseCategoryTwo, groupByList } from './mock'
import { colorArr } from './type'

const { Option } = Select

interface MockProps {
    name: string
    value: number
}

const ReusabilityPieChartCard: React.FC = props => {
    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [reusedCatagory, setReusedCatagory] = useState<string>('all')
    const [groupBy, setGroupBy] = useState<string>('all')
    const [pieOption, setPieOption] = useState<any>(reusePieChartOption)
    const mockData = require('./pieChart.json')

    const selectChange = (reusedCatagory = 'all', groupBy = 'all') => {
        setShowLoading(false)
        let color = colorArr;
        if (groupBy == 'all' && reusedCatagory !== 'all') {
            color  = colorArr.slice(Number(reusedCatagory.substring(1,2)) - 1, Number(reusedCatagory.substring(1,2)))
        }
        setPieOption({
            ...pieOption,
            series: [
                {
                    ...pieOption.series[0],
                    data: mockData[`${reusedCatagory}${groupBy}`],
                    color
                }
            ]
        })
    }

    useEffect(() => {
        console.log(mockData)
        selectChange()
        return () => {
            console.log('pie 销毁')
        }
    }, [])

    return (
        <DashboardCardComponent
            title={'Reusability Pie Chart'}
            className={'reusability-pie-chart-card'}
            extra={
                <Select
                    style={{ width: 200 }}
                    value={reusedCatagory}
                    onChange={value => {
                        setReusedCatagory(value)
                        selectChange(value, groupBy)
                    }}
                >
                    <Option value="all">All</Option>
                    {reuseCategoryTwo.map(item => (
                        <Option value={item.value}>{item.name}</Option>
                    ))}
                </Select>
            }
        >
            <div className={'group-by-select'}>
                <span>Group by</span>
                <Select
                    style={{ width: 200 }}
                    value={groupBy}
                    onChange={value => {
                        setGroupBy(value)
                        selectChange(reusedCatagory, value)
                    }}
                >
                    <Option value="all">All</Option>
                    {groupByList.map(item => (
                        <Option value={item}>{item}</Option>
                    ))}
                </Select>
            </div>

            <ReactEchartsCore
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                notMerge={true}
                style={{ height: 545 }}
            />
        </DashboardCardComponent>
    )
}

export default ReusabilityPieChartCard
