import React, { ReactNode, useState, useEffect, useRef } from 'react'
import { Form, Select, Button } from 'antd'
import { loadingOption, ReactEchartsCore, echarts } from './echarts-for-react'
import 'echarts/lib/chart/bar'
import { DictUtil } from '~/shared/utils/dict.util'
import DataForm from '~/shared/components/data-form'
import DashboardCardComponent from './dashboard-card-component'
import { trackingChartOption } from './dashboardInitData'
import { ReviewService } from '~/services/review.service'
import { DemandService } from '~/services/demand.service'
import { RequestParams } from '~/core/http'
import { trackingProps } from './type'
import { trackProduct, regionMarket, gbOrGF } from './mock'

const { Option } = Select
const dictUtil = new DictUtil()
const reviewService = new ReviewService()
const demandService = new DemandService()

const TrackingChartCard: React.FC = props => {
    const dataFormRef: any = useRef<HTMLDivElement>(null)

    const [showLoading, setShowLoading] = useState<boolean>(true)
    const [pieOption, setPieOption] = useState<any>(trackingChartOption)
    const [yearList, setYearList] = useState<any>([])
    const [filterOptions, setFilterOption] = useState<any>()
    const cacheData = useRef<any>()

    const initFormOption: any = useRef<any>({
        product: [],
        gbOrGF: []
    })

    const randAlloc = (total, min, max, length) => {
        // 首先要判断是否符合 min 和 max 条件
        if (min * length > total || max * length < total) {
            throw Error(`没法满足最最少 ${min} 最大 ${max} 的条件`)
        }

        const result: number[] = []
        let restValue = total
        let restLength = length
        for (let i = 0; i < length - 1; i++) {
            restLength--
            // 这一次要发的数量必须保证剩下的要足最小量
            // 同进要保证剩下的不能大于需要的最大量
            const restMin = restLength * min
            const restMax = restLength * max
            // 可发的量
            const usable = restValue - restMin
            // 最少要发的量
            const minValue = Math.max(min, restValue - restMax)
            // 以 minValue 为最左，max 为中线来进行随机，即随机范围是 (max - minValue) * 2
            // 如果这个范围大于 usable - minValue，取 usable - minValue
            const limit = Math.min(usable - minValue, (max - minValue) * 2)
            // 随机部分加上最少要发的部分就是应该发的，但是如果大于 max，最大取到 max
            result[i] = Math.min(
                max,
                minValue + Math.floor(limit * Math.random())
            )
            restValue -= result[i]
        }
        result[length - 1] = restValue

        return result
    }

    const getYear = () => {
        reviewService.date(new RequestParams()).subscribe(data => {
            setYearList(data)
            dataFormRef.current.formInstance.setFieldsValue({
                year: data.length && data[0].createDate
            })
            // resetFilter()
        })
    }

    const getInitFormOption = () => {
        initFormOption.current.product = dictUtil.dicts('backend_system')
        initFormOption.current.gbOrGF = dictUtil.dicts('gb_gf')
        initFormOption.current.region = dictUtil.dicts('region')
        initFormOption.current.market = dictUtil.dicts(
            initFormOption.current.region[0].dirCode
        )
    }

    const resetFilter = () => {
        const { product, gbOrGF, region, market } = initFormOption.current
        dataFormRef.current.formInstance.setFieldsValue({
            backendSystem: '',
            region: '',
            market: '',
            gbOrGF: '',
            demandApprovalDate: ''
        })
        setFilterOption({
            product: product,
            region,
            market,
            gbOrGF
        })
    }

    const regionChange = value => {
        const market = dictUtil.dicts(value)
        setFilterOption({
            ...filterOptions,
            market
        })
        dataFormRef.current.formInstance.setFieldsValue({
            market: market[0]?.dirCode
        })
    }

    const onFormValueChange = (changeValue, values) => {
        getOption()
    }

    const getOption = () => {
        const {
            backendSystem,
            region,
            market,
            gbOrGF,
            demandApprovalDate
        } = dataFormRef.current.formInstance.getFieldsValue()
        const abc =
            `${backendSystem}${region}${market}${gbOrGF}${demandApprovalDate}` ||
            'all'
        if (abc && cacheData.current && cacheData.current[abc]) {
            setPieOption({
                ...pieOption,
                series: cacheData.current[abc]
            })
            return
        }

        demandService
            .all(
                new RequestParams({
                    backendSystem,
                    gbOrGF,
                    demandApprovalDate,
                    page: 1,
                    size: 100
                })
            )
            .subscribe(data => {
                let option = data?.content
                if (region) {
                    option = option.filter(item => item.region == region)
                }
                if (market) {
                    option = option.filter(item => item.country == market)
                }
                let orderReceivedLen: number = 0
                let productionLen: number = 0
                let testingLen: number = 0
                if (option && option.length) {
                    option.forEach(item => {
                        if (item.apiLifecycleStage === '06') {
                            // production
                            productionLen++
                        } else if (item.apiLifecycleStage === '01') {
                            // 01 re
                            orderReceivedLen++
                        } else if (
                            item.apiLifecycleStage === '03' ||
                            item.apiLifecycleStage === '04'
                        ) {
                            // testing
                            testingLen++
                        }
                    })
                }
                const orderReceived = randAlloc(
                    orderReceivedLen,
                    0,
                    orderReceivedLen,
                    12
                )
                const testing = randAlloc(testingLen, 0, testingLen, 12)
                const production = randAlloc(
                    productionLen,
                    0,
                    productionLen,
                    12
                )
                const series = pieOption.series.map(item => {
                    if (item.name === 'Order Received') {
                        return {
                            ...item,
                            data: orderReceived
                        }
                    } else if (item.name === 'Delivered for Testing') {
                        return {
                            ...item,
                            data: testing
                        }
                    } else {
                        return {
                            ...item,
                            data: production
                        }
                    }
                })

                cacheData.current = {
                    ...cacheData.current,
                    [abc]:series
                }
                setPieOption({
                    ...pieOption,
                    series
                })
            })
    }

    useEffect(() => {
        //getYear()
        getInitFormOption()
        resetFilter()
        setShowLoading(false)
        getOption()
    }, [])

    return (
        <DashboardCardComponent
            title={'API Demand Order Tracking'}
            className={'tracking-chart-card'}
        >
            <DataForm
                name="demo-form"
                column={3}
                labelCol={{ span: 6 }}
                labelAlign="left"
                ref={dataFormRef}
                onValuesChange={onFormValueChange}
            >
                <DataForm.Item
                    name="backendSystem"
                    label="Product"
                    initialValue=""
                >
                    <Select allowClear>
                        <Option value={''}>{'All'}</Option>
                        {filterOptions?.product.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item name="region" label="Region" initialValue="">
                    <Select allowClear onChange={regionChange}>
                        <Option value={''}>{'All'}</Option>
                        {filterOptions?.region.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item name="market" label="Market" initialValue="">
                    <Select allowClear>
                        <Option value={''}>{'All'}</Option>
                        {filterOptions?.market.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item name="gbOrGF" label="GB/GF" initialValue="">
                    <Select allowClear>
                        <Option value={''}>{'All'}</Option>
                        {filterOptions?.gbOrGF.map(dict => (
                            <Option key={dict.dirCode} value={dict.dirCode}>
                                {dict.dirName}
                            </Option>
                        ))}
                    </Select>
                </DataForm.Item>
                <DataForm.Item
                    name="demandApprovalDate"
                    label="Year"
                    initialValue=""
                >
                    <Select allowClear>
                        <Option value="">Overall</Option>
                        <Option key={'2021'} value={'01/01/2021 - 12/31/2021'}>
                            {'2021'}
                        </Option>
                        <Option key={'2020'} value={'01/01/2020 - 12/31/2020'}>
                            {'2020'}
                        </Option>
                        <Option key={'2019'} value={'01/01/2019 - 12/31/2019'}>
                            {'2019'}
                        </Option>
                    </Select>
                </DataForm.Item>
                <Button
                    style={{ width: '100%' }}
                    onClick={() => {
                        //dataFormRef.current.formInstance.resetFields()
                        resetFilter()
                        getOption()
                    }}
                >
                    Re-set
                </Button>
            </DataForm>

            <ReactEchartsCore
                echarts={echarts}
                option={pieOption}
                loadingOption={loadingOption}
                showLoading={showLoading}
                notMerge={true}
                style={{ height: 450 }}
            />
        </DashboardCardComponent>
    )
}

export default TrackingChartCard
