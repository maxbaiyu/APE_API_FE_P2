import React, { ReactNode, useState } from 'react'
import { Card } from 'antd'

import styled from 'styled-components'

const components = {
    Card: styled(Card)`
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        margin-bottom: 1rem;
    `
}

interface CardComponentsProps {
    title?: ReactNode
    extra?: ReactNode
    style?: React.CSSProperties
    className?: string
}

const DashboardCardComponent: React.FC<CardComponentsProps> = props => {
    const { title = '', extra = '', style, className } = props
    return (
        <components.Card
            title={title}
            extra={extra}
            style={style}
            className={className}
            size={'small'}
        >
            {props.children}
        </components.Card>
    )
}

export default DashboardCardComponent
