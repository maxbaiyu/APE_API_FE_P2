import { ReactNode } from 'react'

export const apiReviewRequestListHeader = [
    { title: 'API ID', dataIndex: 'trueSapiId', key: 'trueSapiId' },
    { title: 'API Name', dataIndex: 'apiName', key: 'apiName' },
    {
        title: 'Project Name',
        key: 'projectName',
        dataIndex: 'projectName'
    },
    {
        title: 'Regional Review Group',
        dataIndex: 'rdr',
        key: 'rdr',
        isSelect: true
    },
    {
        title: 'Global Business Design',
        breakTitle: 'Core Banking Group',
        dataIndex: 'gbdrCb',
        key: 'gbdrCb',
        isSelect: true,
        isBreakWord: true
    },
    {
        title: 'Global Business Design',
        breakTitle: 'API Group',
        dataIndex: 'gbdrApi',
        key: 'gbdrApi',
        isSelect: true,
        isBreakWord: true
    },
    {
        title: 'Global Technical Design',
        breakTitle: 'Core Banking Group',
        dataIndex: 'gtdrCb',
        key: 'gtdrCb',
        isSelect: true,
        isBreakWord: true
    },
    {
        title: 'Global Technical Design',
        breakTitle: 'API Group',
        dataIndex: 'gtdrApi',
        key: 'gtdrApi',
        isSelect: true,
        isBreakWord: true
    }
]

export interface APIReviewRequestListColumnProps {
    title: ReactNode | string
    render?: any
}

export interface APIReviewRequestListData {
    key?: Number
    trueSapiId?: String
    apiName?: String
    projectName?: String
    rdr?: any
    gbdrCb?: any
    gbdrApi?: any
    gtdrCb?: any
    gtdrApi?: any,
    reviewId?: Number
}

export interface submitData {
    apiName?: String
    gbdrApiReviewStaffId?: String
    gbdrApiReviewer?: String
    gbdrCbReviewStaffId?: String
    gbdrCbReviewer?: String
    gtdrApiReviewStaffId?: String
    gtdrApiReviewer?: String
    gtdrCbReviewStaffId?: String
    gtdrCbReviewer?: String
    projectName?: String
    rdrReviewStaffId?: String
    rdrReviewer?: String
    reviewId?: String
}
