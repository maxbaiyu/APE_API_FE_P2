import React, { useState, useRef, useEffect } from 'react';
import { Input, Select, Button, Table, message } from 'antd';
import PageContainer from '~/shared/components/page-container';
import CardContainer from '~/shared/components/card-container';
import DataForm from '~/shared/components/data-form';
import DataTable from '~/shared/components/data-table';
import { PageService } from '~/bootstrap/services/page.service';
import { ReviewService } from '~/services/review.service';
import { AccountService } from '~/services/account.service';
import { RequestParams } from '~/core/http';
import {
    apiReviewRequestListHeader,
    APIReviewRequestListData,
    submitData,
    APIReviewRequestListColumnProps
} from './data';

import styled from 'styled-components';
import { layOutSize } from '~/shared/utils/common.util';

const components = {
    PageContainer: styled(PageContainer)``,
    ActionContainer: styled.div`
        & > * {
            margin-right: 10px;
            min-width: 120px;
        }
    `
}

const { Column } = Table
const { Option } = Select
const pageService = new PageService();
const reviewService = new ReviewService();
const accountService = new AccountService();

const APIReviewTaskAssignment = () => {
    const [tableDataSource, setDataSource] = useState<
        APIReviewRequestListData[]
    >([]);
    const [cacheRowSelectState, setCacheRowSelectState] = useState<any>({});
    const [selectedRowKeys, setSelectedRowKeys] = useState<any[]>([]);
    const [Loading, setLoading] = useState<boolean>(true);
    const dataFormRef: any = useRef<HTMLDivElement>(null);
    const initCurrentPageDatas = useRef<submitData[]>([]);
    const tableSubmitDatas = useRef<submitData[]>([]);
    const cacheSelectOptions = useRef<any>({});

    const renderFormAction = () => {
        return (
            <div
                style={{ width: '100%' }}
                className="flex-row justify-content-end"
            >
                <Button
                    type="primary"
                    danger
                    style={{ minWidth: '120px' }}
                    onClick={() => {
                        replacement()
                    }}
                    size={layOutSize()}
                >
                    Search
            </Button>
            </div>
        )
    }
    const replacement  = () =>{
        pageService.reset()
        tableSubmitDatas.current = [];
        setCacheRowSelectState({});
        getTableRenderData();
        setSelectedRowKeys([]);
        setLoading(true)   
    }
    const getExpandTableTitle = () => {
        
        const serviceTableColumn = apiReviewRequestListHeader.map(item => {
            const {
                title,
                breakTitle,
                dataIndex,
                key,
                isSelect,
                isBreakWord
            } = item;
            const renderProps: APIReviewRequestListColumnProps = {
                title
            };
            if (isBreakWord) {
                renderProps.title = () => (
                    <>
                        <div>{title}</div>
                        <div>{breakTitle}</div>
                    </>
                )
            }
            if (isSelect) {
                renderProps.render = (element, record) => {
                    const { columnAlias, defaultVal, options, firstKey, secondKey } = element;
                    const { key } = record;
                    return (
                        <Select
                            showSearch
                            //defaultValue={defaultVal}
                            value={cacheRowSelectState[`${key}${columnAlias}`] ? cacheRowSelectState[`${key}${columnAlias}`] : defaultVal}
                            style={{ width: '9rem' }}
                            size={'small'}
                            onChange={(value, option) => { selectChange(value, option, firstKey, secondKey, record) }}
                            optionFilterProp="children"
                            filterOption={(input, option) => {
                                if (option && option.children) {
                                    return option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                                return true;
                            }}
                        >
                            {options.map(option => {
                                const { accName, staffId } = option;
                                return <Option value={staffId} key={staffId}>{accName}</Option>
                            })}
                        </Select>
                    )
                }
            }
            if(key === 'projectName'){
                return <Column dataIndex={dataIndex} key={key} {...renderProps} width={150} />;
            }
            return <Column dataIndex={dataIndex} key={key} {...renderProps} />;
        })
        return serviceTableColumn;
    }

    const combineTableRenderData = res => {
        const [label, select] = res;
        const { rdrAccounts, gbdrCbAccounts, gbdrApiAccounts, gtdrCbAccounts, gtdrApiAccounts } = select;
        const tableDataSource: APIReviewRequestListData[] = []
        for (let i = 0; i < label.length; i++) {
            const { trueSapiId, apiName, projectName, rdrReviewStaffId, gbdrReviewCbStaffId, gbdrReviewApiStaffId, gtdrReviewCbStaffId, gtdrReviewApiStaffId, reviewId } = label[i];
            tableDataSource.push({
                key: reviewId,
                trueSapiId,
                apiName,
                projectName,
                rdr: {
                    columnAlias: 'rdr',
                    firstKey: 'rdr',
                    secondKey: '',
                    defaultVal: rdrReviewStaffId,
                    options: rdrAccounts
                },
                gbdrCb: {
                    columnAlias: 'gbdrCb',
                    firstKey: 'gbdr',
                    secondKey: 'Cb',
                    defaultVal: gbdrReviewCbStaffId,
                    options: gbdrCbAccounts
                },
                gbdrApi: {
                    columnAlias: 'gbdrApi',
                    firstKey: 'gbdr',
                    secondKey: 'Api',
                    defaultVal: gbdrReviewApiStaffId,
                    options: gbdrApiAccounts
                },
                gtdrCb: {
                    columnAlias: 'gtdrCb',
                    firstKey: 'gtdr',
                    secondKey: 'Cb',
                    defaultVal: gtdrReviewCbStaffId,
                    options: gtdrCbAccounts
                },
                gtdrApi: {
                    columnAlias: 'gtdrApi',
                    firstKey: 'gtdr',
                    secondKey: 'Api',
                    defaultVal: gtdrReviewApiStaffId,
                    options: gtdrApiAccounts
                },
                reviewId
            })
        }
        setDataSource(tableDataSource);
    }

    const selectChange = (value, option, firstKey, secondKey, record) => {
        const columnKey = `${firstKey}${secondKey}`;
        if (!value) return;
        const { children } = option;
        const { key } = record;
        const cacheRowSelectOldState = { ...cacheRowSelectState };
        setCacheRowSelectState({
            ...cacheRowSelectOldState,
            [`${key}${columnKey}`]: value
        });
        // mod修改回传给后台的表格数据
        const index = tableSubmitDatas.current.findIndex(item => {
            return item.reviewId === key;
        })
        if (index === -1) {
            const selectRowData = initCurrentPageDatas.current.find(item => {
                return item.reviewId === key;
            })
            tableSubmitDatas.current.push({
                ...selectRowData,
                [`${columnKey}Reviewer`]: children,
                [`${firstKey}Review${secondKey}StaffId`]: value
            })
        } else {
            tableSubmitDatas.current[index][`${columnKey}Reviewer`] = children;
            tableSubmitDatas.current[index][`${firstKey}Review${secondKey}StaffId`] = value;
        }
    }

    const verifyDataAndSubmit = () => {
        const lastSubmitDatas = selectedRowKeys.map(item => {
            const findObj = tableSubmitDatas.current.find(element => element.reviewId == item);
            return findObj ? findObj : initCurrentPageDatas.current.find(ele => ele.reviewId == item);
        });
        if (!selectedRowKeys.length) {
            message.warn('Please select at least one to submit');
        } else if (lastSubmitDatas.length && selectedRowKeys.length) {
            for (let i = 0; i < lastSubmitDatas.length; i++) {
                const item = lastSubmitDatas[i];
                for (let key in item) {
                    if ((key === 'gbdrApiReviewer' || key === 'gbdrCbReviewer' || key === 'gbdrReviewApiStaffId' ||
                        key === 'gbdrReviewCbStaffId' || key === 'gtdrApiReviewer' || key === 'gtdrCbReviewer' ||
                        key === 'gtdrReviewApiStaffId' || key === 'gtdrReviewCbStaffId' || key === 'rdrReviewStaffId' ||
                        key === 'rdrReviewer') && !item[key]) {
                        const { reviewId } = item;
                        message.error(`ReviewId is ${reviewId} review request list, not all checked`);
                        return;
                    }
                }
            }
            submitRequest(lastSubmitDatas);
        }
    }

    const getTableLableData = () => {
        const fileValues: any = dataFormRef.current.formInstance.getFieldsValue();
        return (
            new Promise((resolve, reject) => {
                reviewService.taskAll(new RequestParams(Object.assign(
                    { ...fileValues }), { page: pageService })).subscribe(res => {
                        initCurrentPageDatas.current = res;
                        resolve(res);
                    }, error => {
                        reject(error);
                    })
            })
        )
    }

    const getTableSelectData = () => {
        return (
            new Promise((resolve, reject) => {
                accountService.reviewer(new RequestParams()).subscribe(res => {
                    cacheSelectOptions.current = res;
                    resolve(res);
                }, error => {
                    reject(error);
                })
            })
        )
    }

    const submitRequest = lastSubmitDatas => {
        reviewService.taskSubmit(new RequestParams(lastSubmitDatas)).subscribe(res => {
            message.success('Submit successfully');
            tableSubmitDatas.current = [];
            setCacheRowSelectState({})
            getTableRenderData();
            setSelectedRowKeys([]);
        }, error => {
            message.error(error.message);
        })
    }

    const getTableRenderData = () => {
        const cacheOptions = Object.keys(cacheSelectOptions.current).length > 0 ? cacheSelectOptions.current : getTableSelectData();
        Promise.all([getTableLableData(), cacheOptions]).then(result => {
            combineTableRenderData(result);
            setTimeout(() => {
                setLoading(false)
            }, 500)
        }).catch(error => {
            tableSubmitDatas.current = [];
            setCacheRowSelectState({});
            setDataSource([]);
        })
    }

    useEffect(() => {
        getTableRenderData();
    }, [])

    return (
        <components.PageContainer title="API Review Task Assignment" noHeader={true} isNotNeedFlex={true} isNeedCenter={true}>
            <CardContainer title="Search">
                <DataForm
                    name="demo-form"
                    column={3}
                    labelCol={{ span: 8 }}
                    labelAlign="left"
                    ref={dataFormRef}
                    actions={renderFormAction()}
                >
                    <DataForm.Item name="apiId" label="API ID" initialValue="">
                        <Input onPressEnter={replacement}/>
                    </DataForm.Item>
                    <DataForm.Item
                        name="apiName"
                        label="API Name"
                        initialValue=""
                    >
                        <Input onPressEnter={replacement}/>
                    </DataForm.Item>
                    <DataForm.Item
                        name="projectName"
                        label="Project Name"
                        initialValue=""
                    >
                        <Input onPressEnter={replacement}/>
                    </DataForm.Item>
                </DataForm>
            </CardContainer>
            <CardContainer title="API Review List">
                <DataTable
                    rowKey={'reviewId'}
                    dataSource={tableDataSource}
                    loading={Loading}
                    setX={tableDataSource.length == 0 ? 'undefined' : true}
                    rowSelection={{
                        selectedRowKeys,
                        onChange: selectedRowKeys => { setSelectedRowKeys(selectedRowKeys) }
                    }}
                    page={pageService}
                    onPageChange={getTableRenderData}
                    onChange={getTableRenderData}
                >
                    {getExpandTableTitle()}
                </DataTable>
                <components.ActionContainer>
                    <div
                        style={{ width: '100%' }}
                        className="flex-row justify-content-end"
                    >
                        <Button
                            type="primary"
                            danger
                            onClick={verifyDataAndSubmit}
                            style={{ minWidth: '120px' }}
                        >
                            Submit
                    </Button>
                    </div>
                </components.ActionContainer>
            </CardContainer>
        </components.PageContainer>
    )
}

export default APIReviewTaskAssignment
