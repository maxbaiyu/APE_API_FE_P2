import React, { Component } from 'react'
import styled from 'styled-components'
import PageContainer from '~/shared/components/page-container'
import { RouteComponentProps } from 'react-router-dom'
import CardContainer from '~/shared/components/card-container'
import DataForm from '~/shared/components/data-form'
import { DownOutlined } from '@ant-design/icons';
import {
    Form,
    Input,
    Select,
    Table,
    Divider,
    Button,
    Avatar,
    Modal,
    List,
    message,
    Steps,
    Typography,
    Popover,
    Collapse
} from 'antd'
import LabelContainer from '~/shared/components/label-contaoner'
import LabelItem from '~/shared/components/label-item'
import { InboxOutlined, UserOutlined, SolutionOutlined, LoadingOutlined, SmileOutlined } from '@ant-design/icons'
import NotificationContainer from '~/shared/components/notification-container'
import { ReviewService } from '~/services/review.service'
import { RequestParams } from '~/core/http'
import { Consumer } from 'reto'
import { UserStore } from '~/store/user.store'
import CustomizeModal from '~/shared/components/customize-modal'
import { DictUtil } from '~/shared/utils/dict.util'
import Dragger from 'antd/lib/upload/Dragger'
import appConfig from '~/config/app.config'
import { AuthMode, AuthWrapper } from '~/shared/components/auth-wrapper'
import ReplyCommont from '~/components/reply-commont'
import { download } from '~/shared/utils/common.util'
import { isNullOrUndefined } from 'util'
import { FormInstance } from 'antd/lib/form'
import 'braft-editor/dist/index.css'
import 'braft-extensions/dist/table.css'
import BraftEditor from 'braft-editor'
import BraftEditorTable from 'braft-extensions/dist/table'
import { spawn } from 'child_process'
import { divide } from 'ramda'
BraftEditor.use(BraftEditorTable({
    defaultColumns: 2,
    defaultRows: 3,
    withDropdown: true,
    columnResizable: true,
    exportAttrString: 'border="1" style="border-collapse: collapse"',
}));
const styles = (): any => ({
    input: (show: boolean) => {
        if (!show) {
            return {
                display: 'none'
            }
        }
    }
})
const components = {
    PageContainer: styled(PageContainer)``,
    PageHeaderContainer: styled(PageContainer)`
        height: 60px;
        line-height: 60px;
        padding: 0 50px;
        font-size: 26px;
    `,
    AuthDisableButton: styled(AuthWrapper(Button, AuthMode.disable))``
}

const { TextArea } = Input

interface ReviewRequestFormState {
    id: string
    data: any
    status: any
    dataSource: any[]
    reviewModalVisible: boolean
    successModalVisible: boolean
    reviewModalVisiblereopen: boolean
    applicableChannelsSpecficDisplay: boolean
    applicableCountriesSpecficDisplay: boolean
    applicableGbSpecficDisplay: boolean
    contractInformationStatus: boolean
    commontsTree: any
    show: boolean
    disabledEdit: boolean
    disabledReopen: boolean
    historynome: boolean
    editorState: any
    oneStatus: any
    submitStatus: any

    assignReview: any
    submitIcon: any

    assignReviewIcon: any
    rdrStatus: any
    rdrIcon: any

    gbdrStatus: any
    gbdrIcon: any
    gtdrStatus: any
    gtdrIcon: any

    oneStatusIcon: any
    onegtdrIcon: any

    onegtdrStatus: any
    onegbdrIcon: any
    onegbdrStatus: any

    onerdrIcon: any
    onerdrStatus: any

    oneassignReviewIcon: any
    oneassignReview: any

    oneSubmitStatus: any
    oneSubmitIcon: any
    historyItems: any
    reviewer: any
    reviewDate: any
    reviewState: any
}

interface ReviewRequestFormProps { }

export default class ReviewRequestForm extends Component<
    RouteComponentProps<ReviewRequestFormProps>,
    ReviewRequestFormState
    > {
    private dataFromRef!: React.RefObject<DataForm>

    private reviewService = new ReviewService()
    private dictUtil = new DictUtil()
    private actionFromRef!: React.RefObject<DataForm>
    private actionFromReopen!: React.RefObject<DataForm>
    private contractInformationFromRef!: React.RefObject<DataForm>
    private reviewType = ''
    private reviewStatus = ''
    private file: File
    private formRef = React.createRef<FormInstance>()

    constructor(props) {
        super(props)
        this.dataFromRef = React.createRef()
        this.actionFromRef = React.createRef()
        this.actionFromReopen = React.createRef()
        this.contractInformationFromRef = React.createRef()
        this.state = {
            id: '',
            data: {},
            status: {},
            dataSource: [],
            reviewModalVisible: false,
            reviewModalVisiblereopen: false,
            successModalVisible: false,
            applicableChannelsSpecficDisplay: false,
            applicableCountriesSpecficDisplay: false,
            applicableGbSpecficDisplay: false,
            contractInformationStatus: false,
            historynome: false,
            commontsTree: [],
            show: false,
            disabledEdit: true,
            disabledReopen: true,
            submitStatus: '',
            assignReview: '',
            rdrStatus: '',
            editorState: BraftEditor.createEditorState(null),
            submitIcon: '',
            assignReviewIcon: '',
            rdrIcon: '',
            gbdrStatus: '',
            gbdrIcon: '',
            gtdrStatus: '',

            gtdrIcon: '',
            oneStatus: '',
            oneStatusIcon: '',

            onegtdrIcon: '',
            onegtdrStatus: '',

            onegbdrIcon: '',
            onegbdrStatus: '',
            onerdrIcon: '',
            onerdrStatus: '',

            oneassignReviewIcon: '',
            oneassignReview: '',
            oneSubmitStatus: '',
            oneSubmitIcon: '',
            historyItems: [],
            reviewer: '',
            reviewDate: '',
            reviewState: ''
        }
    }

    public componentDidMount() {



        this.getReview()
        this.getComments()
        this.getstatus()
    }
    handleEditorChange = (editorState) => {


        this.setState({
            editorState: editorState
        })

    }
    private getReview() {
        const { id } = this.props.location.state as ReviewRequestFormState

        this.reviewService
            .get(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    data: data,
                    dataSource: data.contracts,
                    contractInformationStatus:
                        data.gbdrReviewStatus > 3 ||
                        data.gtdrReviewStatus > 3 ||
                        data.rdrReviewStatus > 3,
                    applicableChannelsSpecficDisplay:
                        data.applicableChannels === '04',
                    applicableCountriesSpecficDisplay:
                        data.applicableGbGF === '04',
                    applicableGbSpecficDisplay:
                        data.applicableCountries === '02' ||
                        data.applicableCountries === '03' ||
                        data.applicableCountries === '04'
                })
                this.contractInformationFrom.formInstance.setFieldsValue(data)
                if (data.gbdrReviewStatus == 4 || data.gbdrReviewStatus == 5) {
                    this.setState({
                        disabledEdit: true
                    })
                } else {
                    this.setState({
                        disabledEdit: false
                    })
                }
                if (data.reopenStatus == 'Y') {
                    this.setState({
                        disabledReopen: false
                    })
                } else {
                    this.setState({
                        disabledReopen: true
                    })
                }
            })
    }
    private getstatus() {
        const { id } = this.props.location.state as ReviewRequestFormState
        this.reviewService
            .workflow(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                this.setState({
                    status: data[0],
                    historyItems: []
                })
                if (data.length < 2) {
                    this.setState({
                        historynome: false
                    })
                } else { this.setState({ historynome: true }) }

                if (this.state.status.createStatus !== null) {
                    this.setState({
                        oneStatus: 'Creact Request',
                        oneStatusIcon: require('~/assets/svg/CreateRequest-Approve.svg'),
                        reviewer: this.state.status.createReviewer,
                        reviewDate: this.state.status.createReviewDate,
                        reviewState: 'process'
                    })
                } else if (this.state.status.reopenStatus !== null) {
                    this.setState({
                        oneStatus: 'Reopen',
                        oneStatusIcon: require('~/assets/svg/Reopen-Approve.svg'),
                        reviewer: this.state.status.reopenReviewer,
                        reviewDate: this.state.status.reopenReviewDate,
                        reviewState: 'wait'
                    })
                }

                if (this.state.status.submitStatus == null) {
                    this.state.status.submitStatus = "3"
                }
                if (this.state.status.assignReviewTask == null) {
                    this.state.status.assignReviewTask = "3"
                }
                if (this.state.status.rdrStatus == null) {
                    this.state.status.rdrStatus = "3"
                }
                if (this.state.status.gbdrStatus == null) {
                    this.state.status.gbdrStatus = "3"
                }
                if (this.state.status.gtdrStatus == null) {
                    this.state.status.gtdrStatus = "3"
                }

                if (this.state.status.submitStatus == '2') {
                    //  绿色
                    this.setState({
                        oneSubmitIcon: require('~/assets/svg/UploadContract-Approve.svg'),
                        oneSubmitStatus: 'process'
                    })
                }
                if (this.state.status.submitStatus == '3') {
                    //  灰色
                    this.setState({
                        oneSubmitIcon: require('~/assets/svg/Upload Contract- In Progress.svg'),
                        oneSubmitStatus: 'finish'
                    })
                }
                if (this.state.status.assignReviewTask == '7') {
                    //  绿色
                    this.setState({
                        oneassignReviewIcon: require('~/assets/svg/Assign Reviewer-Approve.svg'),
                        oneassignReview: 'process'
                    })
                }
                if (this.state.status.assignReviewTask == '3') {
                    //  灰色
                    this.setState({
                        oneassignReviewIcon: require('~/assets/svg/AssignReviewer-Reopen.svg'),
                        oneassignReview: 'finish'
                    })
                }

                if (this.state.status.rdrStatus == '4') {
                    //  绿色
                    this.setState({
                        onerdrIcon: require('~/assets/svg/GTDR-Approve.svg'),
                        onerdrStatus: 'process'
                    })
                }
                if (this.state.status.rdrStatus == '3') {
                    //  灰色
                    this.setState({
                        onerdrIcon: require('~/assets/svg/GTDR-InProgress.svg'),
                        onerdrStatus: 'finish'
                    })
                }
                if (this.state.status.rdrStatus == '5') {
                    //  红色
                    this.setState({
                        onerdrIcon: require('~/assets/svg/GTDR-Reject.svg'),
                        onerdrStatus: 'erroe'
                    })
                }

                if (this.state.status.gbdrStatus == '4') {
                    //  绿色
                    this.setState({
                        onegbdrIcon: require('~/assets/svg/GTDR-Approve.svg'),
                        onegbdrStatus: 'process'
                    })
                }
                if (this.state.status.gbdrStatus == '3') {
                    //  灰色
                    this.setState({
                        onegbdrIcon: require('~/assets/svg/GTDR-InProgress.svg'),
                        onegbdrStatus: 'finish'
                    })
                }
                if (this.state.status.gbdrStatus == '5') {
                    //  红色
                    this.setState({
                        onegbdrIcon: require('~/assets/svg/GTDR-Reject.svg'),
                        onegbdrStatus: 'error'
                    })
                }


                if (this.state.status.gtdrStatus == '4') {
                    //  绿色
                    this.setState({
                        onegtdrIcon: require('~/assets/svg/GTDR-Approve.svg'),
                        onegtdrStatus: 'process'
                    })
                }
                if (this.state.status.gtdrStatus == '3') {
                    //  灰色
                    this.setState({
                        onegtdrIcon: require('~/assets/svg/GTDR-InProgress.svg'),
                        onegtdrStatus: 'finish'
                    })
                }
                if (this.state.status.gtdrStatus == '5') {
                    //  红色
                    this.setState({
                        onegtdrIcon: require('~/assets/svg/GTDR-Reject.svg'),
                        onegtdrStatus: 'error'
                    })
                }

                //  /////////////////////////////////
                for (var i = 1; i < data.length; i++) {
                    let item = data[i]
                    if (item.submitStatus == null) {
                        item.submitStatus = '3'
                    }
                    if (item.createStatus == null || item.assignReviewTask == null) {
                        item.assignReviewTask = '3'
                    }
                    if (item.rdrStatus == null) {
                        item.rdrStatus = '3'
                    }
                    if (item.gbdrStatus == null) {
                        item.gbdrStatus = '3'
                    }
                    if (item.gtdrStatus == null) {
                        item.gtdrStatus = '3'
                    }

                    let itemData = {
                        reopenReviewDesc: item.reopenReviewDesc,
                        reopenReviewer: item.reopenReviewer,
                        assignReviewDate: item.assignReviewDate,
                        assignReviewer: item.assignReviewer,
                        createReviewDate: item.createReviewDate,
                        createReviewer: item.createReviewer,
                        gbdrReviewDate: item.gbdrReviewDate,
                        gbdrReviewer: item.gbdrReviewer,
                        gtdrReviewDate: item.gtdrReviewDate,
                        gtdrReviewer: item.gtdrReviewer,
                        rdrReviewDate: item.rdrReviewDate,
                        rdrReviewer: item.rdrReviewer,
                        submitReviewer: item.submitReviewer,
                        submitContractDate: item.submitContractDate,
                        submitIcon: '',
                        submitstatus: '',
                        assignReviewIcon: '',
                        assignReview: '',
                        rdrIcon: '',
                        rdrstatus: '',
                        gbdrStatus: '',
                        gbdrIcon: '',
                        gtdrStatus: '',
                        gtdrIcon: '',

                        firstTitle: '',
                        firstIcon: '',
                        reviewer: '',
                        reviewDate: ''
                    }

                    if (item.createReviewDate == null) {
                        itemData.createReviewDate = ''
                    }
                    if (item.createReviewer == null) {
                        itemData.createReviewer = ''
                    }
                    if (item.gbdrReviewDate == null) {
                        itemData.gbdrReviewDate = ''
                    }
                    if (item.gbdrReviewer == null) {
                        itemData.gbdrReviewer = ''
                    }
                    if (item.gtdrReviewDate == null) {
                        itemData.gtdrReviewDate = ''
                    }
                    if (item.gtdrReviewer == null) {
                        itemData.gtdrReviewer = ''
                    }
                    if (item.rdrReviewDate == null) {
                        itemData.rdrReviewDate = ''
                    }
                    if (item.rdrReviewer == null) {
                        itemData.rdrReviewer = ''
                    }
                    if (item.submitReviewer == null) {
                        itemData.submitReviewer = ''
                    }
                    if (item.submitContractDate == null) {
                        itemData.submitContractDate = ''
                    }
                    if (item.reopenReviewDesc == null) {
                        itemData.reopenReviewDesc = ''
                    }
                    if (item.reopenReviewer == null) {
                        itemData.reopenReviewer = ''
                    }
                    if (item.assignReviewDate == null) {
                        itemData.assignReviewDate = ''
                    }
                    if (item.reopenReviewer == null) {
                        itemData.assignReviewer = ''
                    }
                    if (item.createStatus !== null) {
                        itemData.firstTitle = 'Creact Request'
                        itemData.reviewer = item.createReviewer
                        itemData.reviewDate = item.createReviewDate
                    } else if (item.reopenStatus !== null) {
                        itemData.firstTitle = 'Reopen'
                        itemData.reviewer = item.reopenReviewer
                        itemData.reviewDate = item.reopenReviewDate
                    }
                    itemData.firstIcon = require('~/assets/svg/CreateRequest-Approve.svg')
                    if (item.submitStatus == '2') {
                        itemData.submitIcon = require('~/assets/svg/Approve.svg')
                        itemData.submitstatus = 'process'
                    }
                    if (item.submitStatus == '3') {
                        itemData.submitIcon = require('~/assets/svg/InProgress.svg')
                        itemData.submitstatus = 'finish'
                    }
                    if (item.assignReviewTask == '7') {
                        itemData.assignReviewIcon = require('~/assets/svg/Approve.svg')
                        itemData.assignReview = 'process'

                    }
                    if (item.assignReviewTask == '3') {
                        itemData.assignReviewIcon = require('~/assets/svg/InProgress.svg')
                        itemData.assignReview = 'finish'

                    }
                    if (item.rdrStatus == '4') {
                        itemData.rdrIcon = require('~/assets/svg/Approve.svg')
                        itemData.rdrstatus = 'process'
                    }
                    if (item.rdrStatus == '3') {
                        itemData.rdrIcon = require('~/assets/svg/InProgress.svg')
                        itemData.rdrstatus = 'finish'
                    }
                    if (item.rdrStatus == '5') {
                        itemData.rdrIcon = require('~/assets/svg/Reject.svg')
                        itemData.rdrstatus = 'finish'
                    }
                    if (item.gbdrStatus == '4') {
                        itemData.gbdrIcon = require('~/assets/svg/Approve.svg')
                        itemData.gbdrStatus = 'process'
                    }
                    if (item.gbdrStatus == '3') {
                        itemData.gbdrIcon = require('~/assets/svg/InProgress.svg')
                        itemData.gbdrStatus = 'finish'
                    }
                    if (item.gbdrStatus == '5') {
                        itemData.gbdrIcon = require('~/assets/svg/Reject.svg')
                        itemData.gbdrStatus = 'finish'
                    }
                    if (item.gtdrStatus == '4') {
                        itemData.gtdrIcon = require('~/assets/svg/Approve.svg')
                        itemData.gtdrStatus = 'process'
                    }
                    if (item.gtdrStatus == '3') {
                        itemData.gtdrIcon = require('~/assets/svg/InProgress.svg')
                        itemData.gtdrStatus = 'finish'
                    }
                    if (item.gtdrStatus == '5') {
                        itemData.gtdrIcon = require('~/assets/svg/Reject.svg')
                        itemData.gtdrStatus = 'finish'
                    }
                    this.state.historyItems.push(itemData)
                }
                this.setState({ historyItems: this.state.historyItems })
            })
    }

    private getComments() {
        const { id } = this.props.location.state as ReviewRequestFormState

        this.reviewService
            .comments(new RequestParams({}, { append: [id] }))
            .subscribe(data => {
                const action = node => {
                    const children = data.filter(
                        x => x.parentId === node.commentId
                    )
                    console.log(children)
                    node.children = children
                    children.length && children.forEach(action)
                    return node
                }

                const tree = data.filter(x => !x.parentId).map(action)
                this.setState({
                    commontsTree: tree
                })
            })
    }

    private openEdit() {
        const ids = this.props.location.state as ReviewRequestFormState
        console.log(ids.id)
        this.props.history.push({
            pathname: '/pages/review-request-edit',
            state: {
                id: ids.id
            }
        })
    }

    private openUpdate() {
        const ids = this.props.location.state as ReviewRequestFormState
        console.log(ids.id)
        this.props.history.push({
            pathname: '/pages/review-request-update',
            state: {
                id: ids.id
            }
        })
    }

    private ReopenUpdate() {
        this.setState({
            reviewModalVisiblereopen: true
        })
    }

    private closeReviewModalReopen() {
        this.setState({
            reviewModalVisiblereopen: false
        })
        this.actionFromRefReopen.formInstance.resetFields()
    }

    private submitActionReopen() {
        const { id } = this.props.location.state as ReviewRequestFormState
        this.actionFromRefReopen.formInstance.validateFields().then((...data1) => {
            this.reviewService
                .reopen(
                    new RequestParams({
                        reopenDesc: this.actionFromRefReopen.formInstance.getFieldValue('reopenDesc'),
                        reviewId: id
                    })
                )
                .subscribe(data => {
                    this.getReview()
                    this.getstatus()
                    this.closeReviewModalReopen()

                })
        })
    }

    public render() {
        const { data, editorState, disabledReopen } = this.state
        return (
            <components.PageContainer title="Review Request Form" noHeader={true}>
                {/* {this.renderPageHeader()} */}
                <div
                    className="flex-row justify-content-between"
                    style={{ paddingTop: 10 }}
                >
                    <div style={{ fontSize: 28, marginLeft: 20 }}>{data.apiName}</div>
                    <div>
                        <Button
                            size="large"
                            onClick={() => {
                                this.props.history.goBack()
                            }}
                        >
                            Back
                    </Button>
                    </div>
                </div>
                {/* <Divider /> */}
                <CardContainer title="Basic Information">
                    <div>
                        <Button
                            type="primary"
                            size="large"
                            style={
                                {
                                    position: 'absolute',
                                    right: 0,
                                    zIndex: 99
                                }
                            }
                            onClick={() => {
                                this.openEdit()
                            }}
                        >
                            Edit
                    </Button>
                    </div>
                    <LabelContainer column={2} labelSpan={3}>

                        <LabelItem label="API Name">
                            <components.AuthDisableButton
                                type="link"
                                className="text-left"
                                style={{ padding: 0 }}
                                onClick={() =>
                                    this.openForm(data.apiCatalogueId)
                                }
                                auth={[
                                    'ROLE_01',
                                    'ROLE_02',
                                    'ROLE_03',
                                    'ROLE_04',
                                    'ROLE_05',
                                    'ROLE_06',
                                    'ROLE_07',
                                    'ROLE_08'
                                ]}
                            >
                                {data?.apiName}
                            </components.AuthDisableButton>
                        </LabelItem>
                        <LabelItem label="Project Name">
                            {data?.projectName}
                        </LabelItem>

                        <LabelItem label="Demand Classfication">
                            {this.dictUtil.filter(
                                'api_classification',
                                data?.demandClassification
                            )}
                        </LabelItem>
                        <LabelItem label="Requester">
                            {data?.requester}
                        </LabelItem>
                        <LabelItem label="Reuse API Version">
                            {data?.reuseApiVersion}
                        </LabelItem>
                        <LabelItem label="Submit Date">
                            {data?.gbdrReviewDate}
                        </LabelItem>
                        <LabelItem label="Original API ID">
                            {data?.originalSapiId}
                        </LabelItem>
                        <LabelItem label="Region">{data?.region}</LabelItem>
                        <LabelItem label="Backend System">
                            {this.dictUtil.filter(
                                'backend_system',
                                data?.backEndSystem
                            )}
                        </LabelItem>
                        <LabelItem label="Site">
                            {data?.country}
                        </LabelItem>
                        <LabelItem label="API ID">{data?.trueSapiId}</LabelItem>
                        <LabelItem label="Multi-Country">
                            {data?.multiCountry}
                        </LabelItem>
                        <LabelItem label="Core Banking API ID">
                            {data?.coreBankingApiId}
                        </LabelItem>
                        <LabelItem label="API Type">
                            {this.dictUtil.filter('api_type', data?.apiType)}
                        </LabelItem>
                        <LabelItem label="API Method">
                            {data?.apiMethod}
                        </LabelItem>
                        <LabelItem label="Capability">
                            {this.dictUtil.filter(
                                'capability',
                                data?.capability
                            )}

                            {/* {data?.capability} */}
                        </LabelItem>
                        <LabelItem label="Platform">
                            {data?.platform}
                        </LabelItem>
                        <LabelItem label="Feature">
                            {this.dictUtil.filter(
                                // 'feature',
                                // data?.feature
                                data?.capability,
                                data?.feature
                            )}
                            {/* {data?.feature} */}
                        </LabelItem>
                        <LabelItem label="Channel Agnostic">
                            {this.dictUtil.filter(
                                'channel_agnostic',
                                data?.channelAgnostic
                            )}
                        </LabelItem>
                        <LabelItem label="Service">
                            {this.dictUtil.filter(
                                //    'service',
                                //     data?.service
                                data?.feature,
                                data?.service
                            )}
                            {/* {data?.service} */}
                        </LabelItem>
                        <LabelItem label="Description">
                            {/* {this.dictUtil.filter(data?.feature, data?.service)}
                            */}
                            {data?.description}
                        </LabelItem>
                    </LabelContainer>


                </CardContainer>
                {this.renderContractInformation()}
                {this.StepsContract()}
                <CardContainer title="Approval Status">
                    <Button
                        disabled={disabledReopen}
                        size="large"
                        style={
                            {
                                position: 'absolute',
                                right: 24,
                                top: 24,
                                zIndex: 99
                            }
                        }
                        onClick={() => {
                            this.ReopenUpdate()
                        }}
                    >
                        Reopen
                    </Button>
                    <Modal
                        title='Justification'
                        visible={this.state.reviewModalVisiblereopen}
                        okText="Submit"
                        onOk={() => this.submitActionReopen()}
                        onCancel={() => this.closeReviewModalReopen()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromReopen}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <DataForm.Item name="reopenDesc" label="Descrription" rules={[{ required: true }]}>
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                    {this.renderrdrViewBox()}
                    {this.renderGbdrViewBox()}
                    {this.renderGtdrViewBox()}
                    {this.renderModal()}
                    {this.renderReviewModal()}

                    <Divider dashed />
                    <CardContainer title="Comments">
                        <Consumer of={UserStore}>
                            {userStore => (
                                <Form
                                    name="reply-form"
                                    ref={this.formRef}
                                >
                                    <div className="flex-row">
                                        <Avatar
                                            style={{
                                                backgroundColor: '#b50015'
                                            }}
                                            icon={<UserOutlined />}
                                        />
                                        <div
                                            style={{
                                                paddingLeft: 30,
                                                width: '100%'
                                            }}
                                        >
                                            <Form.Item
                                                name="comments"
                                                style={{ width: '100%' }}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message:
                                                            'Please Post your Comment here...'
                                                    }
                                                ]}
                                            >
                                                {/* <TextArea
                                                    rows={4}
                                                    style={{
                                                        width: '100%',
                                                        textAlign: 'left'
                                                    }}
                                                    maxLength={4000}
                                                /> */}
                                                {/* <div style={{
                                                    height:240
                                                }}> */}
                                                <BraftEditor
                                                    language='en'
                                                    className="my-editor"
                                                    value={editorState}
                                                    onChange={this.handleEditorChange}
                                                    // onSave={this.submitContent}
                                                    placeholder="Please enter the body content"
                                                />
                                                {/* </div> */}

                                            </Form.Item>
                                        </div>
                                    </div>
                                    <div className="flex-row justify-content-end">
                                        <div style={{ paddingRight: 20 }}>
                                            <Button
                                                type="primary"
                                                htmlType="submit"
                                                className="submit-button"
                                                danger
                                                size="large"
                                                onClick={() =>
                                                    this.submitComment(
                                                        data,
                                                        userStore
                                                    )}
                                            >
                                                Submit
                                            </Button>
                                        </div>
                                    </div>
                                </Form>
                            )}
                        </Consumer>

                        {this.renderComment()}
                    </CardContainer>
                </CardContainer>
            </components.PageContainer>
        )
    }

    private submitComment(data, userStore) {
        let request = {
            commentatorStaffId: userStore.state.staffId,
            comments: this.state.editorState.toHTML(),
            reviewId: data.reviewId
        }

        this.reviewService
            .comment(new RequestParams(request))
            .subscribe(data => {
                this.getComments()
                message.success('Comment Submitted')

                this.formRef?.current?.resetFields()
            })
    }
    private renderContractInformation() {
        const {
            applicableChannelsSpecficDisplay,
            applicableCountriesSpecficDisplay,
            applicableGbSpecficDisplay,
            contractInformationStatus
        } = this.state

        const testData = {
            reviewId: 1,
            applicableChannels: '1'
        }

        const uploadProps = {
            name: 'file',
            multiple: false,
            action: appConfig.server + '/review/upload',
            data: testData,
            beforeUpload: file => {
                this.file = file
                return false
            },
            onChange(info) {
                const { status } = info.file

                if (status === 'done') {
                    message.success(
                        `${info.file.name} file uploaded successfully.`
                    )
                } else if (status === 'error') {
                    message.error(`${info.file.name} file upload failed.`)
                }
            }
        }

        const columns = [
            {
                title: 'Documents',
                dataIndex: 'contractName',
                render: (text, record) => (
                    <Button
                        type="link"
                        className="text-left"
                        onClick={() => {
                            download(
                                appConfig.server +
                                '/review/download?fileName=' +
                                text,
                                text
                            )
                        }}
                    >
                        {text}
                    </Button>
                )
            },
            {
                title: 'Upload Date',
                dataIndex: 'createDate'
            },
            {
                title: 'Upload Person',
                dataIndex: 'accName'
            },
        ]

        const { dataSource, data, disabledEdit } = this.state

        return (
            <CardContainer title="Contract Information">
                <div className="flex-row justify-content-between">
                    <Button
                        disabled={disabledEdit}
                        type="primary"
                        size="large"
                        style={
                            {
                                position: 'absolute',
                                right: 0,
                                zIndex: 99
                            }
                        }
                        onClick={() => {
                            this.openUpdate()
                        }}
                    >
                        Edit
                    </Button>
                </div>

                <LabelContainer column={2} labelSpan={3}>
                    <LabelItem label="API Version">
                        {data.version}
                    </LabelItem>
                    <LabelItem label="Applicable Channels">
                        {this.dictUtil.filter(
                            'applicable_channels',
                            data?.applicableChannels
                        )}{data?.applicableChannels2 != null && data?.applicableChannels2 != '' && ' - ' + data?.applicableChannels2}
                    </LabelItem>
                    <LabelItem label="Applicable GB/GF">
                        {this.dictUtil.filter(
                            'applicable_gb',
                            data?.applicableGbGf
                        )}{data?.applicableGbGf2 != null && data?.applicableGbGf2 != '' && ' - ' + data?.applicableGbGF2}
                    </LabelItem>
                    <LabelItem label="Applicable Countries">
                        {this.dictUtil.filter(
                            'applicable_countries',
                            data?.applicableCountries
                        )}{data?.applicableCountries2 != null && data?.applicableCountries2 != '' && ' - ' + data?.applicableCountries2}
                    </LabelItem>
                    <LabelItem label="Reusability Score">
                        {/* {data.reusabilityScore} */}
                        {this.dictUtil.filter(
                            'reusability_score',
                            data?.reusabilityScore
                        )}
                    </LabelItem>
                </LabelContainer>
                <DataForm
                    name="contractInformationFrom"
                    ref={this.contractInformationFromRef}
                    column={2}
                    labelCol={{ span: 8 }}
                    labelAlign="left"
                >
                </DataForm>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    size="small"
                    rowKey="contractId"
                    pagination={false}
                    expandable={{
                        expandedRowRender: record => <p style={{ margin: 0 }}>{record.commentDesc}</p>,
                    }}
                />
            </CardContainer>
        )
    }

    private StepsContract() {
        const { Step } = Steps;
        const { reviewDate, reviewer } = this.state
        const { Title } = Typography;
        const { status, oneStatusIcon, historyItems, historynome, reviewState,
            onegtdrIcon, onegtdrStatus, onegbdrStatus, onegbdrIcon, onerdrStatus, onerdrIcon,
            oneassignReviewIcon, oneassignReview, oneSubmitIcon, oneSubmitStatus, oneStatus
        } = this.state
        const { Panel } = Collapse;
        const customDot = (dot, { status, index }) => (
            <Popover
                content={
                    <span>
                        step {index} status: {status}
                    </span>
                }
            >

            </Popover>
        );
        return (
            <CardContainer title="Review Process">
                <Title level={4}>Current Process</Title>
                <div className='oneSteps'>
                    <Steps style={{ marginTop: 20, width: '100%' }} >
                        <Step status={reviewState} style={{ color: '#333' }} icon={<img style={{ width: 50, height: 50 }} src={oneStatusIcon} />} title={oneStatus} subTitle={reviewDate} description={reviewer} />
                        <Step status={oneSubmitStatus} style={{ color: '#00847F' }} title="Submit Contract" icon={<img style={{ width: 50, height: 50 }} src={oneSubmitIcon} />} subTitle={status.submitContractDate} description={status.submitReviewer} />
                        <Step status={oneassignReview} title="Assign Reviewer" icon={<img style={{ width: 50, height: 50 }} src={oneassignReviewIcon} />} subTitle={status.assignReviewDate} description={status.assignReviewer} />
                        <Step status={onerdrStatus} title="RDR" icon={<img style={{ width: 50, height: 50 }} src={onerdrIcon} />} description={status.rdrReviewer} subTitle={status.rdrReviewDate} />
                        <Step status={onegbdrStatus} title="GBDR" icon={<img style={{ width: 50, height: 50 }} src={onegbdrIcon} />} description={status.gbdrReviewer} subTitle={status.gbdrReviewDate} />
                        <Step status={onegtdrStatus} title="GTDR" icon={<img style={{ width: 50, height: 50 }} src={onegtdrIcon} />} description={status.gtdrReviewer} subTitle={status.gtdrReviewDate} />
                    </Steps>
                </div>
                <Divider />
                <div
                    style={styles().input(
                        historynome
                    )}
                >
                    <Collapse style={{ marginTop: 20 }} ghost>
                        <Panel header="History Process" key="1">
                            <div className='twoSteps'>
                                {historyItems.map((item, index) => {
                                    return (
                                        <Steps style={{ marginTop: 20 }} key={index}>
                                            <Step icon={<img style={{ width: 25, height: 25 }} src={item.firstIcon} />} status="process" title={item.firstTitle} description={item.reviewer + '   ' + item.reviewDate} />
                                            <Step icon={<img style={{ width: 25, height: 25 }} src={item.submitIcon} />} status={item.submitStatus} title="Submit Contract" description={item.submitReviewer + '   ' + item.submitContractDate} />
                                            <Step icon={<img style={{ width: 25, height: 25 }} src={item.assignReviewIcon} />} status={item.assignReviewer} title="Assign Reviewer" description={item.assignReviewer + '   ' + item.assignReviewDate} />
                                            <Step icon={<img style={{ width: 25, height: 25 }} src={item.rdrIcon} />} status={item.rdrstatus} title="RDR" description={item.rdrReviewer + '   ' + item.rdrReviewDate} />
                                            <Step icon={<img style={{ width: 25, height: 25 }} src={item.gbdrIcon} />} status={item.gbdrStatus} title="GBDR" description={item.gbdrReviewer + '   ' + item.gbdrReviewDate} />
                                            <Step icon={<img style={{ width: 25, height: 25 }} src={item.gtdrIcon} />} status={item.gtdrStatus} title="GTDR" description={item.gtdrReviewer + '   ' + item.gtdrReviewDate} />
                                        </Steps>
                                    )
                                })}

                            </div>
                        </Panel>
                    </Collapse>
                </div>
            </CardContainer>
        )

    }
    private deleteContract(record) {
        this.reviewService
            .deleteContract(
                new RequestParams({}, { append: [record.contractId] })
            )
            .subscribe(data => {
                message.success('contract delete success')

                this.getReview()
            })
    }
    private renderComment() {
        const { commontsTree } = this.state

        return (
            <List
                className="comment-list"
                header={`${commontsTree.length} replies`}
                itemLayout="horizontal"
                dataSource={commontsTree}
                renderItem={(item: any) => (
                    <li key={item.commentId}>
                        {this.renderCommontItem(item)}
                    </li>
                )}

            />
        )
    }
    private renderCommontItem(item) {
        const data = item.children
        return (
            <ReplyCommont
                item={item}
                onSubmit={() => {
                    this.getComments()
                }}
            >
                {data &&
                    data.map(m => {
                        console.log(m)
                        return (
                            <div key={m.commentId}>
                                {m && this.renderCommontItem(m)}
                            </div>
                        )
                    })}
            </ReplyCommont>
        )
    }

    private renderrdrViewBox() {
        const { data } = this.state
        const { rdrReviewStatus } = data
        switch (rdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="approved"
                        status={rdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.rdrReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.rdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.rdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="rejected"
                        status={rdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Reviewer:">
                                {data.rdrReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.rdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.rdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="verify"
                        status={rdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_03']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_03']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Regional Review Group(RDR)"
                        theme="inProgress"
                        status={rdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'RDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderGbdrViewBox() {
        const { data } = this.state
        const { gbdrReviewStatus } = data
        // console.log(gbdrReviewStatus)
        switch (gbdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="approved"
                        status={gbdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gbdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gbdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gbdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gbdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="rejected"
                        status={gbdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gbdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gbdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gbdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gbdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="verify"
                        status={gbdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_04', 'ROLE_05']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_04', 'ROLE_05']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Business Review(GBDR)"
                        theme="inProgress"
                        status={gbdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GBDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderGtdrViewBox() {
        const { data } = this.state
        const { gtdrReviewStatus } = data
        switch (gtdrReviewStatus) {
            case '4':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="approved"
                        status={gtdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gtdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gtdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gtdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gtdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '5':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="rejected"
                        status={gtdrReviewStatus}
                    >
                        <LabelContainer column={1} labelSpan={3}>
                            <LabelItem label="Global Technical CB Reviewer:">
                                {data.gtdrCbReviewer}
                            </LabelItem>
                            <LabelItem label="Global Technical API Reviewer:">
                                {data.gtdrApiReviewer}
                            </LabelItem>
                            <LabelItem label="Date in Operation:">
                                {data.gtdrReviewDate}
                            </LabelItem>
                            <LabelItem label="Comments:">
                                {data.gtdrCommentDesc}
                            </LabelItem>
                        </LabelContainer>
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    disabled
                                    size="large"
                                >
                                    Approve
                                </Button>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <Button
                                    className="submit-button"
                                    size="large"
                                    disabled
                                >
                                    Reject
                                </Button>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            case '3':
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="verify"
                        status={gtdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_06', 'ROLE_07']}
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    auth={['ROLE_06', 'ROLE_07']}
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
            default:
                return (
                    <NotificationContainer
                        className="padding-y"
                        title="Global Technical Review(GTDR)"
                        theme="inProgress"
                        status={gtdrReviewStatus}
                    >
                        <div className="flex-row justify-content-end">
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    type="primary"
                                    htmlType="submit"
                                    className="submit-button"
                                    danger
                                    size="large"
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '4'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Approve
                                </components.AuthDisableButton>
                            </div>
                            <div
                                style={{
                                    padding: 20
                                }}
                            >
                                <components.AuthDisableButton
                                    className="submit-button"
                                    size="large"
                                    style={{ width: 100 }}
                                    onClick={() => {
                                        this.reviewType = 'GTDR'
                                        this.reviewStatus = '5'
                                        this.openReviewModal()
                                    }}
                                    disabled
                                >
                                    Reject
                                </components.AuthDisableButton>
                            </div>
                        </div>
                    </NotificationContainer>
                )
        }
    }

    private renderReviewModalTitle() {
        return (
            <div className="flex-row align-items-center">
                <div
                    style={{
                        color: '#333333',
                        fontSize: 26,
                        fontWeight: 275,
                        paddingLeft: 20
                    }}
                >
                    Verification
                </div>
            </div>
        )
    }

    private renderReviewModal() {
        let strroletype = ''
        if (this.reviewType === 'RDR') {
            strroletype = 'Regional Review Group'
        }
        if (this.reviewType === 'GBDR') {
            strroletype = 'Global Business Design Group'
        }
        if (this.reviewType === 'GTDR') {
            strroletype = 'Global Technical Design Group'
        }
        return (
            <Consumer of={UserStore}>
                {userStore => (
                    <Modal
                        title={this.renderReviewModalTitle()}
                        visible={this.state.reviewModalVisible}
                        okText="Submit"
                        onOk={() => this.submitAction(userStore.state.staffId)}
                        onCancel={() => this.closeReviewModal()}
                        width="680px"
                        okType="primary"
                        cancelText="Close"
                    >
                        {/* {(this.staffId = userStore.state.staffId)} */}
                        <div
                            style={{
                                color: '#333333',
                                fontSize: 14,
                                fontWeight: 300,
                                paddingLeft: 20
                            }}
                        >
                            <DataForm
                                name="actionFrom"
                                ref={this.actionFromRef}
                                column={1}
                                labelCol={{ span: 8 }}
                                labelAlign="left"
                                formWidth={500}
                            >
                                <LabelContainer column={1} labelSpan={4}>
                                    <LabelItem label="Team">
                                        {strroletype}
                                    </LabelItem>
                                </LabelContainer>
                                {/*  <DataForm.Item label="Team">
                                    {userStore.state.roleList.map(
                                        val => val.authority + ' '
                                    )}
                                </DataForm.Item> */}
                                <DataForm.Item
                                    name="comment"
                                    label="Comment"
                                    rules={[{ required: true }]}
                                >
                                    <Input />
                                </DataForm.Item>
                            </DataForm>
                        </div>
                    </Modal>
                )}
            </Consumer>
        )
    }
    private submitAction(staffId) {
        const { data } = this.state
        this.actionForm.formInstance.validateFields().then((...data1) => {
            this.reviewService
                .status(
                    new RequestParams({
                        reviewId: [data.reviewId],
                        commentDesc: this.actionForm.formInstance.getFieldValue(
                            'comment'
                        ),
                        reviewStatus: this.reviewStatus,
                        reviewType: this.reviewType
                    })
                )
                .subscribe(data => {
                    this.getReview()
                    this.getstatus()
                    this.closeReviewModal()
                    this.openSuccessModal()
                })
        })
    }

    public renderModal() {
        return (
            <CustomizeModal
                title="Success!"
                visible={this.state.successModalVisible}
                okText="Review Detail -->"
                cancelText="Close"
                content="Check Status in Review List."
                onOk={() => {
                    this.getReview()
                    this.getstatus()
                    this.closeSuccessModal()
                }}
                onCancel={() => this.closeSuccessModal()}
            ></CustomizeModal>
        )
    }

    private closeReviewModal() {
        this.setState({
            reviewModalVisible: false
        })
        this.actionForm.formInstance.resetFields()
    }
    private closeSuccessModal() {
        this.setState({
            successModalVisible: false
        })
    }
    private openSuccessModal() {
        this.setState({
            successModalVisible: true
        })
    }
    private openReviewModal() {
        this.setState({
            reviewModalVisible: true
        })
    }
    private get actionForm(): DataForm {
        return this.actionFromRef.current as DataForm
    }
    private get actionFromRefReopen(): DataForm {
        return this.actionFromReopen.current as DataForm
    }
    private get contractInformationFrom(): DataForm {
        return this.contractInformationFromRef.current as DataForm
    }

    public renderPageHeader() {
        return (
            <components.PageHeaderContainer>
                Customer Address Creation
            </components.PageHeaderContainer>
        )
    }
    private get dataForm(): DataForm {
        return this.dataFromRef.current as DataForm
    }
    private openForm(apiCatalogueId) {
        this.props.history.push({
            pathname: '/pages/api-catalogue/api-detail',
            state: {
                id: apiCatalogueId
            }
        })
    }
}
