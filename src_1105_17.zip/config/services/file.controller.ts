/**
 * Tools File upload Controller
 */
import { RequestMethod } from '~/core/http'

// controller Name
const controller = 'file'

export const FileController = {
    // download file
    download: {
        controller,
        action: 'download',
        type: RequestMethod.Get
    },
    // upload file
    upload: {
        controller,
        action: 'upload',
        type: RequestMethod.Post
    }
}
